<?php
/**
 * Pull + apply approved changes. Every 5 minutes: GET /changes from the
 * stored cursor; for each change hash the current store value, ack with the
 * hash, and apply only when the server does not answer `conflict`. Images
 * are downloaded before the ack so a broken download becomes a `failed` ack
 * rather than a half-applied gallery.
 *
 * An `images` value comes in two shapes (IMAGE-OPS.md §2): a plain array is
 * "replace the whole gallery" (what every version before 1.4.0 did, and what
 * OneShopLab still sends to stores without image ids), while `{v:1, ops:[…]}`
 * is an ordered operation list planned by {@see OneShopLab_Image_Ops} and executed
 * here. Ops whose target is gone are reported in the ack as `skippedOps`;
 * `remove` only detaches, the media file always stays in the library.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Changes poller.
 */
final class OneShopLab_Changes {

	public const PAGE_SIZE = 50;

	/**
	 * Registers hooks.
	 */
	public static function init(): void {
		add_action( OneShopLab_Plugin::CRON_POLL_CHANGES, array( __CLASS__, 'poll' ) );
	}

	/**
	 * One poll cycle. Returns a summary for the admin "poll now" button.
	 *
	 * @return array|WP_Error {fetched, applied, failed, skipped, conflict, more}
	 */
	public static function poll() {
		if ( ! OneShopLab_State::can_work() ) {
			return new WP_Error( 'paused', __( 'The plugin is paused (no usable site key or maintenance mode).', 'oneshoplab' ) );
		}
		$client = OneShopLab_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			return $client;
		}

		$page = $client->changes( OneShopLab_State::cursor(), self::PAGE_SIZE );
		if ( is_wp_error( $page ) ) {
			if ( 'validation' === $page->get_error_code() && '' !== OneShopLab_State::cursor() ) {
				OneShopLab_State::set_cursor( '' ); // Cursor rejected: start again from the oldest pending change.
			}
			return $page;
		}

		$changes = isset( $page['changes'] ) && is_array( $page['changes'] ) ? $page['changes'] : array();
		$summary = array(
			'fetched'  => count( $changes ),
			'applied'  => 0,
			'failed'   => 0,
			'skipped'  => 0,
			'conflict' => 0,
			'more'     => ! empty( $page['nextCursor'] ),
		);

		foreach ( $changes as $change ) {
			if ( ! is_array( $change ) || empty( $change['id'] ) ) {
				continue;
			}
			$outcome = self::handle( $client, $change );
			if ( is_wp_error( $outcome ) ) {
				// Ack could not be delivered: keep the cursor here and retry next time.
				break;
			}
			++$summary[ $outcome ];
			OneShopLab_State::set_cursor( (string) $change['id'] );
		}

		OneShopLab_State::update_status(
			array(
				'last_poll'       => time(),
				'pending_changes' => $summary['fetched'] - $summary['applied'] - $summary['failed'] - $summary['skipped'] - $summary['conflict'] + ( $summary['more'] ? self::PAGE_SIZE : 0 ),
				'last_poll_stats' => $summary,
			)
		);
		return $summary;
	}

	/**
	 * Processes one change end to end.
	 *
	 * @param OneShopLab_Client $client Client.
	 * @param array      $change Change payload.
	 * @return string|WP_Error applied|failed|skipped|conflict, or WP_Error when the ack itself failed.
	 */
	private static function handle( OneShopLab_Client $client, array $change ) {
		$id    = (string) $change['id'];
		$field = (string) ( $change['field'] ?? '' );
		$pid   = (int) ( $change['productSourceId'] ?? 0 );

		$acked = OneShopLab_State::acked();
		if ( isset( $acked[ $id ] ) ) {
			// Never re-apply: just repeat the same ack (idempotent) so the server stops listing it.
			$status = 'conflict' === $acked[ $id ] ? 'skipped' : $acked[ $id ];
			$result = $client->ack( $id, array( 'status' => $status ) );
			return is_wp_error( $result ) && 'already_acked' !== $result->get_error_code() ? $result : $acked[ $id ];
		}

		$product = $pid > 0 ? wc_get_product( $pid ) : false;
		if ( ! $product instanceof WC_Product ) {
			return self::finish( $client, $change, 'skipped', __( 'Product not found in WooCommerce.', 'oneshoplab' ) );
		}
		if ( ! in_array( $field, array( 'title', 'description', 'tags', 'images' ), true ) ) {
			return self::finish( $client, $change, 'skipped', __( 'Unsupported field.', 'oneshoplab' ) );
		}

		$raw  = OneShopLab_Product_Mapper::collect( $product );
		$hash = OneShopLab_Hash::value( OneShopLab_Product_Mapper::field_value( $raw, $field ) );

		$prepared = null;
		$skipped  = array();
		if ( 'images' === $field ) {
			try {
				$prepared = self::prepare_images( $product, $change['value'] ?? array() );
				$skipped  = $prepared['skipped'];
			} catch ( Throwable $e ) {
				return self::finish( $client, $change, 'failed', $e->getMessage() );
			}
		}

		$modified  = $product->get_date_modified();
		$ack_body  = array(
			'status'         => 'applied',
			'storeValueHash' => $hash,
			'storeUpdatedAt' => gmdate( 'Y-m-d\TH:i:s\Z', $modified ? $modified->getTimestamp() : time() ),
		);
		if ( ! empty( $skipped ) ) {
			$ack_body['skippedOps'] = array_values( array_slice( $skipped, 0, OneShopLab_Image_Ops::MAX_OPS ) );
		}
		$ack = $client->ack( $id, $ack_body );
		if ( is_wp_error( $ack ) ) {
			self::discard_attachments( $prepared );
			if ( 'already_acked' === $ack->get_error_code() ) {
				return self::record( $change, 'skipped', __( 'Already acknowledged earlier.', 'oneshoplab' ) );
			}
			return $ack;
		}
		if ( 'conflict' === ( $ack['status'] ?? '' ) ) {
			self::discard_attachments( $prepared );
			return self::record( $change, 'conflict', __( 'The product changed in WooCommerce since approval; not applied.', 'oneshoplab' ) );
		}

		try {
			self::apply( $product, $field, $change['value'] ?? null, $prepared );
		} catch ( Throwable $e ) {
			OneShopLab_Logger::error( 'Apply failed after ack', array( 'change' => $id, 'error' => $e->getMessage() ) );
			$client->ack( $id, array( 'status' => 'failed', 'error' => mb_substr( $e->getMessage(), 0, 1000 ) ) ); // Best effort (409 expected).
			return self::record( $change, 'failed', $e->getMessage() );
		}
		return self::record( $change, 'applied', self::skipped_note( $skipped ) );
	}

	/**
	 * Plain-words note for the change log when some operations were skipped.
	 *
	 * @param string[] $skipped `"<index>:<verb>"` entries.
	 * @return string
	 */
	private static function skipped_note( array $skipped ): string {
		$count = count( $skipped );
		if ( 0 === $count ) {
			return '';
		}
		return sprintf(
			/* translators: %d: number of image operations that were not applied */
			_n(
				'%d image change was not applied: that image is no longer on the product.',
				'%d image changes were not applied: those images are no longer on the product.',
				$count,
				'oneshoplab'
			),
			$count
		);
	}

	/**
	 * Acks a non-applied outcome and records it.
	 *
	 * @param OneShopLab_Client $client  Client.
	 * @param array      $change  Change.
	 * @param string     $status  failed|skipped.
	 * @param string     $message Reason.
	 * @return string|WP_Error
	 */
	private static function finish( OneShopLab_Client $client, array $change, string $status, string $message ) {
		$result = $client->ack(
			(string) $change['id'],
			array(
				'status' => $status,
				'error'  => mb_substr( OneShopLab_Logger::redact( $message ), 0, 1000 ),
			)
		);
		if ( is_wp_error( $result ) && 'already_acked' !== $result->get_error_code() ) {
			return $result;
		}
		return self::record( $change, $status, $message );
	}

	/**
	 * Local bookkeeping. The product's name is written into the entry next to
	 * its id: the admin page shows names, not post ids, and a product deleted
	 * a month later must still be recognisable in the log.
	 *
	 * @param array  $change  Change.
	 * @param string $status  Outcome.
	 * @param string $message Reason.
	 * @return string Outcome.
	 */
	private static function record( array $change, string $status, string $message ): string {
		$product_id = (int) ( $change['productSourceId'] ?? 0 );
		OneShopLab_State::remember_ack( (string) $change['id'], $status );
		OneShopLab_State::log_change(
			array(
				'id'            => (string) $change['id'],
				'product_id'    => $product_id,
				'product_title' => self::product_title( $product_id ),
				'field'         => (string) ( $change['field'] ?? '' ),
				'status'        => $status,
				'message'       => OneShopLab_Logger::redact( $message ),
				'at'            => time(),
			)
		);
		OneShopLab_Logger::info( "Change {$change['id']} {$status}", array( 'field' => $change['field'] ?? '', 'product' => $change['productSourceId'] ?? '' ) );
		return $status;
	}

	/**
	 * The product's name for the change log, at the moment the change was
	 * processed. Empty when the id no longer resolves — the log then falls
	 * back to `#id`, which is all there ever was to say about it.
	 *
	 * @param int $product_id WooCommerce product id.
	 * @return string
	 */
	private static function product_title( int $product_id ): string {
		if ( $product_id <= 0 ) {
			return '';
		}
		$product = wc_get_product( $product_id );
		$title   = $product instanceof WC_Product ? $product->get_name() : (string) get_the_title( $product_id );
		return mb_substr( trim( wp_strip_all_tags( (string) $title ) ), 0, 200 );
	}

	/**
	 * Writes the value into the product.
	 *
	 * @param WC_Product $product  Product.
	 * @param string     $field    Field.
	 * @param mixed      $value    New value.
	 * @param array|null $prepared {order, alt, created, skipped} from {@see self::prepare_images()}.
	 * @throws RuntimeException When WordPress refuses the update.
	 */
	private static function apply( WC_Product $product, string $field, $value, ?array $prepared ): void {
		switch ( $field ) {
			case 'title':
				$product->set_name( wp_strip_all_tags( (string) $value ) );
				break;
			case 'description':
				$product->set_description( wp_kses_post( (string) $value ) );
				break;
			case 'tags':
				$names  = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', (array) $value ) ) ) );
				$result = wp_set_object_terms( $product->get_id(), $names, 'product_tag', false );
				if ( is_wp_error( $result ) ) {
					throw new RuntimeException( esc_html( $result->get_error_message() ) );
				}
				$ids = wp_get_object_terms( $product->get_id(), 'product_tag', array( 'fields' => 'ids' ) );
				$product->set_tag_ids( is_array( $ids ) ? $ids : array() );
				break;
			case 'images':
				$ids = array_values( array_map( 'intval', (array) ( $prepared['order'] ?? array() ) ) );
				if ( empty( $ids ) ) {
					break; // Never leave the product with no image at all.
				}
				$product->set_image_id( $ids[0] );
				$product->set_gallery_image_ids( array_slice( $ids, 1 ) );
				foreach ( (array) ( $prepared['alt'] ?? array() ) as $attachment_id => $text ) {
					update_post_meta( (int) $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( (string) $text ) );
				}
				break;
		}
		$product->save();
	}

	/**
	 * Turns an `images` change value into everything {@see self::apply()} needs:
	 * the final gallery (attachment ids in order), the alt texts to write, the
	 * attachments created for this change (deleted again on conflict) and the
	 * operations that were skipped. Downloads happen here, before the ack — and
	 * so does the writable-uploads pre-flight, but only for the payloads that
	 * actually download something ({@see self::require_writable_uploads()}).
	 *
	 * @param WC_Product $product Product.
	 * @param mixed      $value   Plain array (replace all) or `{v:1, ops:[…]}`.
	 * @return array {order, alt, created, skipped}
	 * @throws RuntimeException On a malformed payload or a failed download.
	 */
	private static function prepare_images( WC_Product $product, $value ): array {
		if ( ! OneShopLab_Image_Ops::is_ops_payload( $value ) ) {
			// A plain array replaces the whole gallery, so every image in it is
			// downloaded: this branch always needs a writable media folder.
			self::require_writable_uploads();
			$ids = self::sideload_images( $product, (array) $value );
			return array(
				'order'   => $ids,
				'alt'     => array(),
				'created' => $ids,
				'skipped' => array(),
			);
		}
		return self::prepare_ops( $product, (array) $value );
	}

	/**
	 * Plans the operation list against the product's current gallery, then
	 * downloads the images it introduces. A download failure rolls back the
	 * attachments already created for this change.
	 *
	 * @param WC_Product $product Product.
	 * @param array      $value   `{v:1, ops:[…]}`.
	 * @return array {order, alt, created, skipped}
	 * @throws RuntimeException On a malformed payload or a failed download.
	 */
	private static function prepare_ops( WC_Product $product, array $value ): array {
		try {
			$plan = OneShopLab_Image_Ops::plan( $value, self::current_image_ids( $product ) );
		} catch ( Throwable $e ) {
			/* translators: %s: technical reason, in English */
			throw new RuntimeException( esc_html( sprintf( __( 'The image changes could not be read (%s).', 'oneshoplab' ), $e->getMessage() ) ) );
		}

		// Pre-flight, and only for the lists that need it: a media folder that
		// cannot take a new file fails every download below with a raw
		// WordPress sentence, so say it once, in plain words, before spending a
		// single HTTP request on it. A list that only sets alt texts, removes
		// or reorders images writes nothing to disk and must apply on a shop
		// whose uploads folder is read-only.
		if ( OneShopLab_Image_Ops::needs_media_write( $plan ) ) {
			self::require_writable_uploads();
		}

		$created  = array();
		$resolved = array();
		foreach ( $plan['order'] as $ref ) {
			$index = OneShopLab_Image_Ops::new_index( (string) $ref );
			if ( null === $index ) {
				$resolved[ $ref ] = (int) $ref; // An attachment already on the product.
				continue;
			}
			$image = $plan['new'][ $index ];
			try {
				$attachment_id = self::sideload_one( $product, $image['src'], (string) $image['alt'] );
			} catch ( Throwable $e ) {
				self::discard_attachments( $created );
				throw $e;
			}
			$created[]        = $attachment_id;
			$resolved[ $ref ] = $attachment_id;
		}

		$order = array();
		foreach ( $plan['order'] as $ref ) {
			$order[] = $resolved[ $ref ];
		}
		$alt = array();
		foreach ( $plan['alt'] as $ref => $text ) {
			if ( isset( $resolved[ $ref ] ) ) {
				$alt[ $resolved[ $ref ] ] = $text;
			}
		}

		return array(
			'order'   => $order,
			'alt'     => $alt,
			'created' => $created,
			'skipped' => $plan['skipped'],
		);
	}

	/**
	 * Stops a change that would have to copy a file into a media folder that
	 * cannot take one. Asked only by the paths that really download something —
	 * and asked of a *live* write test, never of a cached "blocked"
	 * ({@see OneShopLab_Health::uploads_writable()}), so a host that has just fixed the
	 * permissions unblocks the very next change.
	 *
	 * @throws RuntimeException With the merchant-readable sentence.
	 */
	private static function require_writable_uploads(): void {
		if ( ! OneShopLab_Health::uploads_writable() ) {
			throw new RuntimeException( esc_html( OneShopLab_Health::explain_media_error( OneShopLab_Health::ERR_UPLOADS_NOT_WRITABLE ) ) );
		}
	}

	/**
	 * The product's gallery as the ids operations address: featured image first,
	 * then the gallery, deduplicated and limited to attachments that still
	 * resolve — exactly what {@see OneShopLab_Product_Mapper::collect()} sent, so a
	 * `target` OneShopLab knows about is a target found here.
	 *
	 * @param WC_Product $product Product.
	 * @return string[] Attachment ids as strings.
	 */
	private static function current_image_ids( WC_Product $product ): array {
		$ids = array_merge( array( (int) $product->get_image_id() ), array_map( 'intval', (array) $product->get_gallery_image_ids() ) );
		$out = array();
		foreach ( array_unique( array_filter( $ids ) ) as $attachment_id ) {
			if ( wp_get_attachment_url( (int) $attachment_id ) ) {
				$out[] = (string) $attachment_id;
			}
		}
		return $out;
	}

	/**
	 * Downloads every image into the media library (never hot-linked).
	 *
	 * @param WC_Product $product Product (owner of the attachments).
	 * @param array      $images  `[{src, alt}]` or `[src]`.
	 * @return int[] Attachment ids in order.
	 * @throws RuntimeException On download failure.
	 */
	private static function sideload_images( WC_Product $product, array $images ): array {
		$ids = array();
		foreach ( $images as $image ) {
			$src = is_array( $image ) ? (string) ( $image['src'] ?? '' ) : (string) $image;
			$alt = is_array( $image ) ? (string) ( $image['alt'] ?? '' ) : '';
			if ( '' === $src || ! wp_http_validate_url( $src ) ) {
				continue;
			}
			try {
				$ids[] = self::sideload_one( $product, $src, $alt );
			} catch ( Throwable $e ) {
				self::discard_attachments( $ids );
				throw $e;
			}
		}
		if ( empty( $ids ) ) {
			throw new RuntimeException( esc_html__( 'No usable image in the change.', 'oneshoplab' ) );
		}
		return $ids;
	}

	/**
	 * Copies one CDN image into the media library and sets its alt text.
	 *
	 * @param WC_Product $product Product (owner of the attachment).
	 * @param string     $src     Source URL.
	 * @param string     $alt     Alt text ('' to leave empty).
	 * @return int Attachment id.
	 * @throws RuntimeException On download failure or an unusable URL. The message
	 *                          is always the merchant-readable sentence from
	 *                          {@see OneShopLab_Health}; the raw English one goes to the log.
	 */
	private static function sideload_one( WC_Product $product, string $src, string $alt ): int {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		if ( '' === $src || ! wp_http_validate_url( $src ) ) {
			throw new RuntimeException( esc_html( self::image_failure( $product, $src, 'invalid_url', 'the image URL is not usable' ) ) );
		}
		$attachment_id = media_sideload_image( $src, $product->get_id(), $product->get_name(), 'id' );
		if ( is_wp_error( $attachment_id ) ) {
			throw new RuntimeException( esc_html( self::image_failure( $product, $src, (string) $attachment_id->get_error_code(), (string) $attachment_id->get_error_message() ) ) );
		}
		if ( '' !== $alt ) {
			update_post_meta( (int) $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
		}
		return (int) $attachment_id;
	}

	/**
	 * Turns a raw media failure into the sentence the merchant reads. The
	 * English original — "The uploaded file could not be moved to
	 * wp-content/uploads/2026/08." and friends — is written to the WooCommerce
	 * log for support and never shown or sent anywhere else; the returned
	 * sentence is what the change log and the ack `error` (hence the OneShopLab
	 * dashboard) carry.
	 *
	 * When the family cannot be told from the message, one live write test on
	 * the media folder settles the most common cause before giving up.
	 *
	 * @param WC_Product $product Product being changed.
	 * @param string     $src     Source URL (logged, never shown).
	 * @param string     $code    WP_Error code.
	 * @param string     $message WP_Error message, in the site's language.
	 * @return string Translated, actionable sentence.
	 */
	private static function image_failure( WC_Product $product, string $src, string $code, string $message ): string {
		$family = OneShopLab_Health::classify_media_error( $code, $message, OneShopLab_Health::core_needles() );
		if ( OneShopLab_Health::ERR_UNKNOWN === $family && ! OneShopLab_Health::uploads_writable( true ) ) {
			$family = OneShopLab_Health::ERR_UPLOADS_NOT_WRITABLE;
		}
		OneShopLab_Logger::error(
			'Image sideload failed',
			array(
				'product' => $product->get_id(),
				'src'     => $src,
				'family'  => $family,
				'code'    => $code,
				'error'   => $message,
			)
		);
		return OneShopLab_Health::explain_media_error( $family );
	}

	/**
	 * Deletes attachments created for a change that was not applied. Only ever
	 * called with ids this change downloaded — an image the merchant already
	 * had is detached, never deleted.
	 *
	 * @param array|null $prepared Prepared images, or a plain list of ids.
	 */
	private static function discard_attachments( ?array $prepared ): void {
		$ids = isset( $prepared['created'] ) ? (array) $prepared['created'] : (array) $prepared;
		foreach ( $ids as $id ) {
			wp_delete_attachment( (int) $id, true );
		}
	}
}
