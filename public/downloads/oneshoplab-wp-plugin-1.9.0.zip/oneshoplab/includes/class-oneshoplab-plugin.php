<?php
/**
 * Bootstrap: requirement checks, hooks, cron schedules, activation.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin bootstrap.
 */
final class OneShopLab_Plugin {

	/** Cron hook names. */
	public const CRON_FLUSH_QUEUE = 'oneshoplab_flush_queue';
	public const CRON_POLL_CHANGES = 'oneshoplab_poll_changes';
	public const CRON_FULL_SYNC_STEP = 'oneshoplab_full_sync_step';
	public const CRON_WEBHOOK_REGISTER = 'oneshoplab_webhook_register';
	public const CRON_POLL_NOW = 'oneshoplab_poll_now';

	/** Every cron hook of the plugin (for deactivation / uninstall). */
	public const ALL_CRON_HOOKS = array(
		self::CRON_FLUSH_QUEUE,
		self::CRON_POLL_CHANGES,
		self::CRON_FULL_SYNC_STEP,
		self::CRON_WEBHOOK_REGISTER,
		self::CRON_POLL_NOW,
	);

	/**
	 * Problems found by {@see self::requirement_errors()} (translated strings).
	 *
	 * @var string[]
	 */
	private static array $errors = array();

	/**
	 * Entry point on `plugins_loaded`.
	 */
	public static function boot(): void {
		self::$errors = self::requirement_errors();
		if ( ! empty( self::$errors ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'render_requirement_notice' ) );
			// No hooks, no cron work: the plugin is inert until requirements are met.
			return;
		}

		add_action( 'before_woocommerce_init', array( __CLASS__, 'declare_wc_compat' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval

		OneShopLab_Settings::init();
		OneShopLab_Sync::init();
		OneShopLab_Changes::init();
		OneShopLab_Webhook::init();

		// Self-heal the schedules (e.g. after a cron table wipe).
		add_action( 'admin_init', array( __CLASS__, 'ensure_cron' ) );
	}

	/**
	 * Checks PHP version, WordPress version, extensions and WooCommerce presence.
	 *
	 * @return string[] Translated error messages (empty = all good).
	 */
	public static function requirement_errors(): array {
		$errors = array();
		if ( version_compare( PHP_VERSION, ONESHOPLAB_MIN_PHP, '<' ) ) {
			/* translators: 1: required PHP version, 2: current PHP version */
			$errors[] = sprintf( __( 'OneShopLab needs PHP %1$s or newer (your server runs %2$s).', 'oneshoplab' ), ONESHOPLAB_MIN_PHP, PHP_VERSION );
		}
		$wp_version = self::wp_version();
		if ( '' !== $wp_version && version_compare( $wp_version, ONESHOPLAB_MIN_WP, '<' ) ) {
			/* translators: 1: required WordPress version, 2: current WordPress version */
			$errors[] = sprintf( __( 'OneShopLab needs WordPress %1$s or newer (you have %2$s). Update WordPress, then reload this page.', 'oneshoplab' ), ONESHOPLAB_MIN_WP, $wp_version );
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			$errors[] = __( 'OneShopLab needs the PHP "openssl" extension to store your site key safely. Ask your host to enable it.', 'oneshoplab' );
		}
		if ( ! function_exists( 'curl_init' ) ) {
			$errors[] = __( 'OneShopLab needs the PHP "curl" extension to talk to OneShopLab. Ask your host to enable it.', 'oneshoplab' );
		}
		if ( ! class_exists( 'WooCommerce' ) ) {
			$errors[] = __( 'OneShopLab needs WooCommerce. Install and activate WooCommerce, then reload this page.', 'oneshoplab' );
		} elseif ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, ONESHOPLAB_MIN_WC, '<' ) ) {
			/* translators: 1: required WooCommerce version, 2: current WooCommerce version */
			$errors[] = sprintf( __( 'OneShopLab needs WooCommerce %1$s or newer (you have %2$s).', 'oneshoplab' ), ONESHOPLAB_MIN_WC, WC_VERSION );
		}
		return $errors;
	}

	/**
	 * Running WordPress version ('' when it cannot be read).
	 *
	 * @return string
	 */
	private static function wp_version(): string {
		if ( isset( $GLOBALS['wp_version'] ) ) {
			return (string) $GLOBALS['wp_version'];
		}
		return function_exists( 'get_bloginfo' ) ? (string) get_bloginfo( 'version' ) : '';
	}

	/**
	 * Admin notice listing unmet requirements.
	 */
	public static function render_requirement_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		foreach ( self::$errors as $error ) {
			printf( '<div class="notice notice-error"><p><strong>OneShopLab</strong> — %s</p></div>', esc_html( $error ) );
		}
	}

	/**
	 * HPOS / block checkout compatibility flags. `FeaturesUtil` (and the
	 * `before_woocommerce_init` hook that calls this) only exist from
	 * WooCommerce 7.1: the `class_exists()` guard keeps WooCommerce 7.0 working,
	 * where neither the feature nor the declaration exists.
	 */
	public static function declare_wc_compat(): void {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', ONESHOPLAB_PLUGIN_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', ONESHOPLAB_PLUGIN_FILE, true );
		}
	}

	/**
	 * Adds the 1-minute and 5-minute intervals.
	 *
	 * @param array $schedules Existing schedules.
	 * @return array
	 */
	public static function cron_schedules( array $schedules ): array {
		$schedules['oneshoplab_minutely'] = array(
			'interval' => MINUTE_IN_SECONDS,
			'display'  => __( 'Every minute (OneShopLab)', 'oneshoplab' ),
		);
		$schedules['oneshoplab_five_minutes'] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every 5 minutes (OneShopLab)', 'oneshoplab' ),
		);
		return $schedules;
	}

	/**
	 * Schedules the recurring events if missing.
	 */
	public static function ensure_cron(): void {
		if ( ! wp_next_scheduled( self::CRON_FLUSH_QUEUE ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, 'oneshoplab_minutely', self::CRON_FLUSH_QUEUE );
		}
		if ( ! wp_next_scheduled( self::CRON_POLL_CHANGES ) ) {
			wp_schedule_event( time() + 2 * MINUTE_IN_SECONDS, 'oneshoplab_five_minutes', self::CRON_POLL_CHANGES );
		}
		if ( ! wp_next_scheduled( self::CRON_WEBHOOK_REGISTER ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', self::CRON_WEBHOOK_REGISTER );
		}
	}

	/**
	 * Removes every scheduled event of the plugin.
	 */
	public static function clear_cron(): void {
		foreach ( self::ALL_CRON_HOOKS as $hook ) {
			wp_unschedule_hook( $hook );
		}
	}

	/**
	 * Activation: cron schedules; webhook registration when a key exists.
	 * Options are created lazily.
	 */
	public static function activate(): void {
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval
		self::ensure_cron();
		if ( empty( self::requirement_errors() ) && OneShopLab_State::can_work() ) {
			OneShopLab_Webhook::register();
		}
	}

	/**
	 * Deactivation: stop cron work, tell OneShopLab to stop sending webhooks
	 * (best effort), keep settings.
	 */
	public static function deactivate(): void {
		self::clear_cron();
		if ( OneShopLab_State::has_key() ) {
			OneShopLab_Webhook::unregister();
		}
	}

	/**
	 * True when WordPress or WooCommerce is in maintenance mode: no API traffic then.
	 */
	public static function is_maintenance(): bool {
		if ( function_exists( 'wp_is_maintenance_mode' ) && wp_is_maintenance_mode() ) {
			return true;
		}
		/**
		 * Lets maintenance-mode plugins pause OneShopLab traffic.
		 *
		 * @param bool $paused Whether to skip all API calls.
		 */
		return (bool) apply_filters( 'oneshoplab_is_maintenance', false );
	}
}
