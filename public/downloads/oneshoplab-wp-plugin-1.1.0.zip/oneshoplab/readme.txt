=== OneShopLab ===
Contributors: oneshoplab
Tags: woocommerce, ai, product descriptions, seo, catalog
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 8.1
WC requires at least: 8.0
WC tested up to: 9.9
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connects your WooCommerce catalogue to OneShopLab and applies the titles, descriptions, tags and images you approve there.

== Description ==

**English**

OneShopLab audits your product pages and writes better titles, descriptions, tags and product images. This plugin is the bridge with your WooCommerce shop:

* it sends your products to OneShopLab (no more public-storefront scraping), right after you save them and in full whenever you ask;
* it applies the changes you approve in OneShopLab ("Apply to store") right away — OneShopLab notifies the plugin, which then fetches and writes them into the products (images are copied into your media library); if that notification cannot reach your site, the plugin still checks every 5 minutes;
* it tells OneShopLab what was applied, and refuses to overwrite a product you edited in the meantime (conflict detection).

You need a OneShopLab account and a **site key** created in your site settings › Integrations. The key is stored encrypted and never displayed again.

**Français**

OneShopLab audite vos fiches produit et rédige de meilleurs titres, descriptions, étiquettes et images. Ce plugin fait le lien avec votre boutique WooCommerce :

* il envoie vos produits à OneShopLab, juste après chaque enregistrement et en totalité quand vous le demandez ;
* il applique immédiatement les changements que vous validez dans OneShopLab (« Appliquer à la boutique ») — OneShopLab prévient le plugin, qui récupère et écrit les changements dans vos produits (les images sont copiées dans votre médiathèque) ; si cette notification ne peut pas atteindre votre site, le plugin vérifie quand même toutes les 5 minutes ;
* il confirme à OneShopLab ce qui a été appliqué et refuse d’écraser un produit que vous avez modifié entre-temps (détection de conflit).

Il vous faut un compte OneShopLab et une **clé du site** créée dans les réglages du site › Intégrations. La clé est stockée chiffrée et n’est jamais réaffichée.

== Installation ==

1. Upload the zip through Plugins › Add New › Upload Plugin, then activate it. / Téléversez le zip via Extensions › Ajouter › Téléverser une extension, puis activez-la.
2. Open **OneShopLab** in the left menu (also under WooCommerce). / Ouvrez **OneShopLab** dans le menu de gauche (aussi sous WooCommerce).
3. Paste your site key in the **Site key** box and click Save. / Collez votre clé du site dans la case **Clé du site** et cliquez sur Enregistrer.
4. The plugin sends your products right away; the status card turns green within a minute. / Le plugin envoie vos produits tout de suite ; la carte d’état passe au vert en moins d’une minute.

== Frequently Asked Questions ==

= Where is my site key? / Où est ma clé du site ? =

In OneShopLab, open your site › Integrations. The key is shown once; if you lose it, create a new one and paste it here. / Dans OneShopLab, ouvrez votre site › Intégrations. La clé n’est affichée qu’une fois ; si vous la perdez, créez-en une nouvelle et collez-la ici.

= The status says the key was revoked or expired / L’état dit que la clé est révoquée ou expirée =

Create a new key in OneShopLab and paste it in the plugin. Nothing is sent until then. / Créez une nouvelle clé dans OneShopLab et collez-la dans le plugin. Rien n’est envoyé d’ici là.

= "The server clock is off" / « L’horloge du serveur est décalée » =

Requests are signed with the current time; your server's clock is more than 5 minutes off. Ask your host to enable NTP. / Les requêtes sont signées avec l’heure courante ; l’horloge de votre serveur a plus de 5 minutes de décalage. Demandez à votre hébergeur d’activer NTP.

= Does the plugin work on multisite? =

Yes, each site keeps its own key and settings.

= Where are the logs? =

WooCommerce › Status › Logs, source "oneshoplab". Keys are never written to the logs.

== Changelog ==

= 1.1.0 =
* Instant updates: OneShopLab notifies the plugin as soon as you approve a change (signed webhook); the 5-minute check stays as a fallback. "Test" button on the status card. / Mises à jour instantanées : OneShopLab prévient le plugin dès qu’un changement est validé ; la vérification toutes les 5 minutes reste en secours. Bouton « Tester » sur la carte d’état.

= 1.0.0 =
* First release: catalogue push, approved-changes pull, encrypted site key, French translation.
