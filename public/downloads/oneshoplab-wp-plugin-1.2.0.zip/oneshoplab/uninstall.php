<?php
/**
 * Uninstall: remove every option, transient and cron event, on every site of
 * a network. The WooCommerce log files are left to WooCommerce's own retention.
 *
 * @package OneShopLab
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-osl-state.php';
require_once __DIR__ . '/includes/class-osl-plugin.php';

/**
 * Cleans the current site.
 */
function oneshoplab_uninstall_site(): void {
	foreach ( OSL_State::ALL_OPTIONS as $option ) {
		delete_option( $option );
	}
	foreach ( OSL_State::ALL_TRANSIENTS as $transient ) {
		delete_transient( $transient );
	}
	foreach ( OSL_Plugin::ALL_CRON_HOOKS as $hook ) {
		wp_unschedule_hook( $hook );
	}
	// Webhook dedupe memory (transients named oneshoplab_evt_<sha256>, 24 h TTL).
	global $wpdb;
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_oneshoplab_evt_' ) . '%', $wpdb->esc_like( '_transient_timeout_oneshoplab_evt_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'number' => 0, 'fields' => 'ids' ) ) as $blog_id ) {
		switch_to_blog( (int) $blog_id );
		oneshoplab_uninstall_site();
		restore_current_blog();
	}
} else {
	oneshoplab_uninstall_site();
}
