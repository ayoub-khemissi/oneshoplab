<?php
/**
 * Admin page: top-level "OneShopLab" menu + WooCommerce submenu, site key
 * form, connection test, status card, manual actions. Every action goes
 * through admin-post with a nonce and `manage_woocommerce`.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings screen.
 */
final class OSL_Settings {

	public const SLUG       = 'oneshoplab';
	public const CAPABILITY = 'manage_woocommerce';

	/**
	 * Registers hooks.
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_post_oneshoplab_save_key', array( __CLASS__, 'handle_save_key' ) );
		add_action( 'admin_post_oneshoplab_clear_key', array( __CLASS__, 'handle_clear_key' ) );
		add_action( 'admin_post_oneshoplab_test', array( __CLASS__, 'handle_test' ) );
		add_action( 'admin_post_oneshoplab_full_sync', array( __CLASS__, 'handle_full_sync' ) );
		add_action( 'admin_post_oneshoplab_poll', array( __CLASS__, 'handle_poll' ) );
		add_action( 'wp_ajax_oneshoplab_webhook_ping', array( __CLASS__, 'ajax_webhook_ping' ) );
		add_action( 'wp_ajax_oneshoplab_webhook_ping_status', array( __CLASS__, 'ajax_webhook_ping_status' ) );
		add_action( 'admin_notices', array( __CLASS__, 'key_state_notice' ) );
		add_filter( 'plugin_action_links_' . OSL_PLUGIN_BASENAME, array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Menu entries: the wizard tells merchants to open "OneShopLab" in the left menu.
	 */
	public static function register_menu(): void {
		add_menu_page(
			__( 'OneShopLab', 'oneshoplab' ),
			__( 'OneShopLab', 'oneshoplab' ),
			self::CAPABILITY,
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-store',
			56
		);
		add_submenu_page(
			'woocommerce',
			__( 'OneShopLab', 'oneshoplab' ),
			__( 'OneShopLab', 'oneshoplab' ),
			self::CAPABILITY,
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * "Settings" link on the plugins list.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( array $links ): array {
		array_unshift( $links, '<a href="' . esc_url( self::page_url() ) . '">' . esc_html__( 'Settings', 'oneshoplab' ) . '</a>' );
		return $links;
	}

	/**
	 * Admin URL of the page.
	 *
	 * @param array $args Query args.
	 * @return string
	 */
	public static function page_url( array $args = array() ): string {
		return add_query_arg( array_merge( array( 'page' => self::SLUG ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Site-wide notice when the key stopped working.
	 */
	public static function key_state_notice(): void {
		if ( ! current_user_can( self::CAPABILITY ) || ! OSL_State::has_key() ) {
			return;
		}
		$state = OSL_State::status()['key_state'] ?? OSL_State::KEY_STATE_OK;
		if ( in_array( $state, array( OSL_State::KEY_STATE_OK, '', OSL_State::KEY_STATE_MISSING ), true ) ) {
			return;
		}
		printf(
			'<div class="notice notice-error"><p><strong>OneShopLab</strong> — %s <a href="%s">%s</a></p></div>',
			esc_html( OSL_Client::explain( $state ) ),
			esc_url( self::page_url() ),
			esc_html__( 'Open OneShopLab settings', 'oneshoplab' )
		);
	}

	/* -------------------------------------------------------------- actions */

	/**
	 * Nonce + capability guard shared by all handlers.
	 *
	 * @param string $action Nonce action.
	 */
	private static function guard( string $action ): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'oneshoplab' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Back to the page with a message code.
	 *
	 * @param string $msg  Message code.
	 * @param string $text Optional detail.
	 */
	private static function redirect( string $msg, string $text = '' ): void {
		$args = array( 'osl_msg' => $msg );
		if ( '' !== $text ) {
			$args['osl_text'] = rawurlencode( mb_substr( $text, 0, 500 ) );
		}
		wp_safe_redirect( self::page_url( $args ) );
		exit;
	}

	/**
	 * Save the site key, test it, launch the first full sync.
	 */
	public static function handle_save_key(): void {
		self::guard( 'oneshoplab_save_key' );
		$key = isset( $_POST['oneshoplab_site_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['oneshoplab_site_key'] ) ) ) : '';
		if ( ! OSL_Signer::is_valid_key( $key ) ) {
			self::redirect( 'invalid_key' );
		}
		// Key change: tell OneShopLab to stop sending webhooks for the old key (best effort).
		$old_client = OSL_Client::from_settings();
		if ( ! is_wp_error( $old_client ) ) {
			OSL_Webhook::unregister( $old_client );
		}
		if ( ! OSL_State::save_key( $key ) ) {
			self::redirect( 'error', OSL_Client::explain( 'unreadable' ) );
		}
		delete_transient( OSL_State::TR_RETRY_AFTER );
		OSL_Logger::info( 'Site key saved', array( 'prefix' => OSL_Signer::prefix( $key ) ) );

		$client = new OSL_Client( $key );
		$site   = $client->site();
		if ( is_wp_error( $site ) ) {
			self::redirect( 'saved_but_failed', OSL_Client::explain( $site->get_error_code(), $site->get_error_message() ) );
		}
		self::store_site_info( $site );
		OSL_Webhook::register( $client );
		OSL_Sync::start_full_sync();
		self::redirect( 'saved' );
	}

	/**
	 * Forget the key.
	 */
	public static function handle_clear_key(): void {
		self::guard( 'oneshoplab_clear_key' );
		OSL_Webhook::unregister();
		OSL_State::clear_key();
		OSL_Logger::info( 'Site key removed' );
		self::redirect( 'cleared' );
	}

	/**
	 * "Test connection" → GET /site.
	 */
	public static function handle_test(): void {
		self::guard( 'oneshoplab_test' );
		$client = OSL_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			self::redirect( 'error', OSL_Client::explain( $client->get_error_code(), $client->get_error_message() ) );
		}
		$site = $client->site();
		if ( is_wp_error( $site ) ) {
			self::redirect( 'error', OSL_Client::explain( $site->get_error_code(), $site->get_error_message() ) );
		}
		// A successful call proves the key works again (e.g. after a rotation).
		OSL_State::update_status( array( 'key_state' => OSL_State::KEY_STATE_OK ) );
		self::store_site_info( $site );
		self::redirect( 'test_ok' );
	}

	/**
	 * "Sync everything now".
	 */
	public static function handle_full_sync(): void {
		self::guard( 'oneshoplab_full_sync' );
		$result = OSL_Sync::start_full_sync();
		if ( is_wp_error( $result ) ) {
			self::redirect( 'error', $result->get_error_message() );
		}
		self::redirect( 'sync_started' );
	}

	/**
	 * "Check for changes now".
	 */
	public static function handle_poll(): void {
		self::guard( 'oneshoplab_poll' );
		$result = OSL_Changes::poll();
		if ( is_wp_error( $result ) ) {
			self::redirect( 'error', OSL_Client::explain( $result->get_error_code(), $result->get_error_message() ) );
		}
		self::redirect( 'poll_done', (string) $result['applied'] );
	}

	/**
	 * Keeps the /site answer for the status card.
	 *
	 * @param array $site GET /site response.
	 */
	/**
	 * AJAX "Test" button: asks OneShopLab to send a `ping` event. Returns the
	 * moment the request was made so the page can watch for its arrival.
	 */
	public static function ajax_webhook_ping(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do that.', 'oneshoplab' ) ), 403 );
		}
		check_ajax_referer( 'oneshoplab_webhook_ping', 'nonce' );
		$sent_at = time();
		$result  = OSL_Webhook::request_ping();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => OSL_Client::explain( $result->get_error_code(), $result->get_error_message() ) ) );
		}
		wp_send_json_success( array( 'sent_at' => $sent_at ) );
	}

	/**
	 * AJAX: whether a ping arrived since `sent_at`.
	 */
	public static function ajax_webhook_ping_status(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do that.', 'oneshoplab' ) ), 403 );
		}
		check_ajax_referer( 'oneshoplab_webhook_ping', 'nonce' );
		$sent_at   = isset( $_REQUEST['sent_at'] ) ? (int) $_REQUEST['sent_at'] : 0;
		$last_ping = (int) ( OSL_State::status()['webhook_last_ping'] ?? 0 );
		wp_send_json_success(
			array(
				'arrived'   => $last_ping > 0 && $last_ping >= $sent_at,
				'last_ping' => $last_ping,
			)
		);
	}

	private static function store_site_info( array $site ): void {
		OSL_State::update_status(
			array(
				'site' => array(
					'name'   => (string) ( $site['site']['name'] ?? '' ),
					'plan'   => (string) ( $site['site']['plan'] ?? '' ),
					'domain' => (string) ( $site['site']['domain'] ?? '' ),
					'limits' => (array) ( $site['site']['limits'] ?? array() ),
				),
				'key'  => array(
					'permissions' => (array) ( $site['key']['permissions'] ?? array() ),
					'expiresAt'   => $site['key']['expiresAt'] ?? null,
					'graceUntil'  => $site['key']['graceUntil'] ?? null,
				),
			)
		);
	}

	/* --------------------------------------------------------------- render */

	/**
	 * Page output.
	 */
	public static function render(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'oneshoplab' ), 403 );
		}
		$status   = OSL_State::status();
		$has_key  = OSL_State::has_key();
		$state    = $has_key ? ( $status['key_state'] ?? OSL_State::KEY_STATE_OK ) : OSL_State::KEY_STATE_MISSING;
		$full     = OSL_Sync::full_sync_state();
		$queue    = count( OSL_State::queue() );
		$log      = OSL_State::change_log();
		$msg      = isset( $_GET['osl_msg'] ) ? sanitize_key( wp_unslash( $_GET['osl_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$msg_text = isset( $_GET['osl_text'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['osl_text'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap oneshoplab-wrap">
			<h1><?php esc_html_e( 'OneShopLab', 'oneshoplab' ); ?></h1>
			<?php self::render_message( $msg, $msg_text ); ?>

			<?php if ( $has_key && ! empty( $status['key']['graceUntil'] ) && strtotime( (string) $status['key']['graceUntil'] ) > time() ) : ?>
				<div class="notice notice-warning inline"><p>
					<?php
					/* translators: %s: date/time */
					printf( esc_html__( 'This site key was rotated in OneShopLab. It stops working on %s — paste the new key before then.', 'oneshoplab' ), esc_html( self::format_date( strtotime( (string) $status['key']['graceUntil'] ) ) ) );
					?>
				</p></div>
			<?php endif; ?>

			<div class="oneshoplab-grid">
			<div class="card">
				<h2><?php esc_html_e( 'Site key', 'oneshoplab' ); ?></h2>
				<p><?php esc_html_e( 'Create the key in OneShopLab (site settings › Integrations), then paste it below. It is a password: it is stored encrypted and never shown again.', 'oneshoplab' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="oneshoplab_save_key" />
					<?php wp_nonce_field( 'oneshoplab_save_key' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="oneshoplab_site_key"><?php esc_html_e( 'Site key', 'oneshoplab' ); ?></label></th>
							<td>
								<input type="password" id="oneshoplab_site_key" name="oneshoplab_site_key" class="regular-text" autocomplete="off" spellcheck="false" placeholder="osl_live_…" />
								<?php if ( $has_key ) : ?>
									<p class="description">
										<?php
										/* translators: %s: key prefix */
										printf( esc_html__( 'A key starting with %s is saved. Paste a new key to replace it.', 'oneshoplab' ), '<code>' . esc_html( OSL_State::key_prefix() ) . '…</code>' );
										?>
									</p>
								<?php endif; ?>
							</td>
						</tr>
					</table>
					<?php submit_button( __( 'Save', 'oneshoplab' ), 'primary', 'submit', false ); ?>
				</form>
				<?php if ( $has_key ) : ?>
					<p class="oneshoplab-actions">
						<?php self::action_button( 'oneshoplab_test', __( 'Test connection', 'oneshoplab' ) ); ?>
						<?php self::action_button( 'oneshoplab_clear_key', __( 'Remove the key', 'oneshoplab' ), 'delete' ); ?>
					</p>
				<?php endif; ?>
			</div>

			<div class="card">
				<h2><?php esc_html_e( 'Status', 'oneshoplab' ); ?></h2>
				<?php self::render_state_pill( $state, $status ); ?>
				<table class="widefat striped oneshoplab-status">
					<tbody>
						<tr><th><?php esc_html_e( 'OneShopLab site', 'oneshoplab' ); ?></th><td><?php echo esc_html( self::site_label( $status ) ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Last exchange', 'oneshoplab' ); ?></th><td><?php echo esc_html( self::ago( $status['last_contact'] ?? 0 ) ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Last sync', 'oneshoplab' ); ?></th><td><?php echo esc_html( self::sync_label( $status ) ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Products', 'oneshoplab' ); ?></th><td><?php echo esc_html( self::products_label( $status, $full, $queue ) ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Changes to apply', 'oneshoplab' ); ?></th><td><?php echo esc_html( self::pending_label( $status ) ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Instant updates', 'oneshoplab' ); ?></th><td><?php self::render_webhook_cell( $has_key, $status ); ?></td></tr>
						<tr><th><?php esc_html_e( 'Last error', 'oneshoplab' ); ?></th><td><?php echo esc_html( self::error_label( $status ) ); ?></td></tr>
					</tbody>
				</table>
				<?php if ( $has_key ) : ?>
					<p class="oneshoplab-actions">
						<?php self::action_button( 'oneshoplab_full_sync', __( 'Sync everything now', 'oneshoplab' ), 'primary', null !== $full ); ?>
						<?php self::action_button( 'oneshoplab_poll', __( 'Check for changes now', 'oneshoplab' ) ); ?>
					</p>
				<?php endif; ?>
			</div>
			</div>

			<?php if ( ! empty( $log ) ) : ?>
			<div class="card oneshoplab-log">
				<h2><?php esc_html_e( 'Last applied changes', 'oneshoplab' ); ?></h2>
				<table class="widefat striped">
					<thead><tr>
						<th><?php esc_html_e( 'When', 'oneshoplab' ); ?></th>
						<th><?php esc_html_e( 'Product', 'oneshoplab' ); ?></th>
						<th><?php esc_html_e( 'Field', 'oneshoplab' ); ?></th>
						<th><?php esc_html_e( 'Result', 'oneshoplab' ); ?></th>
						<th><?php esc_html_e( 'Details', 'oneshoplab' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( self::format_date( (int) ( $entry['at'] ?? 0 ) ) ); ?></td>
							<td>
								<?php $title = get_the_title( (int) ( $entry['product_id'] ?? 0 ) ); ?>
								<?php if ( $title ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( (int) $entry['product_id'] ) ?: '#' ); ?>"><?php echo esc_html( $title ); ?></a>
								<?php else : ?>
									#<?php echo esc_html( (string) ( $entry['product_id'] ?? '' ) ); ?>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( self::field_label( (string) ( $entry['field'] ?? '' ) ) ); ?></td>
							<td><?php echo esc_html( self::result_label( (string) ( $entry['status'] ?? '' ) ) ); ?></td>
							<td><?php echo esc_html( (string) ( $entry['message'] ?? '' ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php endif; ?>

			<?php self::render_webhook_script(); ?>

			<p class="description">
				<?php
				printf(
					/* translators: %s: link to WooCommerce logs */
					esc_html__( 'Technical details are in %s (source "oneshoplab").', 'oneshoplab' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs' ) ) . '">' . esc_html__( 'WooCommerce › Status › Logs', 'oneshoplab' ) . '</a>'
				);
				?>
			</p>
		</div>
		<style>
			.oneshoplab-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:16px;max-width:1100px}
			.oneshoplab-wrap .card{max-width:none;margin-top:16px}
			.oneshoplab-log{max-width:1100px}
			.oneshoplab-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
			.oneshoplab-actions form{display:inline}
			.oneshoplab-status th{width:40%}
			.oneshoplab-pill{display:inline-block;padding:4px 10px;border-radius:999px;font-weight:600;margin-bottom:12px}
			.oneshoplab-pill.ok{background:#d1fae5;color:#065f46}
			.oneshoplab-pill.bad{background:#fee2e2;color:#991b1b}
			.oneshoplab-pill.off{background:#e5e7eb;color:#374151}
			.oneshoplab-webhook-test{margin-left:8px;vertical-align:baseline}
			.oneshoplab-webhook-result{display:block;margin-top:4px}
			.oneshoplab-webhook-result.ok{color:#065f46}
			.oneshoplab-webhook-result.bad{color:#991b1b}
		</style>
		<?php
	}

	/**
	 * Inline admin-post button.
	 *
	 * @param string $action   Action name (also the nonce action).
	 * @param string $label    Button label.
	 * @param string $type     primary|secondary|delete.
	 * @param bool   $disabled Disabled state.
	 */
	private static function action_button( string $action, string $label, string $type = 'secondary', bool $disabled = false ): void {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" />
			<?php wp_nonce_field( $action ); ?>
			<button type="submit" class="button <?php echo 'primary' === $type ? 'button-primary' : ( 'delete' === $type ? 'button-link-delete' : '' ); ?>" <?php disabled( $disabled ); ?>><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/**
	 * Feedback after an action.
	 *
	 * @param string $msg  Code.
	 * @param string $text Detail.
	 */
	private static function render_message( string $msg, string $text ): void {
		$map = array(
			'saved'            => array( 'success', __( 'Key saved and connection verified. Your products are being sent now — the status turns green within a minute.', 'oneshoplab' ) ),
			'saved_but_failed' => array( 'error', __( 'Key saved, but OneShopLab refused it:', 'oneshoplab' ) ),
			'invalid_key'      => array( 'error', __( 'That does not look like a site key. It starts with osl_live_ and has no spaces.', 'oneshoplab' ) ),
			'cleared'          => array( 'info', __( 'Key removed. The plugin is paused.', 'oneshoplab' ) ),
			'test_ok'          => array( 'success', __( 'Connected to OneShopLab.', 'oneshoplab' ) ),
			'sync_started'     => array( 'success', __( 'Full sync started. It runs in the background, 200 products at a time.', 'oneshoplab' ) ),
			'poll_done'        => array( 'success', __( 'Checked for changes.', 'oneshoplab' ) ),
			'error'            => array( 'error', __( 'Something went wrong:', 'oneshoplab' ) ),
		);
		if ( ! isset( $map[ $msg ] ) ) {
			return;
		}
		[ $type, $label ] = $map[ $msg ];
		if ( 'poll_done' === $msg && '' !== $text ) {
			/* translators: %s: number of changes */
			$text = sprintf( _n( '%s change applied.', '%s changes applied.', (int) $text, 'oneshoplab' ), $text );
		}
		printf( '<div class="notice notice-%s is-dismissible"><p>%s %s</p></div>', esc_attr( $type ), esc_html( $label ), esc_html( $text ) );
	}

	/**
	 * Green/red/grey state pill.
	 *
	 * @param string $state  Key state.
	 * @param array  $status Status.
	 */
	/**
	 * "Instant updates" cell: state, plain-language note, Test button.
	 *
	 * @param bool  $has_key Whether a key is stored.
	 * @param array $status  Status option.
	 */
	private static function render_webhook_cell( bool $has_key, array $status ): void {
		$fallback = __( 'not available (checking every 5 minutes)', 'oneshoplab' );
		if ( ! $has_key ) {
			echo esc_html( $fallback );
			return;
		}
		$state = OSL_Webhook::state();
		if ( OSL_Webhook::STATE_ACTIVE === $state ) {
			echo esc_html__( 'enabled', 'oneshoplab' );
			$last_ping = (int) ( $status['webhook_last_ping'] ?? 0 );
			if ( $last_ping > 0 ) {
				/* translators: %s: human time diff */
				echo ' ' . esc_html( sprintf( __( '(last test %s)', 'oneshoplab' ), self::ago( $last_ping ) ) );
			}
			printf(
				' <button type="button" class="button button-small oneshoplab-webhook-test" id="oneshoplab-webhook-test">%s</button><span class="oneshoplab-webhook-result" id="oneshoplab-webhook-result" aria-live="polite"></span>',
				esc_html__( 'Test', 'oneshoplab' )
			);
			return;
		}
		echo esc_html( $fallback );
		if ( OSL_Webhook::STATE_FORBIDDEN === $state ) {
			echo '<br /><span class="description">' . esc_html__( 'This key has no webhook permission: create a new key in OneShopLab and paste it here.', 'oneshoplab' ) . '</span>';
		} elseif ( OSL_Webhook::STATE_ERROR === $state && ! empty( $status['webhook_error']['message'] ) ) {
			echo '<br /><span class="description">' . esc_html( (string) $status['webhook_error']['message'] ) . '</span>';
		}
	}

	/**
	 * Inline script for the Test button: POST ping, then poll the last-ping
	 * timestamp for 10 seconds.
	 */
	private static function render_webhook_script(): void {
		if ( ! OSL_Webhook::is_active() ) {
			return;
		}
		$config = array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'oneshoplab_webhook_ping' ),
			'sending' => __( 'Sending a test event…', 'oneshoplab' ),
			'waiting' => __( 'Waiting for OneShopLab…', 'oneshoplab' ),
			'arrived' => __( 'The test event arrived: instant updates work.', 'oneshoplab' ),
			'timeout' => __( 'No test event received within 10 seconds. Check that your site is reachable from the internet over HTTPS; changes are still applied every 5 minutes.', 'oneshoplab' ),
			'failed'  => __( 'Could not ask OneShopLab for a test event:', 'oneshoplab' ),
		);
		?>
		<script>
		( function () {
			var cfg = <?php echo wp_json_encode( $config ); ?>;
			var btn = document.getElementById( 'oneshoplab-webhook-test' );
			var out = document.getElementById( 'oneshoplab-webhook-result' );
			if ( ! btn || ! out ) { return; }
			function say( text, cls ) { out.textContent = text; out.className = 'oneshoplab-webhook-result' + ( cls ? ' ' + cls : '' ); }
			function call( action, extra ) {
				var body = new URLSearchParams( { action: action, nonce: cfg.nonce } );
				Object.keys( extra || {} ).forEach( function ( k ) { body.append( k, extra[ k ] ); } );
				return fetch( cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } ).then( function ( r ) { return r.json(); } );
			}
			btn.addEventListener( 'click', function () {
				btn.disabled = true;
				say( cfg.sending );
				call( 'oneshoplab_webhook_ping' ).then( function ( res ) {
					if ( ! res || ! res.success ) {
						say( cfg.failed + ' ' + ( res && res.data && res.data.message ? res.data.message : '' ), 'bad' );
						btn.disabled = false;
						return;
					}
					say( cfg.waiting );
					var sentAt = res.data.sent_at, tries = 0;
					var timer = setInterval( function () {
						tries++;
						call( 'oneshoplab_webhook_ping_status', { sent_at: sentAt } ).then( function ( st ) {
							if ( st && st.success && st.data.arrived ) {
								clearInterval( timer );
								say( cfg.arrived, 'ok' );
								btn.disabled = false;
							} else if ( tries >= 10 ) {
								clearInterval( timer );
								say( cfg.timeout, 'bad' );
								btn.disabled = false;
							}
						} ).catch( function () {} );
					}, 1000 );
				} ).catch( function () { say( cfg.failed, 'bad' ); btn.disabled = false; } );
			} );
		} )();
		</script>
		<?php
	}

	private static function render_state_pill( string $state, array $status ): void {
		if ( OSL_State::KEY_STATE_MISSING === $state ) {
			$class = 'off';
			$text  = __( 'Not connected — paste your site key.', 'oneshoplab' );
		} elseif ( OSL_State::KEY_STATE_OK === $state || '' === $state ) {
			$class = ! empty( $status['last_contact'] ) ? 'ok' : 'off';
			$text  = ! empty( $status['last_contact'] ) ? __( 'Connected', 'oneshoplab' ) : __( 'Waiting for the first exchange…', 'oneshoplab' );
			if ( OSL_Plugin::is_maintenance() ) {
				$class = 'off';
				$text  = __( 'Paused: the site is in maintenance mode.', 'oneshoplab' );
			}
		} else {
			$class = 'bad';
			$text  = OSL_Client::explain( $state );
		}
		printf( '<span class="oneshoplab-pill %s">%s</span>', esc_attr( $class ), esc_html( $text ) );
	}

	/**
	 * Site name + plan.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function site_label( array $status ): string {
		if ( empty( $status['site']['name'] ) ) {
			return '—';
		}
		return $status['site']['name'] . ( ! empty( $status['site']['plan'] ) ? ' (' . $status['site']['plan'] . ')' : '' );
	}

	/**
	 * Last sync line.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function sync_label( array $status ): string {
		if ( empty( $status['last_sync'] ) ) {
			return __( 'Never', 'oneshoplab' );
		}
		$r = $status['last_sync_result'] ?? array();
		return sprintf(
			/* translators: 1: relative time, 2: inserted, 3: updated, 4: archived, 5: unchanged */
			__( '%1$s — %2$d added, %3$d updated, %4$d archived, %5$d unchanged', 'oneshoplab' ),
			self::ago( (int) $status['last_sync'] ),
			(int) ( $r['inserted'] ?? 0 ),
			(int) ( $r['updated'] ?? 0 ),
			(int) ( $r['archived'] ?? 0 ),
			(int) ( $r['unchanged'] ?? 0 )
		);
	}

	/**
	 * Product count line.
	 *
	 * @param array      $status Status.
	 * @param array|null $full   Full-sync progress.
	 * @param int        $queue  Queued items.
	 * @return string
	 */
	private static function products_label( array $status, ?array $full, int $queue ): string {
		$count = (int) ( $status['product_count'] ?? OSL_Sync::count_products() );
		/* translators: %d: number of products */
		$label = sprintf( _n( '%d product', '%d products', $count, 'oneshoplab' ), $count );
		if ( null !== $full ) {
			/* translators: 1: products sent so far, 2: total */
			$label .= ' — ' . sprintf( __( 'full sync running (%1$d / %2$d sent)', 'oneshoplab' ), (int) $full['sent'], (int) $full['total'] );
		} elseif ( $queue > 0 ) {
			/* translators: %d: number of queued products */
			$label .= ' — ' . sprintf( _n( '%d waiting to be sent', '%d waiting to be sent', $queue, 'oneshoplab' ), $queue );
		}
		return $label;
	}

	/**
	 * Pending changes line.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function pending_label( array $status ): string {
		if ( empty( $status['last_poll'] ) ) {
			return __( 'Not checked yet', 'oneshoplab' );
		}
		$pending = (int) ( $status['pending_changes'] ?? 0 );
		/* translators: 1: number of pending changes, 2: relative time */
		return sprintf( __( '%1$d pending (checked %2$s)', 'oneshoplab' ), $pending, self::ago( (int) $status['last_poll'] ) );
	}

	/**
	 * Last error line.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function error_label( array $status ): string {
		if ( empty( $status['last_error']['code'] ) ) {
			return __( 'None', 'oneshoplab' );
		}
		$e = $status['last_error'];
		return OSL_Client::explain( (string) $e['code'], (string) ( $e['message'] ?? '' ) ) . ' (' . self::ago( (int) ( $e['at'] ?? 0 ) ) . ')';
	}

	/**
	 * Field label.
	 *
	 * @param string $field Field.
	 * @return string
	 */
	private static function field_label( string $field ): string {
		$labels = array(
			'title'       => __( 'Title', 'oneshoplab' ),
			'description' => __( 'Description', 'oneshoplab' ),
			'tags'        => __( 'Tags', 'oneshoplab' ),
			'images'      => __( 'Images', 'oneshoplab' ),
		);
		return $labels[ $field ] ?? $field;
	}

	/**
	 * Outcome label.
	 *
	 * @param string $status Outcome.
	 * @return string
	 */
	private static function result_label( string $status ): string {
		$labels = array(
			'applied'  => __( 'Applied', 'oneshoplab' ),
			'failed'   => __( 'Failed', 'oneshoplab' ),
			'skipped'  => __( 'Skipped', 'oneshoplab' ),
			'conflict' => __( 'Conflict', 'oneshoplab' ),
		);
		return $labels[ $status ] ?? $status;
	}

	/**
	 * "3 minutes ago".
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private static function ago( int $timestamp ): string {
		if ( $timestamp <= 0 ) {
			return __( 'Never', 'oneshoplab' );
		}
		/* translators: %s: human time diff */
		return sprintf( __( '%s ago', 'oneshoplab' ), human_time_diff( $timestamp, time() ) );
	}

	/**
	 * Localised date/time.
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private static function format_date( int $timestamp ): string {
		return $timestamp > 0 ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : '—';
	}
}
