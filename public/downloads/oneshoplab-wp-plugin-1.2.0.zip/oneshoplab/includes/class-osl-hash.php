<?php
/**
 * Canonical JSON + sha256, byte-compatible with the server's `hashValue()`:
 * object keys sorted recursively, no whitespace, `/` and unicode unescaped
 * (JavaScript `JSON.stringify` output). Used for `storeValueHash`.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Value hashing for conflict detection.
 */
final class OSL_Hash {

	/**
	 * Canonical JSON string of a value.
	 *
	 * @param mixed $value Scalars, lists, associative arrays (= objects), stdClass.
	 * @return string
	 */
	public static function canonical_json( $value ): string {
		$json = json_encode( // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode
			self::sort_keys( $value ),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_LINE_TERMINATORS
		);
		return false === $json ? 'null' : $json;
	}

	/**
	 * sha256 hex of the canonical JSON.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function value( $value ): string {
		return hash( 'sha256', self::canonical_json( $value ) );
	}

	/**
	 * Recursively sorts associative keys; lists keep their order; null-ish stays null.
	 *
	 * @param mixed $value Value.
	 * @return mixed
	 */
	private static function sort_keys( $value ) {
		if ( $value instanceof stdClass ) {
			$value = (array) $value;
			if ( empty( $value ) ) {
				return new stdClass();
			}
		}
		if ( is_array( $value ) ) {
			if ( self::is_list( $value ) ) {
				return array_map( array( __CLASS__, 'sort_keys' ), $value );
			}
			ksort( $value, SORT_STRING );
			$out = array();
			foreach ( $value as $k => $v ) {
				$out[ (string) $k ] = self::sort_keys( $v );
			}
			return (object) $out;
		}
		return $value;
	}

	/**
	 * `array_is_list()` (PHP 8.0) when available, else {@see self::is_list_php74()}.
	 *
	 * @param array $value Array.
	 * @return bool
	 */
	private static function is_list( array $value ): bool {
		if ( function_exists( 'array_is_list' ) ) {
			return array_is_list( $value );
		}
		return self::is_list_php74( $value );
	}

	/**
	 * PHP 7.4 stand-in for `array_is_list()`: keys are exactly 0..n-1 in order.
	 * An empty array is a list, like the native function.
	 *
	 * Public so the test suite can check it against the native function on a
	 * modern PHP — on PHP 8 it is the branch that never runs in production.
	 *
	 * @param array $value Array.
	 * @return bool
	 */
	public static function is_list_php74( array $value ): bool {
		$expected = 0;
		foreach ( $value as $key => $ignored ) {
			if ( $key !== $expected ) {
				return false;
			}
			++$expected;
		}
		return true;
	}
}
