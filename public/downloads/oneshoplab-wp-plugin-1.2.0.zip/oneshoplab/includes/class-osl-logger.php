<?php
/**
 * Logging through the WooCommerce logger (WooCommerce › Status › Logs, source
 * "oneshoplab"). Site keys and signatures are redacted before anything is written.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Logger facade.
 */
final class OSL_Logger {

	public const SOURCE = 'oneshoplab';

	/**
	 * Writes one entry.
	 *
	 * @param string $level   emergency|alert|critical|error|warning|notice|info|debug.
	 * @param string $message Message.
	 * @param array  $context Extra data (redacted, appended as JSON).
	 */
	public static function log( string $level, string $message, array $context = array() ): void {
		$line = self::redact( $message );
		if ( ! empty( $context ) ) {
			$line .= ' ' . self::redact( (string) wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
		}
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->log( $level, $line, array( 'source' => self::SOURCE ) );
		} elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[oneshoplab][' . $level . '] ' . $line ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	/**
	 * Shorthands.
	 *
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public static function info( string $message, array $context = array() ): void {
		self::log( 'info', $message, $context );
	}

	/**
	 * Warning entry.
	 *
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public static function warning( string $message, array $context = array() ): void {
		self::log( 'warning', $message, $context );
	}

	/**
	 * Error entry.
	 *
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public static function error( string $message, array $context = array() ): void {
		self::log( 'error', $message, $context );
	}

	/**
	 * Debug entry (only stored when WooCommerce log level allows it).
	 *
	 * @param string $message Message.
	 * @param array  $context Context.
	 */
	public static function debug( string $message, array $context = array() ): void {
		self::log( 'debug', $message, $context );
	}

	/**
	 * Masks site keys (keeps the 12-char prefix) and signature values.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	public static function redact( string $text ): string {
		$text = (string) preg_replace( '/(osl_(?:live|test)_[A-Za-z0-9_-]{3})[A-Za-z0-9_-]+/', '$1…', $text );
		$text = (string) preg_replace( '/(v1=)[0-9a-f]{64}/i', '$1[redacted]', $text );
		$text = (string) preg_replace( '/(Bearer\s+)\S+/i', '$1[redacted]', $text );
		return $text;
	}
}
