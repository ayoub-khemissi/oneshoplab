<?php
/**
 * Pull + apply approved changes. Every 5 minutes: GET /changes from the
 * stored cursor; for each change hash the current store value, ack with the
 * hash, and apply only when the server does not answer `conflict`. Images
 * are downloaded before the ack so a broken download becomes a `failed` ack
 * rather than a half-applied gallery.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Changes poller.
 */
final class OSL_Changes {

	public const PAGE_SIZE = 50;

	/**
	 * Registers hooks.
	 */
	public static function init(): void {
		add_action( OSL_Plugin::CRON_POLL_CHANGES, array( __CLASS__, 'poll' ) );
	}

	/**
	 * One poll cycle. Returns a summary for the admin "poll now" button.
	 *
	 * @return array|WP_Error {fetched, applied, failed, skipped, conflict, more}
	 */
	public static function poll() {
		if ( ! OSL_State::can_work() ) {
			return new WP_Error( 'paused', __( 'The plugin is paused (no usable site key or maintenance mode).', 'oneshoplab' ) );
		}
		$client = OSL_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			return $client;
		}

		$page = $client->changes( OSL_State::cursor(), self::PAGE_SIZE );
		if ( is_wp_error( $page ) ) {
			if ( 'validation' === $page->get_error_code() && '' !== OSL_State::cursor() ) {
				OSL_State::set_cursor( '' ); // Cursor rejected: start again from the oldest pending change.
			}
			return $page;
		}

		$changes = isset( $page['changes'] ) && is_array( $page['changes'] ) ? $page['changes'] : array();
		$summary = array(
			'fetched'  => count( $changes ),
			'applied'  => 0,
			'failed'   => 0,
			'skipped'  => 0,
			'conflict' => 0,
			'more'     => ! empty( $page['nextCursor'] ),
		);

		foreach ( $changes as $change ) {
			if ( ! is_array( $change ) || empty( $change['id'] ) ) {
				continue;
			}
			$outcome = self::handle( $client, $change );
			if ( is_wp_error( $outcome ) ) {
				// Ack could not be delivered: keep the cursor here and retry next time.
				break;
			}
			++$summary[ $outcome ];
			OSL_State::set_cursor( (string) $change['id'] );
		}

		OSL_State::update_status(
			array(
				'last_poll'       => time(),
				'pending_changes' => $summary['fetched'] - $summary['applied'] - $summary['failed'] - $summary['skipped'] - $summary['conflict'] + ( $summary['more'] ? self::PAGE_SIZE : 0 ),
				'last_poll_stats' => $summary,
			)
		);
		return $summary;
	}

	/**
	 * Processes one change end to end.
	 *
	 * @param OSL_Client $client Client.
	 * @param array      $change Change payload.
	 * @return string|WP_Error applied|failed|skipped|conflict, or WP_Error when the ack itself failed.
	 */
	private static function handle( OSL_Client $client, array $change ) {
		$id    = (string) $change['id'];
		$field = (string) ( $change['field'] ?? '' );
		$pid   = (int) ( $change['productSourceId'] ?? 0 );

		$acked = OSL_State::acked();
		if ( isset( $acked[ $id ] ) ) {
			// Never re-apply: just repeat the same ack (idempotent) so the server stops listing it.
			$status = 'conflict' === $acked[ $id ] ? 'skipped' : $acked[ $id ];
			$result = $client->ack( $id, array( 'status' => $status ) );
			return is_wp_error( $result ) && 'already_acked' !== $result->get_error_code() ? $result : $acked[ $id ];
		}

		$product = $pid > 0 ? wc_get_product( $pid ) : false;
		if ( ! $product instanceof WC_Product ) {
			return self::finish( $client, $change, 'skipped', __( 'Product not found in WooCommerce.', 'oneshoplab' ) );
		}
		if ( ! in_array( $field, array( 'title', 'description', 'tags', 'images' ), true ) ) {
			return self::finish( $client, $change, 'skipped', __( 'Unsupported field.', 'oneshoplab' ) );
		}

		$raw  = OSL_Product_Mapper::collect( $product );
		$hash = OSL_Hash::value( OSL_Product_Mapper::field_value( $raw, $field ) );

		$prepared = null;
		if ( 'images' === $field ) {
			try {
				$prepared = self::sideload_images( $product, (array) ( $change['value'] ?? array() ) );
			} catch ( Throwable $e ) {
				return self::finish( $client, $change, 'failed', $e->getMessage() );
			}
		}

		$modified = $product->get_date_modified();
		$ack      = $client->ack(
			$id,
			array(
				'status'         => 'applied',
				'storeValueHash' => $hash,
				'storeUpdatedAt' => gmdate( 'Y-m-d\TH:i:s\Z', $modified ? $modified->getTimestamp() : time() ),
			)
		);
		if ( is_wp_error( $ack ) ) {
			self::discard_attachments( $prepared );
			if ( 'already_acked' === $ack->get_error_code() ) {
				return self::record( $change, 'skipped', __( 'Already acknowledged earlier.', 'oneshoplab' ) );
			}
			return $ack;
		}
		if ( 'conflict' === ( $ack['status'] ?? '' ) ) {
			self::discard_attachments( $prepared );
			return self::record( $change, 'conflict', __( 'The product changed in WooCommerce since approval; not applied.', 'oneshoplab' ) );
		}

		try {
			self::apply( $product, $field, $change['value'] ?? null, $prepared );
		} catch ( Throwable $e ) {
			OSL_Logger::error( 'Apply failed after ack', array( 'change' => $id, 'error' => $e->getMessage() ) );
			$client->ack( $id, array( 'status' => 'failed', 'error' => mb_substr( $e->getMessage(), 0, 1000 ) ) ); // Best effort (409 expected).
			return self::record( $change, 'failed', $e->getMessage() );
		}
		return self::record( $change, 'applied', '' );
	}

	/**
	 * Acks a non-applied outcome and records it.
	 *
	 * @param OSL_Client $client  Client.
	 * @param array      $change  Change.
	 * @param string     $status  failed|skipped.
	 * @param string     $message Reason.
	 * @return string|WP_Error
	 */
	private static function finish( OSL_Client $client, array $change, string $status, string $message ) {
		$result = $client->ack(
			(string) $change['id'],
			array(
				'status' => $status,
				'error'  => mb_substr( OSL_Logger::redact( $message ), 0, 1000 ),
			)
		);
		if ( is_wp_error( $result ) && 'already_acked' !== $result->get_error_code() ) {
			return $result;
		}
		return self::record( $change, $status, $message );
	}

	/**
	 * Local bookkeeping.
	 *
	 * @param array  $change  Change.
	 * @param string $status  Outcome.
	 * @param string $message Reason.
	 * @return string Outcome.
	 */
	private static function record( array $change, string $status, string $message ): string {
		OSL_State::remember_ack( (string) $change['id'], $status );
		OSL_State::log_change(
			array(
				'id'         => (string) $change['id'],
				'product_id' => (int) ( $change['productSourceId'] ?? 0 ),
				'field'      => (string) ( $change['field'] ?? '' ),
				'status'     => $status,
				'message'    => OSL_Logger::redact( $message ),
				'at'         => time(),
			)
		);
		OSL_Logger::info( "Change {$change['id']} {$status}", array( 'field' => $change['field'] ?? '', 'product' => $change['productSourceId'] ?? '' ) );
		return $status;
	}

	/**
	 * Writes the value into the product.
	 *
	 * @param WC_Product $product  Product.
	 * @param string     $field    Field.
	 * @param mixed      $value    New value.
	 * @param int[]|null $prepared Attachment ids for images.
	 * @throws RuntimeException When WordPress refuses the update.
	 */
	private static function apply( WC_Product $product, string $field, $value, ?array $prepared ): void {
		switch ( $field ) {
			case 'title':
				$product->set_name( wp_strip_all_tags( (string) $value ) );
				break;
			case 'description':
				$product->set_description( wp_kses_post( (string) $value ) );
				break;
			case 'tags':
				$names  = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', (array) $value ) ) ) );
				$result = wp_set_object_terms( $product->get_id(), $names, 'product_tag', false );
				if ( is_wp_error( $result ) ) {
					throw new RuntimeException( $result->get_error_message() );
				}
				$ids = wp_get_object_terms( $product->get_id(), 'product_tag', array( 'fields' => 'ids' ) );
				$product->set_tag_ids( is_array( $ids ) ? $ids : array() );
				break;
			case 'images':
				$ids = array_values( (array) $prepared );
				$product->set_image_id( $ids[0] ?? 0 );
				$product->set_gallery_image_ids( array_slice( $ids, 1 ) );
				break;
		}
		$product->save();
	}

	/**
	 * Downloads every image into the media library (never hot-linked).
	 *
	 * @param WC_Product $product Product (owner of the attachments).
	 * @param array      $images  `[{src, alt}]` or `[src]`.
	 * @return int[] Attachment ids in order.
	 * @throws RuntimeException On download failure.
	 */
	private static function sideload_images( WC_Product $product, array $images ): array {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$ids = array();
		foreach ( $images as $image ) {
			$src = is_array( $image ) ? (string) ( $image['src'] ?? '' ) : (string) $image;
			$alt = is_array( $image ) ? (string) ( $image['alt'] ?? '' ) : '';
			if ( '' === $src || ! wp_http_validate_url( $src ) ) {
				continue;
			}
			$attachment_id = media_sideload_image( $src, $product->get_id(), $product->get_name(), 'id' );
			if ( is_wp_error( $attachment_id ) ) {
				self::discard_attachments( $ids );
				/* translators: %s: error message */
				throw new RuntimeException( sprintf( __( 'Image download failed: %s', 'oneshoplab' ), $attachment_id->get_error_message() ) );
			}
			if ( '' !== $alt ) {
				update_post_meta( (int) $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
			}
			$ids[] = (int) $attachment_id;
		}
		if ( empty( $ids ) ) {
			throw new RuntimeException( __( 'No usable image in the change.', 'oneshoplab' ) );
		}
		return $ids;
	}

	/**
	 * Deletes attachments created for a change that was not applied.
	 *
	 * @param int[]|null $ids Attachment ids.
	 */
	private static function discard_attachments( ?array $ids ): void {
		foreach ( (array) $ids as $id ) {
			wp_delete_attachment( (int) $id, true );
		}
	}
}
