<?php
/**
 * Catalogue push. Product saves land in a transient queue (debounce) flushed
 * by a 1-minute cron in batches of 200 (`mode: partial`); trash/delete/
 * unpublish archive. The full sync walks the catalogue in pages of 200 with
 * the server-side session protocol so unseen products get archived only on
 * the final page.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sync engine.
 */
final class OSL_Sync {

	/**
	 * Registers hooks.
	 */
	public static function init(): void {
		add_action( 'woocommerce_new_product', array( __CLASS__, 'on_product_saved' ) );
		add_action( 'woocommerce_update_product', array( __CLASS__, 'on_product_saved' ) );
		add_action( 'woocommerce_new_product_variation', array( __CLASS__, 'on_variation_saved' ) );
		add_action( 'woocommerce_update_product_variation', array( __CLASS__, 'on_variation_saved' ) );
		add_action( 'save_post_product', array( __CLASS__, 'on_save_post' ), 10, 2 );
		add_action( 'trashed_post', array( __CLASS__, 'on_trashed' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'on_untrashed' ) );
		add_action( 'before_delete_post', array( __CLASS__, 'on_deleted' ), 10, 2 );
		add_action( 'woocommerce_product_set_stock', array( __CLASS__, 'on_product_object' ) );
		add_action( 'woocommerce_variation_set_stock', array( __CLASS__, 'on_variation_object' ) );

		add_action( OSL_Plugin::CRON_FLUSH_QUEUE, array( __CLASS__, 'flush_queue' ) );
		add_action( OSL_Plugin::CRON_FULL_SYNC_STEP, array( __CLASS__, 'full_sync_step' ) );
	}

	/* ---------------------------------------------------------------- hooks */

	/**
	 * Product created/updated through the WC CRUD layer.
	 *
	 * @param int $product_id Product id.
	 */
	public static function on_product_saved( $product_id ): void {
		self::enqueue_product( (int) $product_id );
	}

	/**
	 * Variation saved → parent re-sent.
	 *
	 * @param int $variation_id Variation id.
	 */
	public static function on_variation_saved( $variation_id ): void {
		$parent = (int) wp_get_post_parent_id( (int) $variation_id );
		if ( $parent > 0 ) {
			self::enqueue_product( $parent );
		}
	}

	/**
	 * Stock change on a product object.
	 *
	 * @param WC_Product $product Product.
	 */
	public static function on_product_object( $product ): void {
		if ( $product instanceof WC_Product ) {
			self::enqueue_product( $product->get_id() );
		}
	}

	/**
	 * Stock change on a variation object.
	 *
	 * @param WC_Product $variation Variation.
	 */
	public static function on_variation_object( $variation ): void {
		if ( $variation instanceof WC_Product ) {
			self::enqueue_product( (int) $variation->get_parent_id() );
		}
	}

	/**
	 * Classic editor / REST / quick edit saves.
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post    Post.
	 */
	public static function on_save_post( $post_id, $post ): void {
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( ! $post instanceof WP_Post || 'product' !== $post->post_type ) {
			return;
		}
		self::enqueue_product( (int) $post_id );
	}

	/**
	 * Trashed → archive.
	 *
	 * @param int $post_id Post id.
	 */
	public static function on_trashed( $post_id ): void {
		if ( 'product' === get_post_type( $post_id ) ) {
			self::enqueue( (string) $post_id, 'archive' );
		}
	}

	/**
	 * Untrashed → re-upsert (if it comes back published).
	 *
	 * @param int $post_id Post id.
	 */
	public static function on_untrashed( $post_id ): void {
		if ( 'product' === get_post_type( $post_id ) ) {
			self::enqueue_product( (int) $post_id );
		}
	}

	/**
	 * Permanently deleted → archive.
	 *
	 * @param int          $post_id Post id.
	 * @param WP_Post|null $post    Post.
	 */
	public static function on_deleted( $post_id, $post = null ): void {
		$type = $post instanceof WP_Post ? $post->post_type : get_post_type( $post_id );
		if ( 'product' === $type ) {
			self::enqueue( (string) $post_id, 'archive' );
		}
	}

	/* ---------------------------------------------------------------- queue */

	/**
	 * Decides upsert vs archive from the product's current state, then queues.
	 *
	 * @param int $product_id Product id.
	 */
	public static function enqueue_product( int $product_id ): void {
		if ( $product_id <= 0 || ! OSL_State::has_key() ) {
			return;
		}
		$product = wc_get_product( $product_id );
		if ( ! $product instanceof WC_Product || $product->is_type( 'variation' ) ) {
			return;
		}
		self::enqueue( (string) $product_id, self::is_syncable( $product ) ? 'upsert' : 'archive' );
	}

	/**
	 * Published, not hidden from the catalogue.
	 *
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public static function is_syncable( WC_Product $product ): bool {
		$ok = 'publish' === $product->get_status() && 'hidden' !== $product->get_catalog_visibility();
		/**
		 * Lets a site exclude products from OneShopLab.
		 *
		 * @param bool       $ok      Whether the product is sent.
		 * @param WC_Product $product Product.
		 */
		return (bool) apply_filters( 'oneshoplab_is_product_syncable', $ok, $product );
	}

	/**
	 * Adds an entry to the debounced queue (last action wins).
	 *
	 * @param string $source_id Product id as string.
	 * @param string $action    upsert|archive.
	 */
	public static function enqueue( string $source_id, string $action ): void {
		if ( ! OSL_State::has_key() ) {
			return;
		}
		$queue               = OSL_State::queue();
		$queue[ $source_id ] = $action;
		OSL_State::set_queue( $queue );
	}

	/**
	 * Cron (every minute): sends up to 200 upserts in one request + the archives.
	 * Anything left (or failed) stays in the queue for the next run.
	 */
	public static function flush_queue(): void {
		$queue = OSL_State::queue();
		if ( empty( $queue ) || ! OSL_State::can_work() ) {
			return;
		}
		if ( get_transient( OSL_State::TR_FULL_SYNC ) ) {
			return; // The full sync will cover everything; avoid a 409 sync_in_progress.
		}
		$client = OSL_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			return;
		}

		$upserts  = array();
		$archives = array();
		foreach ( $queue as $source_id => $action ) {
			if ( 'archive' === $action ) {
				$archives[] = (string) $source_id;
			} elseif ( count( $upserts ) < OSL_BATCH_SIZE ) {
				$upserts[] = (string) $source_id;
			}
		}

		if ( ! empty( $upserts ) ) {
			$products = array();
			foreach ( $upserts as $source_id ) {
				$product = wc_get_product( (int) $source_id );
				if ( $product instanceof WC_Product && self::is_syncable( $product ) ) {
					$products[] = OSL_Product_Mapper::map( $product );
				} else {
					$archives[] = $source_id; // Vanished or unpublished since it was queued.
				}
				unset( $queue[ $source_id ] );
			}
			if ( ! empty( $products ) ) {
				$result = $client->sync_products(
					array(
						'mode'     => 'partial',
						'products' => $products,
					)
				);
				if ( is_wp_error( $result ) ) {
					if ( self::is_retryable( $result ) ) {
						foreach ( $upserts as $source_id ) {
							$queue[ $source_id ] = 'upsert';
						}
					}
					OSL_State::set_queue( $queue );
					return;
				}
				self::record_sync_result( $result, 'partial', count( $products ) );
			}
		}

		foreach ( array_unique( $archives ) as $source_id ) {
			$result = $client->archive_product( $source_id );
			if ( is_wp_error( $result ) && 'not_found' !== $result->get_error_code() ) {
				if ( ! self::is_retryable( $result ) ) {
					unset( $queue[ $source_id ] );
				}
				OSL_State::set_queue( $queue );
				return;
			}
			unset( $queue[ $source_id ] );
		}
		OSL_State::set_queue( $queue );
	}

	/**
	 * Errors worth retrying on the next cron tick.
	 *
	 * @param WP_Error $error Error.
	 * @return bool
	 */
	private static function is_retryable( WP_Error $error ): bool {
		return in_array( $error->get_error_code(), array( 'network', 'internal', 'rate_limited', 'locked', 'sync_in_progress' ), true );
	}

	/**
	 * Updates the status card after a successful batch.
	 *
	 * @param array  $result Sync response.
	 * @param string $mode   partial|full.
	 * @param int    $sent   Products in the batch.
	 */
	private static function record_sync_result( array $result, string $mode, int $sent ): void {
		OSL_State::update_status(
			array(
				'last_sync'        => time(),
				'last_sync_mode'   => $mode,
				'last_sync_sent'   => $sent,
				'last_sync_result' => array(
					'inserted'  => (int) ( $result['inserted'] ?? 0 ),
					'updated'   => (int) ( $result['updated'] ?? 0 ),
					'archived'  => (int) ( $result['archived'] ?? 0 ),
					'unchanged' => (int) ( $result['unchanged'] ?? 0 ),
					'errors'    => count( (array) ( $result['errors'] ?? array() ) ),
				),
			)
		);
		if ( ! empty( $result['errors'] ) ) {
			OSL_Logger::warning( 'Some products were rejected', array( 'errors' => $result['errors'] ) );
		}
		OSL_Logger::info( "Sync {$mode}: {$sent} sent", array_intersect_key( $result, array_flip( array( 'inserted', 'updated', 'archived', 'unchanged' ) ) ) );
	}

	/* ------------------------------------------------------------ full sync */

	/**
	 * Starts a full sync (runs page by page through single cron events).
	 *
	 * @return true|WP_Error
	 */
	public static function start_full_sync() {
		if ( ! OSL_State::has_key() ) {
			return new WP_Error( 'no_key', OSL_Client::explain( 'no_key' ) );
		}
		if ( get_transient( OSL_State::TR_FULL_SYNC ) ) {
			return new WP_Error( 'sync_in_progress', OSL_Client::explain( 'sync_in_progress' ) );
		}
		$total = self::count_products();
		set_transient(
			OSL_State::TR_FULL_SYNC,
			array(
				'session' => null,
				'page'    => 1,
				'total'   => $total,
				'sent'    => 0,
				'started' => time(),
			),
			30 * MINUTE_IN_SECONDS
		);
		OSL_State::update_status( array( 'product_count' => $total ) );
		wp_schedule_single_event( time(), OSL_Plugin::CRON_FULL_SYNC_STEP );
		spawn_cron();
		return true;
	}

	/**
	 * One page of the full sync; reschedules itself until the final page.
	 */
	public static function full_sync_step(): void {
		$state = get_transient( OSL_State::TR_FULL_SYNC );
		if ( ! is_array( $state ) ) {
			return;
		}
		if ( ! OSL_State::can_work() ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, OSL_Plugin::CRON_FULL_SYNC_STEP );
			return;
		}
		$client = OSL_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			delete_transient( OSL_State::TR_FULL_SYNC );
			return;
		}

		$page     = (int) $state['page'];
		$products = array();
		$ids      = wc_get_products(
			array(
				'status'  => 'publish',
				'limit'   => OSL_BATCH_SIZE,
				'page'    => $page,
				'orderby' => 'ID',
				'order'   => 'ASC',
				'return'  => 'ids',
			)
		);
		foreach ( (array) $ids as $id ) {
			$product = wc_get_product( (int) $id );
			if ( $product instanceof WC_Product && self::is_syncable( $product ) ) {
				$products[] = OSL_Product_Mapper::map( $product );
			}
		}
		$final = count( (array) $ids ) < OSL_BATCH_SIZE;

		$body = array(
			'mode'     => 'full',
			'final'    => $final,
			'products' => $products,
		);
		if ( ! empty( $state['session'] ) ) {
			$body['session'] = (string) $state['session'];
		}

		$result = $client->sync_products( $body );
		if ( is_wp_error( $result ) ) {
			if ( self::is_retryable( $result ) ) {
				set_transient( OSL_State::TR_FULL_SYNC, $state, 30 * MINUTE_IN_SECONDS );
				wp_schedule_single_event( time() + 2 * MINUTE_IN_SECONDS, OSL_Plugin::CRON_FULL_SYNC_STEP );
			} else {
				delete_transient( OSL_State::TR_FULL_SYNC );
				OSL_Logger::error( 'Full sync aborted', array( 'code' => $result->get_error_code() ) );
			}
			return;
		}

		$state['sent'] += count( $products );
		self::record_sync_result( $result, 'full', $state['sent'] );

		if ( $final ) {
			delete_transient( OSL_State::TR_FULL_SYNC );
			OSL_State::update_status(
				array(
					'product_count'  => $state['sent'],
					'last_full_sync' => time(),
				)
			);
			return;
		}
		$state['session'] = isset( $result['session'] ) ? (string) $result['session'] : $state['session'];
		$state['page']    = $page + 1;
		set_transient( OSL_State::TR_FULL_SYNC, $state, 30 * MINUTE_IN_SECONDS );
		wp_schedule_single_event( time(), OSL_Plugin::CRON_FULL_SYNC_STEP );
		spawn_cron();
	}

	/**
	 * Published products (parents only).
	 *
	 * @return int
	 */
	public static function count_products(): int {
		$counts = wp_count_posts( 'product' );
		return isset( $counts->publish ) ? (int) $counts->publish : 0;
	}

	/**
	 * Full-sync progress, or null.
	 *
	 * @return array|null
	 */
	public static function full_sync_state(): ?array {
		$state = get_transient( OSL_State::TR_FULL_SYNC );
		return is_array( $state ) ? $state : null;
	}
}
