<?php
/**
 * Site key at rest: AES-256-GCM with a key derived from the WordPress salts.
 *
 * Storage format: `v1:` + base64( iv(12) . tag(16) . ciphertext ).
 * If the salts change (wp-config edit) decryption fails and the merchant is
 * asked to paste the key again — the key is never recoverable from the DB alone.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Encrypt/decrypt helpers.
 */
final class OSL_Crypto {

	private const CIPHER = 'aes-256-gcm';
	private const PREFIX = 'v1:';

	/**
	 * 32-byte key derived from the auth salts.
	 *
	 * @return string
	 */
	private static function key(): string {
		return hash( 'sha256', wp_salt( 'auth' ) . '|' . wp_salt( 'secure_auth' ) . '|oneshoplab', true );
	}

	/**
	 * Encrypts a secret for storage.
	 *
	 * @param string $plain Secret.
	 * @return string|null Null when openssl is unavailable or fails.
	 */
	public static function encrypt( string $plain ): ?string {
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return null;
		}
		$iv  = random_bytes( 12 );
		$tag = '';
		$ct  = openssl_encrypt( $plain, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16 );
		if ( false === $ct ) {
			return null;
		}
		return self::PREFIX . base64_encode( $iv . $tag . $ct ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Decrypts a stored secret.
	 *
	 * @param string $stored Stored value.
	 * @return string|null Null when malformed, tampered or the salts changed.
	 */
	public static function decrypt( string $stored ): ?string {
		if ( ! function_exists( 'openssl_decrypt' ) || 0 !== strpos( $stored, self::PREFIX ) ) {
			return null;
		}
		$raw = base64_decode( substr( $stored, strlen( self::PREFIX ) ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( false === $raw || strlen( $raw ) < 28 ) {
			return null;
		}
		$plain = openssl_decrypt( substr( $raw, 28 ), self::CIPHER, self::key(), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) );
		return false === $plain ? null : $plain;
	}
}
