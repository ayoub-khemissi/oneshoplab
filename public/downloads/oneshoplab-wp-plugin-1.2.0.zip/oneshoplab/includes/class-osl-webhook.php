<?php
/**
 * Inbound webhooks (OneShopLab → this site): immediate change delivery.
 *
 * Registration: `PUT /api/v1/webhooks/self { url, events }` on key save, on
 * activation and daily (cron). The returned secret is stored encrypted like
 * the site key. `DELETE /api/v1/webhooks/self` on key change / removal and
 * on deactivation (best effort).
 *
 * Receiver: `POST /wp-json/oneshoplab/v1/webhook`, authenticated only by
 * `X-OSL-Signature: v1=<hex HMAC-SHA256(secret, "<X-OSL-Timestamp>.<rawBody>")>`
 * (constant-time), timestamp within ±300 s, deduplicated on `X-OSL-Event-Id`
 * for 24 h. A `change.*` event only schedules an immediate run of the
 * regular changes poll — the payload is never applied directly, the pull is
 * the single write path. The 5-minute poll stays as the fallback.
 *
 * The static helpers `verify()`, `dedupe_key()` and `registration_payload()`
 * are pure PHP (unit-tested without WordPress).
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Webhook registration + receiver.
 */
final class OSL_Webhook {

	public const REST_NAMESPACE = 'oneshoplab/v1';
	public const REST_ROUTE     = '/webhook';

	/** Events the plugin subscribes to. */
	// 'ping' is a delivery kind the server always sends — not a subscribable event.
	public const EVENTS = array( 'change.approved', 'change.cancelled' );

	/** Accepted clock difference between OneShopLab and this server, in seconds. */
	public const TOLERANCE = 300;

	/** How long an event id is remembered (seconds). */
	public const DEDUPE_TTL = 86400;

	/** Transient name prefix for the dedupe memory. */
	public const DEDUPE_PREFIX = 'oneshoplab_evt_';

	/** Registration states shown on the settings page. */
	public const STATE_ACTIVE    = 'active';
	public const STATE_FORBIDDEN = 'forbidden';
	public const STATE_ERROR     = 'error';
	public const STATE_OFF       = 'off';

	/**
	 * Registers hooks.
	 */
	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_route' ) );
		add_action( OSL_Plugin::CRON_WEBHOOK_REGISTER, array( __CLASS__, 'cron_register' ) );
		add_action( OSL_Plugin::CRON_POLL_NOW, array( 'OSL_Changes', 'poll' ) );
	}

	/* ---------------------------------------------------------------------
	 * Pure helpers (no WordPress).
	 * ------------------------------------------------------------------ */

	/**
	 * Body of `PUT /api/v1/webhooks/self`.
	 *
	 * @param string $url Public URL of the receiver.
	 * @return array{url:string,events:string[]}
	 */
	public static function registration_payload( string $url ): array {
		return array(
			'url'    => $url,
			'events' => self::EVENTS,
		);
	}

	/**
	 * The string OneShopLab signs: "<timestamp>.<rawBody>".
	 *
	 * @param string $timestamp Value of X-OSL-Timestamp, verbatim.
	 * @param string $raw_body  Raw request body.
	 * @return string
	 */
	public static function signed_payload( string $timestamp, string $raw_body ): string {
		return $timestamp . '.' . $raw_body;
	}

	/**
	 * Hex HMAC-SHA256 the way the sender computes it.
	 *
	 * @param string $secret    Webhook secret.
	 * @param string $timestamp X-OSL-Timestamp.
	 * @param string $raw_body  Raw body.
	 * @return string
	 */
	public static function sign( string $secret, string $timestamp, string $raw_body ): string {
		return hash_hmac( 'sha256', self::signed_payload( $timestamp, $raw_body ), $secret );
	}

	/**
	 * Extracts the `v1` value from `v1=<hex>` (also tolerates `t=…,v1=…`).
	 *
	 * @param string $header X-OSL-Signature.
	 * @return string|null Lower-case hex, or null when absent/malformed.
	 */
	public static function parse_signature( string $header ): ?string {
		foreach ( explode( ',', $header ) as $part ) {
			$part = trim( $part );
			if ( 0 === strncasecmp( $part, 'v1=', 3 ) ) {
				$hex = strtolower( substr( $part, 3 ) );
				return 1 === preg_match( '/^[0-9a-f]{64}$/', $hex ) ? $hex : null;
			}
		}
		return null;
	}

	/**
	 * Parses X-OSL-Timestamp: unix seconds, unix milliseconds or ISO-8601.
	 *
	 * @param string $timestamp Header value.
	 * @return int|null Unix seconds or null when unreadable.
	 */
	public static function parse_timestamp( string $timestamp ): ?int {
		$timestamp = trim( $timestamp );
		if ( '' === $timestamp ) {
			return null;
		}
		if ( 1 === preg_match( '/^\d{1,13}$/', $timestamp ) ) {
			$n = (int) $timestamp;
			return $n > 99999999999 ? intdiv( $n, 1000 ) : $n;
		}
		$parsed = strtotime( $timestamp );
		return false === $parsed ? null : $parsed;
	}

	/**
	 * Verifies a delivery. Returns null when valid, else a short error code:
	 * `missing_signature`, `bad_timestamp`, `expired`, `invalid_signature`.
	 *
	 * @param string   $secret     Stored webhook secret.
	 * @param string   $timestamp  X-OSL-Timestamp header.
	 * @param string   $raw_body   Raw body exactly as received.
	 * @param string   $signature  X-OSL-Signature header.
	 * @param int|null $now        Current unix time (defaults to time()).
	 * @return string|null
	 */
	public static function verify( string $secret, string $timestamp, string $raw_body, string $signature, ?int $now = null ): ?string {
		$given = self::parse_signature( $signature );
		if ( null === $given || '' === $secret ) {
			return 'missing_signature';
		}
		$ts = self::parse_timestamp( $timestamp );
		if ( null === $ts ) {
			return 'bad_timestamp';
		}
		if ( abs( ( $now ?? time() ) - $ts ) > self::TOLERANCE ) {
			return 'expired';
		}
		// Compare the raw header value: the HMAC covers the timestamp string verbatim.
		if ( ! hash_equals( self::sign( $secret, trim( $timestamp ), $raw_body ), $given ) ) {
			return 'invalid_signature';
		}
		return null;
	}

	/**
	 * Transient name remembering an event id (bounded length, safe charset).
	 *
	 * @param string $event_id X-OSL-Event-Id.
	 * @return string
	 */
	public static function dedupe_key( string $event_id ): string {
		return self::DEDUPE_PREFIX . hash( 'sha256', $event_id );
	}

	/* ---------------------------------------------------------------------
	 * Receiver.
	 * ------------------------------------------------------------------ */

	/**
	 * Registers the REST route. Authentication is the signature, hence
	 * `__return_true` as permission callback.
	 */
	public static function register_route(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			self::REST_ROUTE,
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'receive' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Public URL of the receiver.
	 *
	 * @return string
	 */
	public static function endpoint_url(): string {
		return rest_url( self::REST_NAMESPACE . self::REST_ROUTE );
	}

	/**
	 * Handles one delivery. Always fast: verify, dedupe, schedule, answer.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function receive( WP_REST_Request $request ): WP_REST_Response {
		$raw       = (string) $request->get_body();
		$signature = (string) $request->get_header( 'x_osl_signature' );
		$timestamp = (string) $request->get_header( 'x_osl_timestamp' );
		$secret    = OSL_State::webhook_secret();

		$problem = self::verify( (string) $secret, $timestamp, $raw, $signature );
		if ( null !== $problem ) {
			OSL_Logger::warning( 'Webhook rejected', array( 'reason' => $problem, 'event' => (string) $request->get_header( 'x_osl_event' ) ) );
			return new WP_REST_Response(
				array(
					'error' => array(
						'code'    => $problem,
						'message' => 'Signature verification failed.',
					),
				),
				401
			);
		}

		$data     = json_decode( $raw, true );
		$data     = is_array( $data ) ? $data : array();
		$event    = (string) ( $request->get_header( 'x_osl_event' ) ?: ( $data['event'] ?? '' ) );
		$event_id = (string) ( $request->get_header( 'x_osl_event_id' ) ?: ( $data['id'] ?? '' ) );

		if ( '' !== $event_id ) {
			$key = self::dedupe_key( $event_id );
			if ( false !== get_transient( $key ) ) {
				return new WP_REST_Response(
					array(
						'ok'        => true,
						'duplicate' => true,
					),
					200
				);
			}
			set_transient( $key, time(), self::DEDUPE_TTL );
		}

		OSL_State::update_status( array( 'webhook_last_event' => time() ) );

		if ( 'ping' === $event ) {
			OSL_State::update_status( array( 'webhook_last_ping' => time() ) );
			return new WP_REST_Response(
				array(
					'ok'      => true,
					'version' => OSL_VERSION,
				),
				200
			);
		}

		$queued = false;
		if ( 0 === strncmp( $event, 'change.', 7 ) ) {
			$queued = self::schedule_poll_now();
		}
		OSL_Logger::debug( 'Webhook received', array( 'event' => $event, 'id' => $event_id, 'queued' => $queued ) );

		return new WP_REST_Response(
			array(
				'ok'     => true,
				'queued' => $queued,
			),
			200
		);
	}

	/**
	 * Schedules the changes poll to run right away (single event) and kicks
	 * WP-Cron so it does not wait for the next visitor.
	 *
	 * @return bool True when a run is scheduled (already pending counts).
	 */
	public static function schedule_poll_now(): bool {
		if ( ! OSL_State::can_work() ) {
			return false;
		}
		if ( ! wp_next_scheduled( OSL_Plugin::CRON_POLL_NOW ) ) {
			$scheduled = wp_schedule_single_event( time(), OSL_Plugin::CRON_POLL_NOW );
			if ( true !== $scheduled ) {
				return false;
			}
		}
		if ( function_exists( 'spawn_cron' ) && ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ) {
			spawn_cron();
		}
		return true;
	}

	/* ---------------------------------------------------------------------
	 * Registration with OneShopLab.
	 * ------------------------------------------------------------------ */

	/**
	 * Registers (or re-registers) this site's endpoint. Stores the returned
	 * secret; on 403 `forbidden` switches to polling mode with a note.
	 *
	 * @param OSL_Client|null $client Client (defaults to the stored key).
	 * @return bool True when the webhook is active.
	 */
	public static function register( ?OSL_Client $client = null ): bool {
		$client = $client ?? OSL_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			return false;
		}
		$result = $client->register_webhook( self::registration_payload( self::endpoint_url() ), true );
		if ( is_wp_error( $result ) ) {
			$code = $result->get_error_code();
			if ( 'forbidden' === $code ) {
				OSL_State::clear_webhook_secret();
				self::set_state( self::STATE_FORBIDDEN, $code, '' );
				OSL_Logger::warning( 'Webhook registration refused: key has no webhooks:manage permission' );
				return false;
			}
			// Keep any previous secret: a failed PUT did not rotate it server-side.
			self::set_state( null === OSL_State::webhook_secret() ? self::STATE_ERROR : self::STATE_ACTIVE, $code, OSL_Client::explain( $code, $result->get_error_message() ) );
			return null !== OSL_State::webhook_secret();
		}
		$secret = isset( $result['secret'] ) ? (string) $result['secret'] : '';
		if ( '' === $secret || ! OSL_State::save_webhook_secret( $secret ) ) {
			self::set_state( self::STATE_ERROR, 'no_secret', __( 'OneShopLab did not return a webhook secret.', 'oneshoplab' ) );
			return false;
		}
		self::set_state( self::STATE_ACTIVE, '', '' );
		OSL_State::update_status(
			array(
				'webhook_id'            => isset( $result['id'] ) ? (string) $result['id'] : '',
				'webhook_registered_at' => time(),
			)
		);
		OSL_Logger::info( 'Webhook registered', array( 'url' => self::endpoint_url() ) );
		return true;
	}

	/**
	 * Best-effort `DELETE /webhooks/self`, then forgets the secret.
	 *
	 * @param OSL_Client|null $client Client for the key to unregister with.
	 */
	public static function unregister( ?OSL_Client $client = null ): void {
		$client = $client ?? OSL_Client::from_settings();
		if ( ! is_wp_error( $client ) && null !== OSL_State::webhook_secret() ) {
			$client->unregister_webhook();
		}
		OSL_State::clear_webhook_secret();
		self::set_state( self::STATE_OFF, '', '' );
	}

	/**
	 * `POST /webhooks/self/ping`: asks OneShopLab to send a `ping` event.
	 *
	 * @return true|WP_Error
	 */
	public static function request_ping() {
		$client = OSL_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			return $client;
		}
		$result = $client->ping_webhook();
		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * Daily cron: re-register so a lost/disabled webhook heals itself.
	 */
	public static function cron_register(): void {
		if ( ! OSL_State::can_work() ) {
			return;
		}
		if ( self::STATE_FORBIDDEN === self::state() && ! empty( OSL_State::status()['webhook_checked_at'] ) ) {
			// The key has no webhook permission; nothing changes until a new key is saved.
			return;
		}
		self::register();
	}

	/**
	 * Current registration state.
	 *
	 * @return string One of the STATE_* values.
	 */
	public static function state(): string {
		$state = OSL_State::status()['webhook_state'] ?? self::STATE_OFF;
		if ( self::STATE_ACTIVE === $state && null === OSL_State::webhook_secret() ) {
			return self::STATE_ERROR;
		}
		return (string) $state;
	}

	/**
	 * Whether deliveries can currently be authenticated.
	 *
	 * @return bool
	 */
	public static function is_active(): bool {
		return self::STATE_ACTIVE === self::state();
	}

	/**
	 * Stores the state on the status card.
	 *
	 * @param string $state   STATE_* value.
	 * @param string $code    Error code or ''.
	 * @param string $message Merchant-facing message or ''.
	 */
	private static function set_state( string $state, string $code, string $message ): void {
		OSL_State::update_status(
			array(
				'webhook_state'      => $state,
				'webhook_error'      => '' === $code ? null : array(
					'code'    => $code,
					'message' => OSL_Logger::redact( $message ),
				),
				'webhook_checked_at' => time(),
			)
		);
	}
}
