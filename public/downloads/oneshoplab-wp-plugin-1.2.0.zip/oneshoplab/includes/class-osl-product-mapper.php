<?php
/**
 * WooCommerce product → OneShopLab `Product` shape.
 *
 * Two layers: {@see OSL_Product_Mapper::collect()} reads WooCommerce (needs WP),
 * {@see OSL_Product_Mapper::build()} normalises a plain array into the API
 * shape (pure PHP, unit-tested). {@see OSL_Product_Mapper::field_value()}
 * returns the canonical current value of a change field, hashed for
 * conflict detection — it must match what the last sync sent.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product mapping.
 */
final class OSL_Product_Mapper {

	public const MAX_TITLE       = 512;
	public const MAX_DESCRIPTION = 65536; // bytes.
	public const MAX_IMAGES      = 30;
	public const MAX_TAGS        = 50;
	public const MAX_TAG_LENGTH  = 64;
	public const MAX_SHORT       = 255;

	/**
	 * Reads everything the mapping needs from a WooCommerce product.
	 *
	 * @param WC_Product $product Product (any type but variation).
	 * @return array Raw data for {@see self::build()}.
	 */
	public static function collect( WC_Product $product ): array {
		$image_ids = array_merge( array( (int) $product->get_image_id() ), array_map( 'intval', (array) $product->get_gallery_image_ids() ) );
		$images    = array();
		foreach ( array_unique( array_filter( $image_ids ) ) as $attachment_id ) {
			$src = wp_get_attachment_url( $attachment_id );
			if ( ! $src ) {
				continue;
			}
			$meta     = wp_get_attachment_metadata( $attachment_id );
			$images[] = array(
				'src'    => $src,
				'alt'    => (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
				'width'  => isset( $meta['width'] ) ? (int) $meta['width'] : null,
				'height' => isset( $meta['height'] ) ? (int) $meta['height'] : null,
			);
		}

		$tags = wp_get_post_terms( $product->get_id(), 'product_tag', array( 'fields' => 'names' ) );
		$cats = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );

		$vendor = null;
		if ( taxonomy_exists( 'product_brand' ) ) {
			$brands = wp_get_post_terms( $product->get_id(), 'product_brand', array( 'fields' => 'names' ) );
			$vendor = ( is_array( $brands ) && ! empty( $brands ) ) ? (string) $brands[0] : null;
		}
		/**
		 * Overrides the vendor/brand sent to OneShopLab (e.g. from a third-party brand plugin).
		 *
		 * @param string|null $vendor  Brand name.
		 * @param WC_Product  $product Product.
		 */
		$vendor = apply_filters( 'oneshoplab_product_vendor', $vendor, $product );

		$variants = array();
		if ( $product->is_type( 'variable' ) ) {
			foreach ( (array) $product->get_children() as $child_id ) {
				$variation = wc_get_product( $child_id );
				if ( ! $variation instanceof WC_Product_Variation ) {
					continue;
				}
				$options = array();
				foreach ( (array) $variation->get_variation_attributes() as $attr => $val ) {
					$name = wc_attribute_label( str_replace( 'attribute_', '', (string) $attr ), $product );
					if ( '' !== (string) $val ) {
						$options[ $name ] = (string) $val;
					}
				}
				$variants[] = array(
					'id'        => (string) $child_id,
					'title'     => $variation->get_name(),
					'sku'       => $variation->get_sku(),
					'price'     => $variation->get_price(),
					'available' => $variation->is_in_stock() && $variation->is_purchasable(),
					'options'   => $options,
				);
			}
			$price_min = $product->get_variation_price( 'min' );
			$price_max = $product->get_variation_price( 'max' );
		} else {
			$variants[] = array(
				'id'        => (string) $product->get_id(),
				'title'     => $product->get_name(),
				'sku'       => $product->get_sku(),
				'price'     => $product->get_price(),
				'available' => $product->is_in_stock() && $product->is_purchasable(),
				'options'   => array(),
			);
			$price_min  = $product->get_price();
			$price_max  = $price_min;
		}

		$modified = $product->get_date_modified();

		return array(
			'id'          => $product->get_id(),
			'permalink'   => $product->get_permalink(),
			'slug'        => $product->get_slug(),
			'name'        => $product->get_name(),
			'description' => $product->get_description(),
			'images'      => $images,
			'tags'        => is_array( $tags ) ? $tags : array(),
			'category'    => ( is_array( $cats ) && ! empty( $cats ) ) ? (string) $cats[0] : null,
			'vendor'      => $vendor,
			'variants'    => $variants,
			'price_min'   => $price_min,
			'price_max'   => $price_max,
			'currency'    => get_woocommerce_currency(),
			'sku'         => $product->get_sku(),
			'modified'    => $modified ? $modified->getTimestamp() : null,
		);
	}

	/**
	 * Collect + build.
	 *
	 * @param WC_Product $product Product.
	 * @return array API product.
	 */
	public static function map( WC_Product $product ): array {
		return self::build( self::collect( $product ) );
	}

	/**
	 * Normalises raw data into the API `Product` shape (caps, types, nulls).
	 *
	 * @param array $raw Output of {@see self::collect()}.
	 * @return array
	 */
	public static function build( array $raw ): array {
		$images = array();
		foreach ( array_slice( (array) ( $raw['images'] ?? array() ), 0, self::MAX_IMAGES ) as $i => $img ) {
			if ( empty( $img['src'] ) ) {
				continue;
			}
			$images[] = array(
				'src'      => (string) $img['src'],
				'alt'      => self::nullable_string( $img['alt'] ?? null, 1024 ),
				'width'    => isset( $img['width'] ) ? (int) $img['width'] : null,
				'height'   => isset( $img['height'] ) ? (int) $img['height'] : null,
				'position' => (int) $i,
			);
		}

		$variants = array();
		foreach ( (array) ( $raw['variants'] ?? array() ) as $v ) {
			$variant = array(
				'id'              => (string) $v['id'],
				'sourceVariantId' => (string) $v['id'],
				'title'           => self::nullable_string( $v['title'] ?? null, self::MAX_TITLE ),
				'sku'             => self::nullable_string( $v['sku'] ?? null, self::MAX_SHORT ),
				'price'           => self::to_float( $v['price'] ?? null ) ?? 0.0,
				'available'       => (bool) ( $v['available'] ?? false ),
			);
			if ( ! empty( $v['options'] ) && is_array( $v['options'] ) ) {
				$options = array();
				foreach ( $v['options'] as $k => $val ) {
					$options[ self::truncate( (string) $k, self::MAX_SHORT ) ] = self::truncate( (string) $val, 1024 );
				}
				$variant['options'] = $options;
			}
			$variants[] = $variant;
		}

		$modified = isset( $raw['modified'] ) ? (int) $raw['modified'] : 0;

		return array(
			'sourceId'        => (string) $raw['id'],
			'sourceUrl'       => self::nullable_string( $raw['permalink'] ?? null, 1024 ),
			'handle'          => self::nullable_string( $raw['slug'] ?? null, self::MAX_SHORT ),
			'title'           => self::title( $raw['name'] ?? '' ),
			'descriptionHtml' => self::description( $raw['description'] ?? '' ),
			'images'          => $images,
			'tags'            => self::tags( $raw['tags'] ?? array() ),
			'variants'        => $variants,
			'vendor'          => self::nullable_string( $raw['vendor'] ?? null, self::MAX_SHORT ),
			'productType'     => self::nullable_string( $raw['category'] ?? null, self::MAX_SHORT ),
			'priceMin'        => self::to_float( $raw['price_min'] ?? null ),
			'priceMax'        => self::to_float( $raw['price_max'] ?? null ),
			'currency'        => self::nullable_string( $raw['currency'] ?? null, 8 ),
			'sku'             => self::nullable_string( $raw['sku'] ?? null, self::MAX_SHORT ),
			'sourceUpdatedAt' => $modified > 0 ? gmdate( 'Y-m-d\TH:i:s\Z', $modified ) : null,
		);
	}

	/**
	 * Canonical current value of a change field, from raw data. Hashed with
	 * {@see OSL_Hash::value()} and sent as `storeValueHash`; must mirror the
	 * server's `currentFieldValue()`: title, descriptionHtml ?? '', tags ?? [],
	 * images as `[{src, alt|null}]`.
	 *
	 * @param array  $raw   Output of {@see self::collect()}.
	 * @param string $field title|description|tags|images.
	 * @return mixed
	 */
	public static function field_value( array $raw, string $field ) {
		$built = self::build( $raw );
		switch ( $field ) {
			case 'title':
				return $built['title'];
			case 'description':
				return $built['descriptionHtml'];
			case 'tags':
				return $built['tags'];
			case 'images':
				return array_map(
					static fn( array $img ): array => array(
						'src' => $img['src'],
						'alt' => $img['alt'],
					),
					$built['images']
				);
		}
		return null;
	}

	/**
	 * Title, trimmed and capped; never empty (the API requires it).
	 *
	 * @param mixed $name Raw name.
	 * @return string
	 */
	private static function title( $name ): string {
		$title = self::truncate( trim( (string) $name ), self::MAX_TITLE );
		return '' === $title ? '-' : $title;
	}

	/**
	 * Description capped at 64 KiB on a UTF-8 boundary.
	 *
	 * @param mixed $html Raw post_content.
	 * @return string
	 */
	private static function description( $html ): string {
		$html = (string) $html;
		if ( strlen( $html ) <= self::MAX_DESCRIPTION ) {
			return $html;
		}
		return mb_strcut( $html, 0, self::MAX_DESCRIPTION, 'UTF-8' );
	}

	/**
	 * Tag names: trimmed, deduplicated, capped (count and length), empties dropped.
	 *
	 * @param mixed $tags Raw names.
	 * @return string[]
	 */
	private static function tags( $tags ): array {
		$out = array();
		foreach ( (array) $tags as $tag ) {
			$tag = self::truncate( trim( (string) $tag ), self::MAX_TAG_LENGTH );
			if ( '' !== $tag && ! in_array( $tag, $out, true ) ) {
				$out[] = $tag;
			}
			if ( count( $out ) >= self::MAX_TAGS ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * Null for empty strings/null, otherwise a capped string.
	 *
	 * @param mixed $value Value.
	 * @param int   $max   Max characters.
	 * @return string|null
	 */
	private static function nullable_string( $value, int $max ): ?string {
		if ( null === $value ) {
			return null;
		}
		$value = (string) $value;
		return '' === $value ? null : self::truncate( $value, $max );
	}

	/**
	 * Multibyte-safe truncation.
	 *
	 * @param string $value Value.
	 * @param int    $max   Max characters.
	 * @return string
	 */
	private static function truncate( string $value, int $max ): string {
		return mb_strlen( $value, 'UTF-8' ) > $max ? mb_substr( $value, 0, $max, 'UTF-8' ) : $value;
	}

	/**
	 * Numeric string/number → float, otherwise null.
	 *
	 * @param mixed $value Value.
	 * @return float|null
	 */
	private static function to_float( $value ): ?float {
		if ( null === $value || '' === $value || ! is_numeric( $value ) ) {
			return null;
		}
		return (float) $value;
	}
}
