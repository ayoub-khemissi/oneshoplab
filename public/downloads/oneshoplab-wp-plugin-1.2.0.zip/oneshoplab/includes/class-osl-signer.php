<?php
/**
 * Request signing (pure PHP, no WordPress dependency so it is unit-testable).
 *
 * `X-OSL-Signature: t=<unix seconds>,v1=<hex>` where
 * `v1 = HMAC-SHA256(key, "{t}.{METHOD}.{pathname}.{sha256(rawBody)}")`.
 * `pathname` excludes host and query string. Server window: ±300 s.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds the signature header.
 */
final class OSL_Signer {

	/** Key format: `osl_live_` (or `osl_test_`) + 43 base64url chars. */
	public const KEY_PATTERN = '/^osl_(live|test)_[A-Za-z0-9_-]{43}$/';

	/** Length of the public prefix kept for display/logs (matches the server). */
	public const PREFIX_LENGTH = 12;

	/**
	 * The string that gets HMAC'd.
	 *
	 * @param int    $t        Unix seconds.
	 * @param string $method   HTTP method (any case).
	 * @param string $pathname URL path without query string.
	 * @param string $raw_body Raw request body ('' for none).
	 * @return string
	 */
	public static function payload( int $t, string $method, string $pathname, string $raw_body ): string {
		return $t . '.' . strtoupper( $method ) . '.' . $pathname . '.' . hash( 'sha256', $raw_body );
	}

	/**
	 * Hex HMAC-SHA256 of the payload.
	 *
	 * @param string $key      Site key.
	 * @param int    $t        Unix seconds.
	 * @param string $method   HTTP method.
	 * @param string $pathname URL path.
	 * @param string $raw_body Raw body.
	 * @return string
	 */
	public static function signature( string $key, int $t, string $method, string $pathname, string $raw_body ): string {
		return hash_hmac( 'sha256', self::payload( $t, $method, $pathname, $raw_body ), $key );
	}

	/**
	 * Full header value.
	 *
	 * @param string   $key      Site key.
	 * @param string   $method   HTTP method.
	 * @param string   $pathname URL path.
	 * @param string   $raw_body Raw body.
	 * @param int|null $t        Unix seconds (defaults to now).
	 * @return string
	 */
	public static function header( string $key, string $method, string $pathname, string $raw_body, ?int $t = null ): string {
		$t = $t ?? time();
		return 't=' . $t . ',v1=' . self::signature( $key, $t, $method, $pathname, $raw_body );
	}

	/**
	 * Path component of a URL or path string, without query/fragment.
	 *
	 * @param string $url_or_path Absolute URL or path.
	 * @return string
	 */
	public static function pathname( string $url_or_path ): string {
		$path = (string) parse_url( $url_or_path, PHP_URL_PATH ); // phpcs:ignore WordPress.WP.AlternativeFunctions.parse_url_parse_url
		return '' === $path ? '/' : $path;
	}

	/**
	 * Whether the string looks like a site key.
	 *
	 * @param string $key Candidate.
	 * @return bool
	 */
	public static function is_valid_key( string $key ): bool {
		return 1 === preg_match( self::KEY_PATTERN, $key );
	}

	/**
	 * Public prefix of a key (what may be displayed or logged).
	 *
	 * @param string $key Site key.
	 * @return string
	 */
	public static function prefix( string $key ): string {
		return substr( $key, 0, self::PREFIX_LENGTH );
	}
}
