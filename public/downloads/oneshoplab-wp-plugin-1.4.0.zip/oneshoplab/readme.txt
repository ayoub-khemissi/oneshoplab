=== OneShopLab ===
Contributors: oneshoplab
Tags: woocommerce, ai, product descriptions, seo, catalog
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
WC requires at least: 7.0
WC tested up to: 11.0
Stable tag: 1.4.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connects your WooCommerce catalogue to OneShopLab and applies the titles, descriptions, tags and images you approve there.

== Description ==

**Languages / Langues / Idiomas / Sprachen / Lingue:** English, Français, Español, Deutsch, Italiano. The plugin follows your WordPress language automatically. / L’extension suit automatiquement la langue de votre WordPress. / El plugin sigue automáticamente el idioma de su WordPress. / Das Plugin übernimmt automatisch die Sprache Ihres WordPress. / Il plugin segue automaticamente la lingua del suo WordPress.

**English**

OneShopLab audits your product pages and writes better titles, descriptions, tags and product images. This plugin is the bridge with your WooCommerce shop:

* it sends your products to OneShopLab (no more public-storefront scraping), right after you save them and in full whenever you ask;
* it applies the changes you approve in OneShopLab ("Apply to store") right away — OneShopLab notifies the plugin, which then fetches and writes them into the products (images are copied into your media library); if that notification cannot reach your site, the plugin still checks every 5 minutes;
* it tells OneShopLab what was applied, and refuses to overwrite a product you edited in the meantime (conflict detection).

You need a OneShopLab account and a **site key** created in your site settings › Integrations. The key is stored encrypted and never displayed again.

**Français**

OneShopLab audite vos fiches produit et rédige de meilleurs titres, descriptions, étiquettes et images. Ce plugin fait le lien avec votre boutique WooCommerce :

* il envoie vos produits à OneShopLab, juste après chaque enregistrement et en totalité quand vous le demandez ;
* il applique immédiatement les changements que vous validez dans OneShopLab (« Appliquer à la boutique ») — OneShopLab prévient le plugin, qui récupère et écrit les changements dans vos produits (les images sont copiées dans votre médiathèque) ; si cette notification ne peut pas atteindre votre site, le plugin vérifie quand même toutes les 5 minutes ;
* il confirme à OneShopLab ce qui a été appliqué et refuse d’écraser un produit que vous avez modifié entre-temps (détection de conflit).

Il vous faut un compte OneShopLab et une **clé du site** créée dans les réglages du site › Intégrations. La clé est stockée chiffrée et n’est jamais réaffichée.

== Installation ==

1. Upload the zip through Plugins › Add New › Upload Plugin, then activate it. / Téléversez le zip via Extensions › Ajouter › Téléverser une extension, puis activez-la.
2. Open **OneShopLab** in the left menu (also under WooCommerce). / Ouvrez **OneShopLab** dans le menu de gauche (aussi sous WooCommerce).
3. Paste your site key in the **Site key** box and click Save. / Collez votre clé du site dans la case **Clé du site** et cliquez sur Enregistrer.
4. The plugin sends your products right away; the status card turns green within a minute. / Le plugin envoie vos produits tout de suite ; la carte d’état passe au vert en moins d’une minute.

== Frequently Asked Questions ==

= Where is my site key? / Où est ma clé du site ? =

In OneShopLab, open your site › Integrations. The key is shown once; if you lose it, create a new one and paste it here. / Dans OneShopLab, ouvrez votre site › Intégrations. La clé n’est affichée qu’une fois ; si vous la perdez, créez-en une nouvelle et collez-la ici.

= The status says the key was revoked or expired / L’état dit que la clé est révoquée ou expirée =

Create a new key in OneShopLab and paste it in the plugin. Nothing is sent until then. / Créez une nouvelle clé dans OneShopLab et collez-la dans le plugin. Rien n’est envoyé d’ici là.

= "The server clock is off" / « L’horloge du serveur est décalée » =

Requests are signed with the current time; your server's clock is more than 5 minutes off. Ask your host to enable NTP. / Les requêtes sont signées avec l’heure courante ; l’horloge de votre serveur a plus de 5 minutes de décalage. Demandez à votre hébergeur d’activer NTP.

= Does the plugin work on multisite? =

Yes, each site keeps its own key and settings.

= Where are the logs? =

WooCommerce › Status › Logs, source "oneshoplab". Keys are never written to the logs.

== Changelog ==

= 1.4.0 =
* Your photos stay yours: OneShopLab can now change one image at a time — set the main photo, add one, replace one, remove one from the product, edit an alternative text, reorder the gallery — instead of replacing the whole gallery. Removing an image only takes it off the product; the file always stays in your media library. / Vos photos restent les vôtres : OneShopLab peut désormais modifier une image à la fois — définir la photo principale, en ajouter une, en remplacer une, en retirer une du produit, modifier un texte alternatif, réordonner la galerie — au lieu de remplacer toute la galerie. Retirer une image la détache seulement du produit ; le fichier reste toujours dans votre médiathèque.
* If one of those images was already deleted from the product on your side, that single change is skipped and the rest still applies — nothing fails, and OneShopLab tells you what was not applied. A product is never left without any image. / Si l’une de ces images a déjà été supprimée du produit de votre côté, cette modification-là est ignorée et le reste s’applique quand même — rien n’échoue, et OneShopLab vous dit ce qui n’a pas été appliqué. Un produit n’est jamais laissé sans aucune image.
* Su tienda decide: OneShopLab solo ofrece las acciones que este plugin sabe hacer. / Ihr Shop entscheidet: OneShopLab bietet nur die Aktionen an, die dieses Plugin wirklich ausführen kann. / Il suo negozio decide: OneShopLab propone solo le azioni che questo plugin sa eseguire.

= 1.3.0 =
* The plugin now speaks English, French, Spanish, German and Italian; it follows your WordPress language on its own, nothing to set up. / L’extension parle désormais anglais, français, espagnol, allemand et italien ; elle suit la langue de votre WordPress toute seule, rien à régler.
* El plugin ahora habla inglés, francés, español, alemán e italiano; sigue el idioma de su WordPress por sí solo, no hay que configurar nada. / Das Plugin spricht jetzt Englisch, Französisch, Spanisch, Deutsch und Italienisch; es übernimmt die Sprache Ihres WordPress von selbst, Sie müssen nichts einstellen. / Il plugin ora parla inglese, francese, spagnolo, tedesco e italiano; segue da solo la lingua del suo WordPress, non c’è nulla da impostare.

= 1.2.0 =
* Works on older shops: PHP 7.4+, WordPress 6.0+ and WooCommerce 7.0+ (was PHP 8.1 / WordPress 6.4 / WooCommerce 8.0). Nothing else changes, and the site key is still stored encrypted. / Fonctionne sur des boutiques plus anciennes : PHP 7.4+, WordPress 6.0+ et WooCommerce 7.0+ (au lieu de PHP 8.1 / WordPress 6.4 / WooCommerce 8.0). Rien d’autre ne change, et la clé du site reste stockée chiffrée.
* If your WordPress is older than 6.0 the plugin now says so clearly instead of doing nothing. / Si votre WordPress est antérieur à 6.0, l’extension vous le dit clairement au lieu de rester inactive.

= 1.1.0 =
* Instant updates: OneShopLab notifies the plugin as soon as you approve a change (signed webhook); the 5-minute check stays as a fallback. "Test" button on the status card. / Mises à jour instantanées : OneShopLab prévient le plugin dès qu’un changement est validé ; la vérification toutes les 5 minutes reste en secours. Bouton « Tester » sur la carte d’état.

= 1.0.0 =
* First release: catalogue push, approved-changes pull, encrypted site key, French translation.
