<?php
/**
 * HTTP client for the Integration API v1: bearer + HMAC signature, error
 * envelope → WP_Error, retry with backoff on network errors, Retry-After on
 * 429, auth failures recorded so cron stops until a new key is saved.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * API client.
 */
final class OSL_Client {

	public const DEFAULT_BASE = 'https://oneshoplab.com';
	public const API_PREFIX   = '/api/v1';
	public const PLATFORM     = 'woocommerce';
	public const MAX_ATTEMPTS = 3;

	/** Auth codes that stop all cron work until the merchant saves a new key. */
	private const BLOCKING_CODES = array( 'key_revoked', 'key_expired', 'unauthorized', 'signature_invalid' );

	/**
	 * Site key for this instance.
	 *
	 * @var string
	 */
	private string $key;

	/**
	 * Base URL without trailing slash.
	 *
	 * @var string
	 */
	private string $base;

	/**
	 * Constructor.
	 *
	 * @param string      $key  Site key.
	 * @param string|null $base Base URL (filterable through `oneshoplab_api_base`).
	 */
	public function __construct( string $key, ?string $base = null ) {
		$this->key = $key;
		/**
		 * Overrides the API base URL (staging, local dev).
		 *
		 * @param string $base Base URL.
		 */
		$this->base = rtrim( $base ?? (string) apply_filters( 'oneshoplab_api_base', defined( 'OSL_API_BASE' ) ? OSL_API_BASE : self::DEFAULT_BASE ), '/' );
	}

	/**
	 * Client for the stored key, or a WP_Error explaining why there is none.
	 *
	 * @return self|WP_Error
	 */
	public static function from_settings() {
		$key = OSL_State::key();
		if ( null === $key ) {
			return new WP_Error( 'no_key', __( 'No site key saved yet.', 'oneshoplab' ) );
		}
		return new self( $key );
	}

	/**
	 * GET /site.
	 *
	 * @return array|WP_Error
	 */
	public function site() {
		return $this->request( 'GET', '/site' );
	}

	/**
	 * What this plugin build can do, reported on every `/products/sync` call
	 * (IMAGE-OPS.md §7). OneShopLab persists it per project and only sends the
	 * operations listed here; a build older than 1.4.0 reports nothing and
	 * keeps receiving the replace-all payload.
	 *
	 * Everything claimed is executed by {@see OSL_Changes}: WooCommerce holds
	 * the featured image and the gallery as ordered attachment ids, so the six
	 * verbs and the alt text (`_wp_attachment_image_alt`) are all writable.
	 *
	 * @return array
	 */
	public static function capabilities(): array {
		return array(
			'stableImageIds' => true,
			'imageOps'       => OSL_Image_Ops::VERBS,
			'maxImages'      => OSL_Product_Mapper::MAX_IMAGES,
			'altEditable'    => true,
			'fields'         => array( 'title', 'description', 'tags', 'images' ),
		);
	}

	/**
	 * POST /products/sync.
	 *
	 * @param array       $body            mode/session/final/products.
	 * @param string|null $idempotency_key Reused across retries; generated when null.
	 * @return array|WP_Error
	 */
	public function sync_products( array $body, ?string $idempotency_key = null ) {
		$body['capabilities'] = self::capabilities();
		return $this->request( 'POST', '/products/sync', $body, array( 'Idempotency-Key' => $idempotency_key ?? wp_generate_uuid4() ) );
	}

	/**
	 * DELETE /products/{sourceId} (archive).
	 *
	 * @param string $source_id Product source id.
	 * @return array|WP_Error
	 */
	public function archive_product( string $source_id ) {
		return $this->request( 'DELETE', '/products/' . rawurlencode( $source_id ) );
	}

	/**
	 * GET /changes.
	 *
	 * @param string $since Cursor or ''.
	 * @param int    $limit 1..200.
	 * @return array|WP_Error
	 */
	public function changes( string $since = '', int $limit = 50 ) {
		$query = array( 'limit' => max( 1, min( 200, $limit ) ) );
		if ( '' !== $since ) {
			$query['since'] = $since;
		}
		return $this->request( 'GET', '/changes?' . http_build_query( $query ) );
	}

	/**
	 * POST /changes/{id}/ack.
	 *
	 * @param string $change_id Change id.
	 * @param array  $body      status/error/storeUpdatedAt/storeValueHash/skippedOps.
	 * @return array|WP_Error
	 */
	public function ack( string $change_id, array $body ) {
		return $this->request( 'POST', '/changes/' . rawurlencode( $change_id ) . '/ack', $body );
	}

	/**
	 * PUT /webhooks/self (needs the `webhooks:manage` key permission).
	 *
	 * @param array $body  {url, events}.
	 * @param bool  $quiet Do not record a failure as the card's "last error".
	 * @return array|WP_Error {id, secret}
	 */
	public function register_webhook( array $body, bool $quiet = false ) {
		return $this->request( 'PUT', '/webhooks/self', $body, array(), $quiet );
	}

	/**
	 * DELETE /webhooks/self (best effort, never shown as an error).
	 *
	 * @return array|WP_Error
	 */
	public function unregister_webhook() {
		return $this->request( 'DELETE', '/webhooks/self', null, array(), true );
	}

	/**
	 * POST /webhooks/self/ping: asks OneShopLab to deliver a `ping` event.
	 *
	 * @return array|WP_Error
	 */
	public function ping_webhook() {
		return $this->request( 'POST', '/webhooks/self/ping', array(), array(), true );
	}

	/**
	 * Signed request with retries.
	 *
	 * @param string     $method  GET|POST|PUT|DELETE.
	 * @param string     $path    Path relative to /api/v1 (may carry a query string).
	 * @param array|null $body    JSON body or null.
	 * @param array      $headers Extra headers.
	 * @param bool       $quiet   When true, failures are logged but not recorded as the status card's last error.
	 * @return array|WP_Error Decoded JSON (array, possibly empty) or error with the API `code`.
	 */
	public function request( string $method, string $path, ?array $body = null, array $headers = array(), bool $quiet = false ) {
		$url      = $this->base . self::API_PREFIX . $path;
		$pathname = OSL_Signer::pathname( $url );
		$raw      = null === $body ? '' : (string) wp_json_encode( $body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		$attempt = 0;
		$last    = null;
		while ( $attempt < self::MAX_ATTEMPTS ) {
			++$attempt;
			$args = array(
				'method'      => $method,
				'timeout'     => 30,
				'redirection' => 0,
				'user-agent'  => 'OneShopLab-WooCommerce/' . OSL_VERSION . ' (' . home_url() . ')',
				'headers'     => array_merge(
					array(
						'Authorization'   => 'Bearer ' . $this->key,
						'X-OSL-Signature' => OSL_Signer::header( $this->key, $method, $pathname, $raw ),
						'X-OSL-Platform'  => self::PLATFORM,
						'Accept'          => 'application/json',
					),
					'' !== $raw ? array( 'Content-Type' => 'application/json' ) : array(),
					$headers
				),
				'body'        => '' !== $raw ? $raw : null,
			);

			$response = wp_remote_request( $url, $args );
			if ( is_wp_error( $response ) ) {
				$last = new WP_Error( 'network', $response->get_error_message(), array( 'attempt' => $attempt ) );
				OSL_Logger::warning( "Network error on {$method} {$pathname} (attempt {$attempt})", array( 'error' => $response->get_error_message() ) );
				if ( $attempt < self::MAX_ATTEMPTS ) {
					usleep( (int) ( 500000 * ( 2 ** ( $attempt - 1 ) ) ) ); // 0.5 s, 1 s.
				}
				continue;
			}

			$result = $this->interpret( $response, $method, $pathname, $quiet );
			if ( is_wp_error( $result ) && 'internal' === $result->get_error_code() && $attempt < self::MAX_ATTEMPTS ) {
				$last = $result;
				usleep( (int) ( 500000 * ( 2 ** ( $attempt - 1 ) ) ) );
				continue;
			}
			return $result;
		}

		$error = $last ?? new WP_Error( 'network', __( 'Could not reach OneShopLab.', 'oneshoplab' ) );
		if ( ! $quiet ) {
			OSL_State::record_error( $error );
		}
		return $error;
	}

	/**
	 * Turns a raw response into data or a WP_Error, updating status/auth state.
	 *
	 * @param array  $response wp_remote_request() result.
	 * @param string $method   Method (for logs).
	 * @param string $pathname Path (for logs).
	 * @param bool   $quiet    Skip the status card's "last error".
	 * @return array|WP_Error
	 */
	private function interpret( array $response, string $method, string $pathname, bool $quiet = false ) {
		$status = (int) wp_remote_retrieve_response_code( $response );
		$text   = (string) wp_remote_retrieve_body( $response );
		$data   = json_decode( $text, true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}

		if ( $status >= 200 && $status < 300 ) {
			OSL_State::update_status(
				array(
					'last_contact' => time(),
					'last_error'   => null,
				)
			);
			return $data;
		}

		$code    = isset( $data['error']['code'] ) ? (string) $data['error']['code'] : ( $status >= 500 ? 'internal' : 'http_' . $status );
		$message = isset( $data['error']['message'] ) ? (string) $data['error']['message'] : sprintf( 'HTTP %d', $status );
		$details = isset( $data['error']['details'] ) && is_array( $data['error']['details'] ) ? $data['error']['details'] : array();
		$error   = new WP_Error(
			$code,
			$message,
			array(
				'status'  => $status,
				'details' => $details,
			)
		);

		if ( 429 === $status || 'rate_limited' === $code ) {
			$retry_after = (int) wp_remote_retrieve_header( $response, 'retry-after' );
			$retry_after = $retry_after > 0 ? $retry_after : 60;
			set_transient( OSL_State::TR_RETRY_AFTER, time() + $retry_after, $retry_after );
			$error->add_data( array( 'retry_after' => $retry_after ), 'retry' );
		}

		if ( in_array( $code, self::BLOCKING_CODES, true ) ) {
			OSL_State::block_key( in_array( $code, array( 'key_revoked', 'key_expired' ), true ) ? $code : OSL_State::KEY_STATE_INVALID );
		}

		if ( 'clock_skew' === $code ) {
			$server_time = isset( $details['serverTime'] ) ? (string) $details['serverTime'] : '';
			$error       = new WP_Error(
				'clock_skew',
				/* translators: %s: server time reported by OneShopLab */
				sprintf( __( 'The server clock is off (OneShopLab time: %s). Ask your host to enable NTP time synchronisation.', 'oneshoplab' ), $server_time ),
				$error->get_error_data()
			);
		}

		OSL_Logger::error( "API error on {$method} {$pathname}: {$code}", array( 'status' => $status, 'message' => $message, 'details' => $details ) );
		if ( ! $quiet ) {
			OSL_State::record_error( $error );
		}
		return $error;
	}

	/**
	 * Merchant-facing explanation of an error code (plain words, no jargon).
	 *
	 * @param string $code API code.
	 * @param string $fallback Message returned by the API.
	 * @return string
	 */
	public static function explain( string $code, string $fallback = '' ): string {
		switch ( $code ) {
			case 'key_revoked':
				return __( 'This site key was revoked in OneShopLab. Create a new key in OneShopLab (site settings › Integrations) and paste it here.', 'oneshoplab' );
			case 'key_expired':
				return __( 'This site key has expired. Create a new key in OneShopLab (site settings › Integrations) and paste it here.', 'oneshoplab' );
			case 'unauthorized':
			case 'signature_invalid':
				return __( 'OneShopLab does not recognise this site key. Check that you pasted the whole key without spaces, or create a new one.', 'oneshoplab' );
			case 'clock_skew':
				return __( 'The server clock is off. Ask your host to enable NTP time synchronisation, then try again.', 'oneshoplab' );
			case 'forbidden':
				return __( 'This site key does not have the permission for that action. Create a key with all permissions.', 'oneshoplab' );
			case 'rate_limited':
				return __( 'Too many requests for the moment. The plugin will retry automatically.', 'oneshoplab' );
			case 'plan_limit':
				return __( 'Your OneShopLab plan does not allow that many products. Upgrade your plan or reduce your catalogue.', 'oneshoplab' );
			case 'sync_in_progress':
				return __( 'A full sync is already running. Wait a few minutes and try again.', 'oneshoplab' );
			case 'locked':
				return __( 'OneShopLab is busy with another batch. The plugin will retry automatically.', 'oneshoplab' );
			case 'network':
				return __( 'Could not reach OneShopLab. Check that your server can make outgoing HTTPS requests.', 'oneshoplab' );
			case 'no_key':
				return __( 'No site key saved yet.', 'oneshoplab' );
			case 'unreadable':
				return __( 'The saved site key can no longer be read (the WordPress security keys changed). Paste the key again.', 'oneshoplab' );
			case 'validation':
				return __( 'OneShopLab rejected some product data. See WooCommerce › Status › Logs (source "oneshoplab").', 'oneshoplab' );
			default:
				return '' !== $fallback ? $fallback : $code;
		}
	}
}
