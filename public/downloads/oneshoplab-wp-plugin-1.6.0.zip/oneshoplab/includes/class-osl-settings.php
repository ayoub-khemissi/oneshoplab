<?php
/**
 * Admin page: top-level "OneShopLab" menu + WooCommerce submenu.
 *
 * The screen reads top to bottom the way a shop owner needs it: who this is
 * (identity header), whether it works (connection card), the site key form,
 * instant updates, diagnostics, then the log of what was actually changed.
 * Everything is built from native admin furniture — `.wrap`, `.postbox`,
 * `.form-table`, `.widefat`, `.notice`, `button button-primary` — so the page
 * belongs to the admin it is shown in rather than imitating a foreign
 * dashboard. Presentation lives in `assets/admin.css` and `assets/admin.js`,
 * enqueued only on this plugin's own screens; the only inline CSS is the three
 * accent custom properties derived from the running admin colour scheme
 * ({@see OSL_Admin_Color}).
 *
 * Every action goes through admin-post (or admin-ajax) with a nonce and
 * `manage_woocommerce`.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings screen.
 */
final class OSL_Settings {

	public const SLUG       = 'oneshoplab';
	public const CAPABILITY = 'manage_woocommerce';

	/** Handle shared by the stylesheet and the script. */
	public const ASSET_HANDLE = 'oneshoplab-admin';

	/** App locales the dashboard link can point at; anything else gets English. */
	public const APP_LOCALES = array( 'en', 'fr', 'es', 'de', 'it' );

	/**
	 * Registers hooks.
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_oneshoplab_save_key', array( __CLASS__, 'handle_save_key' ) );
		add_action( 'admin_post_oneshoplab_clear_key', array( __CLASS__, 'handle_clear_key' ) );
		add_action( 'admin_post_oneshoplab_test', array( __CLASS__, 'handle_test' ) );
		add_action( 'admin_post_oneshoplab_full_sync', array( __CLASS__, 'handle_full_sync' ) );
		add_action( 'admin_post_oneshoplab_poll', array( __CLASS__, 'handle_poll' ) );
		add_action( 'admin_post_oneshoplab_health_recheck', array( __CLASS__, 'handle_health_recheck' ) );
		add_action( 'wp_ajax_oneshoplab_webhook_ping', array( __CLASS__, 'ajax_webhook_ping' ) );
		add_action( 'wp_ajax_oneshoplab_webhook_ping_status', array( __CLASS__, 'ajax_webhook_ping_status' ) );
		add_action( 'admin_notices', array( __CLASS__, 'key_state_notice' ) );
		add_filter( 'plugin_action_links_' . OSL_PLUGIN_BASENAME, array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Menu entries: the wizard tells merchants to open "OneShopLab" in the left menu.
	 */
	public static function register_menu(): void {
		add_menu_page(
			__( 'OneShopLab', 'oneshoplab' ),
			__( 'OneShopLab', 'oneshoplab' ),
			self::CAPABILITY,
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-store',
			56
		);
		add_submenu_page(
			'woocommerce',
			__( 'OneShopLab', 'oneshoplab' ),
			__( 'OneShopLab', 'oneshoplab' ),
			self::CAPABILITY,
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * "Settings" link on the plugins list.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( array $links ): array {
		array_unshift( $links, '<a href="' . esc_url( self::page_url() ) . '">' . esc_html__( 'Settings', 'oneshoplab' ) . '</a>' );
		return $links;
	}

	/**
	 * Admin URL of the page.
	 *
	 * @param array $args Query args.
	 * @return string
	 */
	public static function page_url( array $args = array() ): string {
		return add_query_arg( array_merge( array( 'page' => self::SLUG ), $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Whether a hook suffix belongs to this plugin. The page is registered
	 * twice under the same slug, so it answers to `toplevel_page_oneshoplab`
	 * and to `<parent>_page_oneshoplab` — the parent part depends on how
	 * WooCommerce named its own menu, hence the suffix test.
	 *
	 * @param string $hook Hook suffix given to admin_enqueue_scripts.
	 * @return bool
	 */
	public static function is_own_screen( string $hook ): bool {
		return 'toplevel_page_' . self::SLUG === $hook || substr( $hook, -strlen( '_page_' . self::SLUG ) ) === '_page_' . self::SLUG;
	}

	/**
	 * Stylesheet + script, on this plugin's screens only.
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public static function enqueue_assets( string $hook ): void {
		if ( ! self::is_own_screen( $hook ) || ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		wp_enqueue_style( self::ASSET_HANDLE, OSL_PLUGIN_URL . 'assets/admin.css', array( 'dashicons' ), OSL_VERSION );
		wp_add_inline_style( self::ASSET_HANDLE, OSL_Admin_Color::css( '.oneshoplab-wrap', self::scheme_accent() ) );

		if ( ! OSL_Webhook::is_active() ) {
			return;
		}
		wp_enqueue_script( self::ASSET_HANDLE, OSL_PLUGIN_URL . 'assets/admin.js', array(), OSL_VERSION, true );
		wp_localize_script(
			self::ASSET_HANDLE,
			'oneshoplabAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'oneshoplab_webhook_ping' ),
				'sending' => __( 'Sending a test event…', 'oneshoplab' ),
				'waiting' => __( 'Waiting for OneShopLab…', 'oneshoplab' ),
				'arrived' => __( 'The test event arrived: instant updates work.', 'oneshoplab' ),
				'timeout' => __( 'No test event received within 10 seconds. Check that your site is reachable from the internet over HTTPS; changes are still applied every 5 minutes.', 'oneshoplab' ),
				'failed'  => __( 'Could not ask OneShopLab for a test event:', 'oneshoplab' ),
			)
		);
	}

	/**
	 * Highlight colour of the colour scheme this user picked in their profile.
	 *
	 * @return string `#rrggbb`.
	 */
	private static function scheme_accent(): string {
		global $_wp_admin_css_colors;
		$scheme  = (string) get_user_option( 'admin_color' );
		$palette = array();
		if ( isset( $_wp_admin_css_colors[ $scheme ]->colors ) ) {
			$palette = (array) $_wp_admin_css_colors[ $scheme ]->colors;
		}
		return OSL_Admin_Color::accent_for_scheme( $scheme, $palette );
	}

	/**
	 * The merchant's OneShopLab dashboard, in their own language when the app
	 * has that locale.
	 *
	 * @return string
	 */
	private static function dashboard_url(): string {
		$base = defined( 'OSL_API_BASE' ) ? OSL_API_BASE : OSL_Client::DEFAULT_BASE;
		/** This filter is documented in includes/class-osl-client.php */
		$base     = rtrim( (string) apply_filters( 'oneshoplab_api_base', $base ), '/' );
		$language = strtolower( substr( (string) determine_locale(), 0, 2 ) );
		if ( ! in_array( $language, self::APP_LOCALES, true ) ) {
			$language = 'en';
		}
		return $base . '/' . $language . '/dashboard';
	}

	/**
	 * Site-wide notice when the key stopped working.
	 */
	public static function key_state_notice(): void {
		if ( ! current_user_can( self::CAPABILITY ) || ! OSL_State::has_key() ) {
			return;
		}
		$state = OSL_State::status()['key_state'] ?? OSL_State::KEY_STATE_OK;
		if ( in_array( $state, array( OSL_State::KEY_STATE_OK, '', OSL_State::KEY_STATE_MISSING ), true ) ) {
			return;
		}
		printf(
			'<div class="notice notice-error"><p><strong>OneShopLab</strong> — %s <a href="%s">%s</a></p></div>',
			esc_html( OSL_Client::explain( $state ) ),
			esc_url( self::page_url() ),
			esc_html__( 'Open OneShopLab settings', 'oneshoplab' )
		);
	}

	/* -------------------------------------------------------------- actions */

	/**
	 * Nonce + capability guard shared by all handlers.
	 *
	 * @param string $action Nonce action.
	 */
	private static function guard( string $action ): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'oneshoplab' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Back to the page with a message code.
	 *
	 * @param string $msg  Message code.
	 * @param string $text Optional detail.
	 */
	private static function redirect( string $msg, string $text = '' ): void {
		$args = array( 'osl_msg' => $msg );
		if ( '' !== $text ) {
			$args['osl_text'] = rawurlencode( mb_substr( $text, 0, 500 ) );
		}
		wp_safe_redirect( self::page_url( $args ) );
		exit;
	}

	/**
	 * Save the site key, test it, launch the first full sync.
	 */
	public static function handle_save_key(): void {
		self::guard( 'oneshoplab_save_key' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- check_admin_referer() ran on the line above, inside self::guard().
		$key = isset( $_POST['oneshoplab_site_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['oneshoplab_site_key'] ) ) ) : '';
		if ( ! OSL_Signer::is_valid_key( $key ) ) {
			self::redirect( 'invalid_key' );
		}
		// Key change: tell OneShopLab to stop sending webhooks for the old key (best effort).
		$old_client = OSL_Client::from_settings();
		if ( ! is_wp_error( $old_client ) ) {
			OSL_Webhook::unregister( $old_client );
		}
		if ( ! OSL_State::save_key( $key ) ) {
			self::redirect( 'error', OSL_Client::explain( 'unreadable' ) );
		}
		delete_transient( OSL_State::TR_RETRY_AFTER );
		OSL_Logger::info( 'Site key saved', array( 'prefix' => OSL_Signer::prefix( $key ) ) );

		$client = new OSL_Client( $key );
		$site   = $client->site();
		if ( is_wp_error( $site ) ) {
			self::redirect( 'saved_but_failed', OSL_Client::explain( $site->get_error_code(), $site->get_error_message() ) );
		}
		self::store_site_info( $site );
		OSL_Webhook::register( $client );
		OSL_Sync::start_full_sync();
		self::redirect( 'saved' );
	}

	/**
	 * Forget the key.
	 */
	public static function handle_clear_key(): void {
		self::guard( 'oneshoplab_clear_key' );
		OSL_Webhook::unregister();
		OSL_State::clear_key();
		OSL_Logger::info( 'Site key removed' );
		self::redirect( 'cleared' );
	}

	/**
	 * "Test connection" → GET /site.
	 */
	public static function handle_test(): void {
		self::guard( 'oneshoplab_test' );
		$client = OSL_Client::from_settings();
		if ( is_wp_error( $client ) ) {
			self::redirect( 'error', OSL_Client::explain( $client->get_error_code(), $client->get_error_message() ) );
		}
		$site = $client->site();
		if ( is_wp_error( $site ) ) {
			self::redirect( 'error', OSL_Client::explain( $site->get_error_code(), $site->get_error_message() ) );
		}
		// A successful call proves the key works again (e.g. after a rotation).
		OSL_State::update_status( array( 'key_state' => OSL_State::KEY_STATE_OK ) );
		self::store_site_info( $site );
		self::redirect( 'test_ok' );
	}

	/**
	 * "Sync everything now".
	 */
	public static function handle_full_sync(): void {
		self::guard( 'oneshoplab_full_sync' );
		$result = OSL_Sync::start_full_sync();
		if ( is_wp_error( $result ) ) {
			self::redirect( 'error', $result->get_error_message() );
		}
		self::redirect( 'sync_started' );
	}

	/**
	 * "Check for changes now".
	 */
	public static function handle_poll(): void {
		self::guard( 'oneshoplab_poll' );
		$result = OSL_Changes::poll();
		if ( is_wp_error( $result ) ) {
			self::redirect( 'error', OSL_Client::explain( $result->get_error_code(), $result->get_error_message() ) );
		}
		self::redirect( 'poll_done', (string) $result['applied'] );
	}

	/**
	 * "Re-check" on the diagnostics list: drops the cached probes and runs
	 * them again right away, so a merchant who just asked their host to fix
	 * the folder permissions sees the answer immediately.
	 */
	public static function handle_health_recheck(): void {
		self::guard( 'oneshoplab_health_recheck' );
		OSL_Health::flush();
		$report = OSL_Health::report( true );
		OSL_Logger::info( 'Diagnostics re-checked', OSL_Health::flags_from_report( $report ) );
		self::redirect( 'health_rechecked' );
	}

	/**
	 * AJAX "Test" button: asks OneShopLab to send a `ping` event. Returns the
	 * moment the request was made so the page can watch for its arrival.
	 */
	public static function ajax_webhook_ping(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do that.', 'oneshoplab' ) ), 403 );
		}
		check_ajax_referer( 'oneshoplab_webhook_ping', 'nonce' );
		$sent_at = time();
		$result  = OSL_Webhook::request_ping();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => OSL_Client::explain( $result->get_error_code(), $result->get_error_message() ) ) );
		}
		wp_send_json_success( array( 'sent_at' => $sent_at ) );
	}

	/**
	 * AJAX: whether a ping arrived since `sent_at`.
	 */
	public static function ajax_webhook_ping_status(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do that.', 'oneshoplab' ) ), 403 );
		}
		check_ajax_referer( 'oneshoplab_webhook_ping', 'nonce' );
		$sent_at   = isset( $_REQUEST['sent_at'] ) ? (int) $_REQUEST['sent_at'] : 0;
		$last_ping = (int) ( OSL_State::status()['webhook_last_ping'] ?? 0 );
		wp_send_json_success(
			array(
				'arrived'   => $last_ping > 0 && $last_ping >= $sent_at,
				'last_ping' => $last_ping,
			)
		);
	}

	/**
	 * Keeps the /site answer for the Connection card.
	 *
	 * @param array $site GET /site response.
	 */
	private static function store_site_info( array $site ): void {
		OSL_State::update_status(
			array(
				'site' => array(
					'name'   => (string) ( $site['site']['name'] ?? '' ),
					'plan'   => (string) ( $site['site']['plan'] ?? '' ),
					'domain' => (string) ( $site['site']['domain'] ?? '' ),
					'limits' => (array) ( $site['site']['limits'] ?? array() ),
				),
				'key'  => array(
					'permissions' => (array) ( $site['key']['permissions'] ?? array() ),
					'expiresAt'   => $site['key']['expiresAt'] ?? null,
					'graceUntil'  => $site['key']['graceUntil'] ?? null,
				),
			)
		);
	}

	/* --------------------------------------------------------------- render */

	/**
	 * Page output. Reading order, top to bottom: who this is, whether it
	 * works, the key, instant updates, diagnostics, what was changed.
	 */
	public static function render(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'oneshoplab' ), 403 );
		}
		$status   = OSL_State::status();
		$has_key  = OSL_State::has_key();
		$state    = $has_key ? ( $status['key_state'] ?? OSL_State::KEY_STATE_OK ) : OSL_State::KEY_STATE_MISSING;
		$full     = OSL_Sync::full_sync_state();
		$queue    = count( OSL_State::queue() );
		$log      = OSL_State::change_log();
		$msg      = isset( $_GET['osl_msg'] ) ? sanitize_key( wp_unslash( $_GET['osl_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only feedback code from our own redirect.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- decoded first, then sanitised on the next line.
		$msg_text = isset( $_GET['osl_text'] ) ? rawurldecode( (string) wp_unslash( $_GET['osl_text'] ) ) : '';
		$msg_text = sanitize_text_field( $msg_text );
		?>
		<div class="wrap oneshoplab-wrap">
			<?php self::render_identity(); ?>
			<hr class="wp-header-end" />

			<?php self::render_message( $msg, $msg_text ); ?>

			<?php if ( $has_key && ! empty( $status['key']['graceUntil'] ) && strtotime( (string) $status['key']['graceUntil'] ) > time() ) : ?>
				<div class="notice notice-warning"><p>
					<?php
					/* translators: %s: date/time */
					printf( esc_html__( 'This site key was rotated in OneShopLab. It stops working on %s — paste the new key before then.', 'oneshoplab' ), esc_html( self::format_date( strtotime( (string) $status['key']['graceUntil'] ) ) ) );
					?>
				</p></div>
			<?php endif; ?>

			<?php self::render_connection( (string) $state, $status, $has_key, $full, $queue ); ?>

			<div class="osl-grid">
				<?php self::render_key_card( $has_key ); ?>
				<?php self::render_webhook_card( $has_key, $status ); ?>
			</div>

			<?php self::render_health(); ?>
			<?php self::render_log( $log ); ?>

			<p class="osl-foot">
				<?php
				printf(
					/* translators: %s: link to WooCommerce logs */
					esc_html__( 'Technical details are in %s (source "oneshoplab").', 'oneshoplab' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs' ) ) . '">' . esc_html__( 'WooCommerce › Status › Logs', 'oneshoplab' ) . '</a>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Identity header: the mark, the plugin name as the page `h1`, the version
	 * and a way back to the merchant's own OneShopLab dashboard. The
	 * `wp-header-end` rule after it is where WordPress drops admin notices.
	 */
	private static function render_identity(): void {
		?>
		<div class="osl-head">
			<img class="osl-head__mark" src="<?php echo esc_url( OSL_PLUGIN_URL . 'assets/icon-128x128.png' ); ?>" width="44" height="44" alt="" />
			<div class="osl-head__body">
				<h1><?php esc_html_e( 'OneShopLab', 'oneshoplab' ); ?></h1>
				<p class="osl-head__meta">
					<span class="osl-version">
						<?php
						/* translators: %s: plugin version number */
						printf( esc_html__( 'Version %s', 'oneshoplab' ), esc_html( OSL_VERSION ) );
						?>
					</span>
					<a class="osl-head__link" href="<?php echo esc_url( self::dashboard_url() ); ?>" target="_blank" rel="noopener noreferrer">
						<?php esc_html_e( 'Open your OneShopLab dashboard', 'oneshoplab' ); ?>
						<span class="dashicons dashicons-external" aria-hidden="true"></span>
					</a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Connection card: one unambiguous sentence about the state of the link,
	 * the six figures that back it up, and the three manual actions.
	 *
	 * @param string     $state   Key state.
	 * @param array      $status  Status option.
	 * @param bool       $has_key Whether a key is stored.
	 * @param array|null $full    Full-sync progress.
	 * @param int        $queue   Queued items.
	 */
	private static function render_connection( string $state, array $status, bool $has_key, ?array $full, int $queue ): void {
		$view  = self::connection_view( $state, $status );
		$error = self::error_label( $status );
		self::card_open( 'dashicons-admin-links', __( 'Connection', 'oneshoplab' ), 'osl-hero ' . $view['class'] );
		?>
		<div class="osl-hero__state">
			<span class="osl-hero__icon"><span class="dashicons <?php echo esc_attr( $view['icon'] ); ?>" aria-hidden="true"></span></span>
			<div>
				<p class="osl-hero__title"><?php echo esc_html( $view['title'] ); ?></p>
				<?php if ( '' !== $view['sub'] ) : ?>
					<p class="osl-hero__sub"><?php echo esc_html( $view['sub'] ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="osl-facts">
			<?php
			self::render_fact( __( 'Last exchange', 'oneshoplab' ), self::ago( (int) ( $status['last_contact'] ?? 0 ) ) );
			self::render_fact( __( 'OneShopLab site', 'oneshoplab' ), self::site_label( $status ) );
			self::render_fact( __( 'Products', 'oneshoplab' ), self::products_label( $status, $full, $queue ) );
			self::render_fact( __( 'Last sync', 'oneshoplab' ), self::sync_label( $status ) );
			self::render_fact( __( 'Changes to apply', 'oneshoplab' ), self::pending_label( $status ) );
			self::render_fact( __( 'Last error', 'oneshoplab' ), $error, ! empty( $status['last_error']['code'] ) );
			?>
		</div>
		<?php if ( $has_key ) : ?>
			<div class="osl-hero__actions">
				<p class="osl-actions">
					<?php self::action_button( 'oneshoplab_test', __( 'Test connection', 'oneshoplab' ), 'primary' ); ?>
					<?php self::action_button( 'oneshoplab_full_sync', __( 'Sync everything now', 'oneshoplab' ), 'secondary', null !== $full ); ?>
					<?php self::action_button( 'oneshoplab_poll', __( 'Check for changes now', 'oneshoplab' ) ); ?>
				</p>
			</div>
		<?php endif; ?>
		<?php
		self::card_close();
	}

	/**
	 * The connection state as something a shop owner can act on: a colour, an
	 * icon, a short verdict and one line saying what it means.
	 *
	 * @param string $state  Key state.
	 * @param array  $status Status option.
	 * @return array{class:string,icon:string,title:string,sub:string}
	 */
	private static function connection_view( string $state, array $status ): array {
		if ( OSL_State::KEY_STATE_MISSING === $state ) {
			return array(
				'class' => 'is-idle',
				'icon'  => 'dashicons-admin-network',
				'title' => __( 'Not connected — paste your site key.', 'oneshoplab' ),
				'sub'   => __( 'The key is in your OneShopLab account, under site settings › Integrations.', 'oneshoplab' ),
			);
		}
		if ( OSL_State::KEY_STATE_OK !== $state && '' !== $state ) {
			return array(
				'class' => 'is-bad',
				'icon'  => 'dashicons-warning',
				'title' => __( 'Key problem', 'oneshoplab' ),
				'sub'   => OSL_Client::explain( $state ),
			);
		}
		if ( OSL_Plugin::is_maintenance() ) {
			return array(
				'class' => 'is-idle',
				'icon'  => 'dashicons-hammer',
				'title' => __( 'Paused: the site is in maintenance mode.', 'oneshoplab' ),
				'sub'   => '',
			);
		}
		if ( empty( $status['last_contact'] ) ) {
			return array(
				'class' => 'is-waiting',
				'icon'  => 'dashicons-clock',
				'title' => __( 'Waiting for the first exchange…', 'oneshoplab' ),
				'sub'   => __( 'Your products are on their way — this card turns green after the first exchange.', 'oneshoplab' ),
			);
		}
		return array(
			'class' => 'is-ok',
			'icon'  => 'dashicons-yes-alt',
			'title' => __( 'Connected', 'oneshoplab' ),
			'sub'   => __( 'Your products are being kept in sync with OneShopLab.', 'oneshoplab' ),
		);
	}

	/**
	 * One cell of the figures strip.
	 *
	 * @param string $label Label.
	 * @param string $value Value.
	 * @param bool   $bad   Draw it as a problem.
	 */
	private static function render_fact( string $label, string $value, bool $bad = false ): void {
		?>
		<div class="osl-fact<?php echo $bad ? ' is-bad' : ''; ?>">
			<p class="osl-fact__label"><?php echo esc_html( $label ); ?></p>
			<p class="osl-fact__value"><?php echo esc_html( $value ); ?></p>
		</div>
		<?php
	}

	/**
	 * Site-key card: the one thing a merchant has to do here.
	 *
	 * @param bool $has_key Whether a key is stored.
	 */
	private static function render_key_card( bool $has_key ): void {
		self::card_open( 'dashicons-admin-network', __( 'Site key', 'oneshoplab' ) );
		?>
		<p class="osl-note"><?php esc_html_e( 'Create the key in OneShopLab (site settings › Integrations), then paste it below. It is a password: it is stored encrypted and never shown again.', 'oneshoplab' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="oneshoplab_save_key" />
			<?php wp_nonce_field( 'oneshoplab_save_key' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="oneshoplab_site_key"><?php esc_html_e( 'Site key', 'oneshoplab' ); ?></label></th>
					<td>
						<input type="password" id="oneshoplab_site_key" name="oneshoplab_site_key" class="regular-text" autocomplete="off" spellcheck="false" placeholder="osl_live_…" />
						<?php if ( $has_key ) : ?>
							<p class="description osl-key-hint">
								<?php
								/* translators: %s: key prefix */
								printf( esc_html__( 'A key starting with %s is saved. Paste a new key to replace it.', 'oneshoplab' ), '<code>' . esc_html( OSL_State::key_prefix() ) . '…</code>' );
								?>
							</p>
						<?php endif; ?>
					</td>
				</tr>
			</table>
			<p class="osl-actions">
				<?php submit_button( __( 'Save', 'oneshoplab' ), 'primary', 'submit', false ); ?>
			</p>
		</form>
		<?php if ( $has_key ) : ?>
			<p class="osl-actions osl-card__actions">
				<?php self::action_button( 'oneshoplab_clear_key', __( 'Remove the key', 'oneshoplab' ), 'delete' ); ?>
			</p>
		<?php endif; ?>
		<?php
		self::card_close();
	}

	/**
	 * Instant-updates card: whether OneShopLab can reach this site directly,
	 * and a Test button that proves it end to end.
	 *
	 * @param bool  $has_key Whether a key is stored.
	 * @param array $status  Status option.
	 */
	private static function render_webhook_card( bool $has_key, array $status ): void {
		$state  = $has_key ? OSL_Webhook::state() : OSL_Webhook::STATE_OFF;
		$active = OSL_Webhook::STATE_ACTIVE === $state;
		self::card_open( 'dashicons-update', __( 'Instant updates', 'oneshoplab' ) );
		?>
		<p class="osl-note"><?php esc_html_e( 'OneShopLab tells your shop the moment you approve a change, so it is applied in seconds instead of waiting for the next five-minute check.', 'oneshoplab' ); ?></p>
		<p class="osl-live <?php echo $active ? 'is-ok' : 'is-off'; ?>">
			<span class="osl-dot" aria-hidden="true"></span>
			<?php if ( $active ) : ?>
				<?php esc_html_e( 'enabled', 'oneshoplab' ); ?>
				<?php $last_ping = (int) ( $status['webhook_last_ping'] ?? 0 ); ?>
				<?php if ( $last_ping > 0 ) : ?>
					<span class="osl-live__when">
						<?php
						/* translators: %s: human time diff */
						printf( esc_html__( '(last test %s)', 'oneshoplab' ), esc_html( self::ago( $last_ping ) ) );
						?>
					</span>
				<?php endif; ?>
			<?php else : ?>
				<?php esc_html_e( 'not available (checking every 5 minutes)', 'oneshoplab' ); ?>
			<?php endif; ?>
		</p>
		<?php if ( OSL_Webhook::STATE_FORBIDDEN === $state ) : ?>
			<p class="osl-check__fix"><?php esc_html_e( 'This key has no webhook permission: create a new key in OneShopLab and paste it here.', 'oneshoplab' ); ?></p>
		<?php elseif ( OSL_Webhook::STATE_ERROR === $state && ! empty( $status['webhook_error']['message'] ) ) : ?>
			<p class="osl-check__fix"><?php echo esc_html( (string) $status['webhook_error']['message'] ); ?></p>
		<?php endif; ?>
		<?php if ( $active ) : ?>
			<p class="osl-actions osl-card__actions">
				<button type="button" class="button" id="oneshoplab-webhook-test"><?php esc_html_e( 'Test', 'oneshoplab' ); ?></button>
			</p>
			<span class="osl-live-result" id="oneshoplab-webhook-result" aria-live="polite"></span>
		<?php endif; ?>
		<?php
		self::card_close();
	}

	/**
	 * Diagnostics: the four pre-flight checks, each failing one followed by the
	 * fix in plain words. Shown whether or not a site key is saved — a shop
	 * that cannot write into its media folder should know before connecting.
	 */
	private static function render_health(): void {
		$lines = OSL_Health::lines( OSL_Health::report() );
		self::card_open( 'dashicons-admin-tools', __( 'Diagnostics', 'oneshoplab' ) );
		?>
		<p class="osl-note"><?php esc_html_e( 'They all have to say OK for an approved change to be applied.', 'oneshoplab' ); ?></p>
		<div class="osl-checks">
			<?php foreach ( $lines as $line ) : ?>
				<div class="osl-check <?php echo $line['ok'] ? 'is-ok' : 'is-bad'; ?>">
					<p class="osl-check__head">
						<span class="osl-dot" aria-hidden="true"></span>
						<?php echo esc_html( $line['label'] ); ?>
						<span class="osl-check__state"><?php echo esc_html( $line['state'] ); ?></span>
					</p>
					<?php if ( '' !== $line['fix'] ) : ?>
						<p class="osl-check__fix"><?php echo esc_html( $line['fix'] ); ?></p>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<p class="osl-actions osl-card__actions">
			<?php self::action_button( 'oneshoplab_health_recheck', __( 'Re-check', 'oneshoplab' ) ); ?>
		</p>
		<?php
		self::card_close();
	}

	/**
	 * What OneShopLab actually changed, most recent first.
	 *
	 * @param array $log Change log entries.
	 */
	private static function render_log( array $log ): void {
		self::card_open( 'dashicons-list-view', __( 'Last applied changes', 'oneshoplab' ) );
		if ( empty( $log ) ) {
			?>
			<p class="osl-empty"><?php esc_html_e( 'No change has been applied yet. Approve one in OneShopLab and it appears here.', 'oneshoplab' ); ?></p>
			<?php
			self::card_close();
			return;
		}
		?>
		<div class="osl-table">
			<table class="widefat striped">
				<thead><tr>
					<th class="osl-col-when"><?php esc_html_e( 'When', 'oneshoplab' ); ?></th>
					<th><?php esc_html_e( 'Product', 'oneshoplab' ); ?></th>
					<th><?php esc_html_e( 'Field', 'oneshoplab' ); ?></th>
					<th><?php esc_html_e( 'Result', 'oneshoplab' ); ?></th>
					<th><?php esc_html_e( 'Details', 'oneshoplab' ); ?></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $log as $entry ) : ?>
					<tr>
						<td class="osl-col-when"><?php echo esc_html( self::format_date( (int) ( $entry['at'] ?? 0 ) ) ); ?></td>
						<td>
							<?php $title = get_the_title( (int) ( $entry['product_id'] ?? 0 ) ); ?>
							<?php if ( $title ) : ?>
								<a href="<?php echo esc_url( get_edit_post_link( (int) $entry['product_id'] ) ?: '#' ); ?>"><?php echo esc_html( $title ); ?></a>
							<?php else : ?>
								#<?php echo esc_html( (string) ( $entry['product_id'] ?? '' ) ); ?>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( self::field_label( (string) ( $entry['field'] ?? '' ) ) ); ?></td>
						<td>
							<?php $result = (string) ( $entry['status'] ?? '' ); ?>
							<span class="osl-tag <?php echo esc_attr( self::result_class( $result ) ); ?>"><?php echo esc_html( self::result_label( $result ) ); ?></span>
						</td>
						<td><?php echo esc_html( (string) ( $entry['message'] ?? '' ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
		self::card_close();
	}

	/**
	 * Opens a native admin box. Kept in one place so every card on the page
	 * carries the same heading structure.
	 *
	 * @param string $icon  Dashicon class.
	 * @param string $title Heading.
	 * @param string $class Extra classes on the box.
	 */
	private static function card_open( string $icon, string $title, string $class = '' ): void {
		?>
		<div class="<?php echo esc_attr( trim( 'postbox ' . $class ) ); ?>">
			<div class="postbox-header">
				<h2 class="hndle">
					<span class="dashicons <?php echo esc_attr( $icon ); ?>" aria-hidden="true"></span>
					<?php echo esc_html( $title ); ?>
				</h2>
			</div>
			<div class="inside">
		<?php
	}

	/**
	 * Closes {@see self::card_open()}.
	 */
	private static function card_close(): void {
		?>
			</div>
		</div>
		<?php
	}

	/**
	 * Inline admin-post button.
	 *
	 * @param string $action   Action name (also the nonce action).
	 * @param string $label    Button label.
	 * @param string $type     primary|secondary|delete.
	 * @param bool   $disabled Disabled state.
	 */
	private static function action_button( string $action, string $label, string $type = 'secondary', bool $disabled = false ): void {
		$class = 'button';
		if ( 'primary' === $type ) {
			$class = 'button button-primary';
		} elseif ( 'delete' === $type ) {
			$class = 'button button-link-delete';
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" />
			<?php wp_nonce_field( $action ); ?>
			<button type="submit" class="<?php echo esc_attr( $class ); ?>" <?php disabled( $disabled ); ?>><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/**
	 * Feedback after an action.
	 *
	 * @param string $msg  Code.
	 * @param string $text Detail.
	 */
	private static function render_message( string $msg, string $text ): void {
		$map = array(
			'saved'            => array( 'success', __( 'Key saved and connection verified. Your products are being sent now — the status turns green within a minute.', 'oneshoplab' ) ),
			'saved_but_failed' => array( 'error', __( 'Key saved, but OneShopLab refused it:', 'oneshoplab' ) ),
			'invalid_key'      => array( 'error', __( 'That does not look like a site key. It starts with osl_live_ and has no spaces.', 'oneshoplab' ) ),
			'cleared'          => array( 'info', __( 'Key removed. The plugin is paused.', 'oneshoplab' ) ),
			'test_ok'          => array( 'success', __( 'Connected to OneShopLab.', 'oneshoplab' ) ),
			'sync_started'     => array( 'success', __( 'Full sync started. It runs in the background, 200 products at a time.', 'oneshoplab' ) ),
			'poll_done'        => array( 'success', __( 'Checked for changes.', 'oneshoplab' ) ),
			'health_rechecked' => array( 'info', __( 'Diagnostics checked again.', 'oneshoplab' ) ),
			'error'            => array( 'error', __( 'Something went wrong:', 'oneshoplab' ) ),
		);
		if ( ! isset( $map[ $msg ] ) ) {
			return;
		}
		list( $type, $label ) = $map[ $msg ];
		if ( 'poll_done' === $msg && '' !== $text ) {
			/* translators: %s: number of changes */
			$text = sprintf( _n( '%s change applied.', '%s changes applied.', (int) $text, 'oneshoplab' ), $text );
		}
		printf( '<div class="notice notice-%s is-dismissible"><p>%s %s</p></div>', esc_attr( $type ), esc_html( $label ), esc_html( $text ) );
	}

	/**
	 * Site name + plan.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function site_label( array $status ): string {
		if ( empty( $status['site']['name'] ) ) {
			return '—';
		}
		return $status['site']['name'] . ( ! empty( $status['site']['plan'] ) ? ' (' . $status['site']['plan'] . ')' : '' );
	}

	/**
	 * Last sync line.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function sync_label( array $status ): string {
		if ( empty( $status['last_sync'] ) ) {
			return __( 'Never', 'oneshoplab' );
		}
		$r = $status['last_sync_result'] ?? array();
		return sprintf(
			/* translators: 1: relative time, 2: inserted, 3: updated, 4: archived, 5: unchanged */
			__( '%1$s — %2$d added, %3$d updated, %4$d archived, %5$d unchanged', 'oneshoplab' ),
			self::ago( (int) $status['last_sync'] ),
			(int) ( $r['inserted'] ?? 0 ),
			(int) ( $r['updated'] ?? 0 ),
			(int) ( $r['archived'] ?? 0 ),
			(int) ( $r['unchanged'] ?? 0 )
		);
	}

	/**
	 * Product count line.
	 *
	 * @param array      $status Status.
	 * @param array|null $full   Full-sync progress.
	 * @param int        $queue  Queued items.
	 * @return string
	 */
	private static function products_label( array $status, ?array $full, int $queue ): string {
		$count = (int) ( $status['product_count'] ?? OSL_Sync::count_products() );
		/* translators: %d: number of products */
		$label = sprintf( _n( '%d product', '%d products', $count, 'oneshoplab' ), $count );
		if ( null !== $full ) {
			/* translators: 1: products sent so far, 2: total */
			$label .= ' — ' . sprintf( __( 'full sync running (%1$d / %2$d sent)', 'oneshoplab' ), (int) $full['sent'], (int) $full['total'] );
		} elseif ( $queue > 0 ) {
			/* translators: %d: number of queued products */
			$label .= ' — ' . sprintf( _n( '%d waiting to be sent', '%d waiting to be sent', $queue, 'oneshoplab' ), $queue );
		}
		return $label;
	}

	/**
	 * Pending changes line.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function pending_label( array $status ): string {
		if ( empty( $status['last_poll'] ) ) {
			return __( 'Not checked yet', 'oneshoplab' );
		}
		$pending = (int) ( $status['pending_changes'] ?? 0 );
		/* translators: 1: number of pending changes, 2: relative time */
		return sprintf( __( '%1$d pending (checked %2$s)', 'oneshoplab' ), $pending, self::ago( (int) $status['last_poll'] ) );
	}

	/**
	 * Last error line.
	 *
	 * @param array $status Status.
	 * @return string
	 */
	private static function error_label( array $status ): string {
		if ( empty( $status['last_error']['code'] ) ) {
			return __( 'None', 'oneshoplab' );
		}
		$e = $status['last_error'];
		return OSL_Client::explain( (string) $e['code'], (string) ( $e['message'] ?? '' ) ) . ' (' . self::ago( (int) ( $e['at'] ?? 0 ) ) . ')';
	}

	/**
	 * Field label.
	 *
	 * @param string $field Field.
	 * @return string
	 */
	private static function field_label( string $field ): string {
		$labels = array(
			'title'       => __( 'Title', 'oneshoplab' ),
			'description' => __( 'Description', 'oneshoplab' ),
			'tags'        => __( 'Tags', 'oneshoplab' ),
			'images'      => __( 'Images', 'oneshoplab' ),
		);
		return $labels[ $field ] ?? $field;
	}

	/**
	 * Outcome label.
	 *
	 * @param string $status Outcome.
	 * @return string
	 */
	private static function result_label( string $status ): string {
		$labels = array(
			'applied'  => __( 'Applied', 'oneshoplab' ),
			'failed'   => __( 'Failed', 'oneshoplab' ),
			'skipped'  => __( 'Skipped', 'oneshoplab' ),
			'conflict' => __( 'Conflict', 'oneshoplab' ),
		);
		return $labels[ $status ] ?? $status;
	}

	/**
	 * Colour of the outcome chip in the change log.
	 *
	 * @param string $status Outcome.
	 * @return string CSS class.
	 */
	private static function result_class( string $status ): string {
		$classes = array(
			'applied'  => 'is-ok',
			'failed'   => 'is-bad',
			'conflict' => 'is-warn',
		);
		return $classes[ $status ] ?? '';
	}

	/**
	 * "3 minutes ago".
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private static function ago( int $timestamp ): string {
		if ( $timestamp <= 0 ) {
			return __( 'Never', 'oneshoplab' );
		}
		/* translators: %s: human time diff */
		return sprintf( __( '%s ago', 'oneshoplab' ), human_time_diff( $timestamp, time() ) );
	}

	/**
	 * Localised date/time.
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private static function format_date( int $timestamp ): string {
		return $timestamp > 0 ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : '—';
	}
}
