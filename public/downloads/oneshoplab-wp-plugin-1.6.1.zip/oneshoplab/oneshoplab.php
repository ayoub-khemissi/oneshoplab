<?php
/**
 * Plugin Name:       OneShopLab
 * Plugin URI:        https://oneshoplab.com
 * Description:       Connects your WooCommerce catalogue to OneShopLab: sends your products, then applies the titles, descriptions, tags and images you approve in OneShopLab.
 * Version:           1.6.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            OneShopLab
 * Author URI:        https://oneshoplab.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       oneshoplab
 * Domain Path:       /languages
 * WC requires at least: 7.0
 * WC tested up to:   11.0
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OSL_VERSION', '1.6.1' );
define( 'OSL_PLUGIN_FILE', __FILE__ );
define( 'OSL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'OSL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'OSL_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'OSL_MIN_PHP', '7.4' );
define( 'OSL_MIN_WP', '6.0' );
define( 'OSL_MIN_WC', '7.0' );
define( 'OSL_BATCH_SIZE', 200 );

/**
 * Autoload `OSL_Foo_Bar` from `includes/class-osl-foo-bar.php`.
 *
 * @param string $class_name Class name.
 */
spl_autoload_register(
	static function ( string $class_name ): void {
		if ( 0 !== strpos( $class_name, 'OSL_' ) ) {
			return;
		}
		$file = OSL_PLUGIN_DIR . 'includes/class-' . str_replace( '_', '-', strtolower( $class_name ) ) . '.php';
		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

register_activation_hook( __FILE__, array( 'OSL_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'OSL_Plugin', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'OSL_Plugin', 'boot' ), 20 );
