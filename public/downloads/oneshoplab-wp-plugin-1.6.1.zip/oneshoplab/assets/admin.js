/*
 * OneShopLab — settings screen behaviour.
 *
 * Two jobs. The "Test" button of the Instant updates card asks OneShopLab to
 * send a `ping` event, then watches for its arrival for ten seconds. And any
 * button carrying `data-osl-confirm` asks its question before submitting —
 * the guard is server-side (nonce + capability), this is only the courtesy of
 * asking first, so the action still works when scripts are blocked.
 *
 * Strings, the admin-ajax URL and the nonce arrive in `oneshoplabAdmin`
 * (wp_localize_script). Unminified and dependency-free on purpose: this file
 * is only loaded on the plugin's own admin pages.
 */

( function () {
	'use strict';

	var cfg = window.oneshoplabAdmin || {};
	var TRIES = 10;

	function ready( fn ) {
		if ( 'loading' === document.readyState ) {
			document.addEventListener( 'DOMContentLoaded', fn );
		} else {
			fn();
		}
	}

	function call( action, extra ) {
		var body = new URLSearchParams();
		var key;
		body.append( 'action', action );
		body.append( 'nonce', cfg.nonce );
		for ( key in extra || {} ) {
			if ( Object.prototype.hasOwnProperty.call( extra, key ) ) {
				body.append( key, extra[ key ] );
			}
		}
		return fetch( cfg.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} ).then( function ( response ) {
			return response.json();
		} );
	}

	ready( function () {
		document.addEventListener( 'click', function ( event ) {
			var trigger = event.target && event.target.closest ? event.target.closest( '[data-osl-confirm]' ) : null;
			if ( trigger && ! window.confirm( trigger.getAttribute( 'data-osl-confirm' ) ) ) {
				event.preventDefault();
			}
		} );
	} );

	ready( function () {
		var button = document.getElementById( 'oneshoplab-webhook-test' );
		var output = document.getElementById( 'oneshoplab-webhook-result' );

		if ( ! button || ! output || ! cfg.ajaxUrl ) {
			return;
		}

		function say( text, state ) {
			output.textContent = text;
			output.className = 'osl-live-result' + ( state ? ' is-' + state : '' );
		}

		function done( text, state ) {
			say( text, state );
			button.disabled = false;
		}

		function watch( sentAt ) {
			var tries = 0;
			var timer = setInterval( function () {
				tries++;
				call( 'oneshoplab_webhook_ping_status', { sent_at: sentAt } ).then( function ( status ) {
					if ( status && status.success && status.data.arrived ) {
						clearInterval( timer );
						done( cfg.arrived, 'ok' );
					} else if ( tries >= TRIES ) {
						clearInterval( timer );
						done( cfg.timeout, 'bad' );
					}
				} ).catch( function () {} );
			}, 1000 );
		}

		button.addEventListener( 'click', function () {
			button.disabled = true;
			say( cfg.sending );
			call( 'oneshoplab_webhook_ping' ).then( function ( response ) {
				if ( ! response || ! response.success ) {
					var detail = response && response.data && response.data.message ? ' ' + response.data.message : '';
					done( cfg.failed + detail, 'bad' );
					return;
				}
				say( cfg.waiting );
				watch( response.data.sent_at );
			} ).catch( function () {
				done( cfg.failed, 'bad' );
			} );
		} );
	} );
}() );
