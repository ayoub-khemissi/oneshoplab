<?php
/**
 * The `images` change payload of the v1.1 protocol (OneShopLab
 * `docs/api/IMAGE-OPS.md` §2). Two shapes are valid:
 *
 *   - a plain array `[{src, alt}]` — the historical "replace the whole
 *     gallery" shape, still sent to stores that never reported an image id;
 *   - `{ "v": 1, "ops": [ … ] }` — an ordered operation list.
 *
 * This class is the pure-PHP half: it turns an ops payload plus the product's
 * current attachment ids into a *plan* — the gallery order to write, the
 * images still to download, the alt texts to set, and the ops that could not
 * be carried out. It never touches WordPress, so `tests/run.php` can drive it.
 * {@see OSL_Changes} executes the plan (sideloading, `set_image_id()`, alt meta).
 *
 * Semantics mirror the server's simulation (`entities/product-change/lib/image-ops.ts`):
 *   - ops apply in order; `new:<n>` is the n-th image *introduced earlier* in
 *     the same list, and the counter advances even when the op that introduced
 *     it was skipped, so numbering computed by the server always lines up;
 *   - an op whose `target` is no longer on the product is skipped, not fatal,
 *     and collected as `"<index>:<verb>"`;
 *   - `remove` detaches, it never deletes the media file, and it is skipped
 *     rather than leaving the product with no image at all;
 *   - a malformed payload (unknown verb, missing image, forward `new:` ref) is
 *     a protocol error, not a store difference: it throws.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Image operation planning (pure PHP).
 */
final class OSL_Image_Ops {

	/** Payload version this build understands. */
	public const VERSION = 1;

	/** Same bound as the server's `MAX_IMAGE_OPS`. */
	public const MAX_OPS = 60;

	/** Longest `sourceImageId` / reference the API accepts. */
	public const MAX_REF = 255;

	/** The verbs this plugin executes — reported verbatim as `capabilities.imageOps`. */
	public const VERBS = array( 'set_featured', 'append', 'replace', 'remove', 'set_alt', 'reorder' );

	/**
	 * Is this change value the ops shape rather than the plain array?
	 *
	 * @param mixed $value `product_changes.value`.
	 * @return bool
	 */
	public static function is_ops_payload( $value ): bool {
		return is_array( $value )
			&& isset( $value['v'] )
			&& self::VERSION === (int) $value['v']
			&& isset( $value['ops'] )
			&& is_array( $value['ops'] );
	}

	/**
	 * Replays an ops payload over the product's current gallery.
	 *
	 * @param array    $value   `{v, ops}` payload.
	 * @param string[] $current Attachment ids as strings, gallery order (featured first).
	 * @return array {
	 *     @type string[]                     $order   Refs in final order: existing ids and `new:<n>`.
	 *     @type array<int,array{src:string,alt:?string}> $new  Images to download, keyed by their `<n>`.
	 *     @type array<string,string>         $alt     Alt text to write, keyed by ref (`set_alt` only).
	 *     @type string[]                     $skipped `"<index>:<verb>"` of the ops that were skipped.
	 * }
	 * @throws RuntimeException When the payload does not follow the protocol.
	 */
	public static function plan( array $value, array $current ): array {
		if ( ! self::is_ops_payload( $value ) ) {
			throw new RuntimeException( 'not an image operation list (expected {"v":1,"ops":[…]})' );
		}
		$ops = array_values( $value['ops'] );
		if ( empty( $ops ) ) {
			throw new RuntimeException( 'the operation list is empty' );
		}
		if ( count( $ops ) > self::MAX_OPS ) {
			throw new RuntimeException( esc_html( 'the operation list exceeds ' . self::MAX_OPS . ' operations' ) );
		}

		$order = array();
		foreach ( $current as $id ) {
			$id = (string) $id;
			if ( '' !== $id ) {
				$order[] = $id;
			}
		}

		$new        = array();
		$alt        = array();
		$skipped    = array();
		$introduced = 0;

		foreach ( $ops as $index => $op ) {
			$index = (int) $index;
			if ( ! is_array( $op ) || ! isset( $op['op'] ) || ! in_array( (string) $op['op'], self::VERBS, true ) ) {
				throw new RuntimeException( esc_html( sprintf( 'unknown image operation at index %d', $index ) ) );
			}
			$verb = (string) $op['op'];
			$ref  = $index . ':' . $verb;

			switch ( $verb ) {
				case 'append':
					$new_ref              = 'new:' . $introduced;
					$new[ $introduced ]   = self::image_of( $op, $index );
					++$introduced;
					$order[]              = $new_ref;
					break;

				case 'set_featured':
					$has_image  = isset( $op['image'] );
					$has_target = isset( $op['target'] ) && '' !== (string) $op['target'];
					if ( $has_image === $has_target ) {
						throw new RuntimeException( esc_html( sprintf( 'set_featured at index %d takes exactly one of image or target', $index ) ) );
					}
					if ( $has_image ) {
						$new_ref            = 'new:' . $introduced;
						$new[ $introduced ] = self::image_of( $op, $index );
						++$introduced;
						array_unshift( $order, $new_ref );
						break;
					}
					$target = self::ref_of( $op['target'], $introduced, $index );
					$at     = array_search( $target, $order, true );
					if ( false === $at ) {
						$skipped[] = $ref;
						break;
					}
					array_splice( $order, (int) $at, 1 );
					array_unshift( $order, $target );
					break;

				case 'replace':
					$target = self::ref_of( isset( $op['target'] ) ? $op['target'] : null, $introduced, $index );
					$image  = self::image_of( $op, $index );
					// The counter advances even when the target is gone, so the
					// numbering the server computed offline stays valid.
					$new_ref            = 'new:' . $introduced;
					$new[ $introduced ] = $image;
					++$introduced;
					$at = array_search( $target, $order, true );
					if ( false === $at ) {
						$skipped[] = $ref;
						break;
					}
					array_splice( $order, (int) $at, 1, array( $new_ref ) );
					break;

				case 'remove':
					$target = self::ref_of( isset( $op['target'] ) ? $op['target'] : null, $introduced, $index );
					$at     = array_search( $target, $order, true );
					if ( false === $at ) {
						$skipped[] = $ref;
						break;
					}
					if ( count( $order ) <= 1 ) {
						// A product with no image shows a placeholder in the shop.
						$skipped[] = $ref;
						break;
					}
					array_splice( $order, (int) $at, 1 );
					break;

				case 'set_alt':
					$target = self::ref_of( isset( $op['target'] ) ? $op['target'] : null, $introduced, $index );
					if ( ! in_array( $target, $order, true ) ) {
						$skipped[] = $ref;
						break;
					}
					$alt[ $target ] = isset( $op['alt'] ) ? (string) $op['alt'] : '';
					break;

				case 'reorder':
					if ( ! isset( $op['order'] ) || ! is_array( $op['order'] ) || empty( $op['order'] ) ) {
						throw new RuntimeException( esc_html( sprintf( 'reorder at index %d needs a non-empty order', $index ) ) );
					}
					$rank     = array();
					$position = 0;
					foreach ( $op['order'] as $wanted ) {
						$wanted = self::ref_of( $wanted, $introduced, $index );
						if ( ! isset( $rank[ $wanted ] ) ) {
							$rank[ $wanted ] = $position;
						}
						++$position;
					}
					$order = self::rank_sort( $order, $rank );
					break;
			}
		}

		return array(
			'order'   => array_values( $order ),
			'new'     => $new,
			'alt'     => $alt,
			'skipped' => $skipped,
		);
	}

	/**
	 * `new:<n>` → n, or null for a store id.
	 *
	 * @param string $ref Reference.
	 * @return int|null
	 */
	public static function new_index( string $ref ): ?int {
		return preg_match( '/^new:(\d+)$/', $ref, $m ) ? (int) $m[1] : null;
	}

	/**
	 * Validates one image reference: a non-empty short string, and — when it is
	 * a `new:<n>` — one the list has already introduced (a forward reference is
	 * a client bug, never a store difference).
	 *
	 * @param mixed $value      Raw reference.
	 * @param int   $introduced Images introduced so far.
	 * @param int   $index      Op index (for the message).
	 * @return string
	 * @throws RuntimeException When the reference cannot be used.
	 */
	private static function ref_of( $value, int $introduced, int $index ): string {
		if ( ! is_string( $value ) && ! is_int( $value ) ) {
			throw new RuntimeException( esc_html( sprintf( 'the operation at index %d has no usable target', $index ) ) );
		}
		$ref = (string) $value;
		if ( '' === $ref || strlen( $ref ) > self::MAX_REF ) {
			throw new RuntimeException( esc_html( sprintf( 'the operation at index %d has no usable target', $index ) ) );
		}
		$n = self::new_index( $ref );
		if ( null !== $n && $n >= $introduced ) {
			throw new RuntimeException( esc_html( sprintf( 'the operation at index %d refers to %s before it exists', $index, $ref ) ) );
		}
		return $ref;
	}

	/**
	 * Validates the `image` of an op.
	 *
	 * @param array $op    Operation.
	 * @param int   $index Op index (for the message).
	 * @return array {src, alt}
	 * @throws RuntimeException When there is no usable source URL.
	 */
	private static function image_of( array $op, int $index ): array {
		$image = isset( $op['image'] ) && is_array( $op['image'] ) ? $op['image'] : array();
		$src   = isset( $image['src'] ) ? trim( (string) $image['src'] ) : '';
		if ( '' === $src ) {
			throw new RuntimeException( esc_html( sprintf( 'the operation at index %d has no image source', $index ) ) );
		}
		$alt = isset( $image['alt'] ) && null !== $image['alt'] ? (string) $image['alt'] : null;
		return array(
			'src' => $src,
			'alt' => $alt,
		);
	}

	/**
	 * Stable sort by rank; refs the reorder does not name keep their relative
	 * order at the end. Written by hand because `usort()` is only stable from
	 * PHP 8.0 and the plugin floor is 7.4.
	 *
	 * @param string[]          $order Current refs.
	 * @param array<string,int> $rank  ref → wanted position.
	 * @return string[]
	 */
	private static function rank_sort( array $order, array $rank ): array {
		$decorated = array();
		foreach ( array_values( $order ) as $i => $item ) {
			$decorated[] = array( isset( $rank[ $item ] ) ? $rank[ $item ] : PHP_INT_MAX, $i, $item );
		}
		usort(
			$decorated,
			static function ( array $a, array $b ): int {
				return $a[0] === $b[0] ? $a[1] <=> $b[1] : $a[0] <=> $b[0];
			}
		);
		$out = array();
		foreach ( $decorated as $item ) {
			$out[] = $item[2];
		}
		return $out;
	}
}
