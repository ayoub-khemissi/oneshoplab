<?php
/**
 * Admin colour scheme → the three accent values the settings stylesheet needs.
 *
 * WordPress ships eight colour schemes plus Fresh, and a user switches them in
 * their profile. They only repaint the admin *menu* and toolbar — the content
 * area, where this plugin's page lives, stays light in all of them — so the
 * page's greens, ambers, reds and greys are fixed and only the accent follows
 * the scheme. Each scheme declares that accent as `$highlight-color` in
 * `wp-admin/css/colors/<scheme>/colors.scss`; {@see self::SCHEME_ACCENTS} is
 * that list, and {@see self::pick_accent()} is the fallback for a scheme a
 * plugin or theme registered itself.
 *
 * The highlight colour is not used as text without a check first. All nine
 * core ones happen to clear 4.5:1 against the white card background, but only
 * just — Blue, Light and Sunrise sit at 4.58 — and a colour scheme registered
 * by another plugin or a theme has no such guarantee. {@see self::ink()}
 * therefore walks the same hue towards black until it is readable, and that is
 * what text uses; rules, borders and the mark keep the raw highlight, where
 * contrast does not apply. The unit tests assert the invariant over the whole
 * core table.
 *
 * Everything in this class is pure PHP (no WordPress) and unit-tested.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Accent derivation for the admin colour schemes.
 */
final class OSL_Admin_Color {

	/** Fresh, the default scheme. */
	public const DEFAULT_ACCENT = '#2271b1';

	/**
	 * `$highlight-color` of every core scheme, read from
	 * `wp-admin/css/colors/<scheme>/colors.scss` (WordPress 6.0 → 7.1; the
	 * values have not moved since 5.3). The registered `->colors` swatches
	 * cannot be used instead: their order is not consistent between schemes
	 * (Fresh puts the highlight third, Midnight fourth).
	 */
	public const SCHEME_ACCENTS = array(
		'fresh'     => '#2271b1',
		'light'     => '#007cba',
		'modern'    => '#3858e9',
		'blue'      => '#437aa8',
		'coffee'    => '#916745',
		'ectoplasm' => '#646c3e',
		'midnight'  => '#cf4339',
		'ocean'     => '#567958',
		'sunrise'   => '#ad631e',
	);

	/** Contrast ratio the accent must reach against the card background. */
	public const MIN_CONTRAST = 4.5;

	/**
	 * `#rgb` / `#rrggbb` / `rrggbb` → lower-case `#rrggbb`, or null.
	 *
	 * @param string $hex Colour.
	 * @return string|null
	 */
	public static function normalize( string $hex ): ?string {
		$hex = strtolower( trim( $hex ) );
		if ( '' !== $hex && '#' === $hex[0] ) {
			$hex = substr( $hex, 1 );
		}
		if ( 1 === preg_match( '/^[0-9a-f]{3}$/', $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		return 1 === preg_match( '/^[0-9a-f]{6}$/', $hex ) ? '#' . $hex : null;
	}

	/**
	 * Colour → `array( r, g, b )` in 0-255, or null when unreadable.
	 *
	 * @param string $hex Colour.
	 * @return int[]|null
	 */
	public static function rgb( string $hex ): ?array {
		$normalized = self::normalize( $hex );
		if ( null === $normalized ) {
			return null;
		}
		return array(
			(int) hexdec( substr( $normalized, 1, 2 ) ),
			(int) hexdec( substr( $normalized, 3, 2 ) ),
			(int) hexdec( substr( $normalized, 5, 2 ) ),
		);
	}

	/**
	 * `array( r, g, b )` → `#rrggbb`, clamped.
	 *
	 * @param array $rgb Channels.
	 * @return string
	 */
	public static function hex( array $rgb ): string {
		$out = '#';
		foreach ( array( 0, 1, 2 ) as $channel ) {
			$value = (int) round( (float) ( $rgb[ $channel ] ?? 0 ) );
			$value = max( 0, min( 255, $value ) );
			$out  .= str_pad( dechex( $value ), 2, '0', STR_PAD_LEFT );
		}
		return $out;
	}

	/**
	 * WCAG relative luminance.
	 *
	 * @param string $hex Colour.
	 * @return float 0 (black) → 1 (white); -1 when unreadable.
	 */
	public static function luminance( string $hex ): float {
		$rgb = self::rgb( $hex );
		if ( null === $rgb ) {
			return -1.0;
		}
		$linear = array();
		foreach ( $rgb as $channel ) {
			$value    = $channel / 255;
			$linear[] = $value <= 0.04045 ? $value / 12.92 : pow( ( $value + 0.055 ) / 1.055, 2.4 );
		}
		return 0.2126 * $linear[0] + 0.7152 * $linear[1] + 0.0722 * $linear[2];
	}

	/**
	 * WCAG contrast ratio between two colours (1 → 21).
	 *
	 * @param string $one Colour.
	 * @param string $two Colour.
	 * @return float 0 when either is unreadable.
	 */
	public static function contrast( string $one, string $two ): float {
		$a = self::luminance( $one );
		$b = self::luminance( $two );
		if ( $a < 0 || $b < 0 ) {
			return 0.0;
		}
		$light = max( $a, $b );
		$dark  = min( $a, $b );
		return ( $light + 0.05 ) / ( $dark + 0.05 );
	}

	/**
	 * Linear blend between two colours.
	 *
	 * @param string $from   Colour.
	 * @param string $to     Colour blended in.
	 * @param float  $amount 0 → $from, 1 → $to.
	 * @return string `#rrggbb`; $from unchanged when either is unreadable.
	 */
	public static function mix( string $from, string $to, float $amount ): string {
		$a = self::rgb( $from );
		$b = self::rgb( $to );
		if ( null === $a || null === $b ) {
			return self::normalize( $from ) ?? self::DEFAULT_ACCENT;
		}
		$amount = max( 0.0, min( 1.0, $amount ) );
		$mixed  = array();
		foreach ( array( 0, 1, 2 ) as $channel ) {
			$mixed[ $channel ] = $a[ $channel ] + ( $b[ $channel ] - $a[ $channel ] ) * $amount;
		}
		return self::hex( $mixed );
	}

	/**
	 * The same hue, darkened just enough to be readable as text on $background.
	 *
	 * Walks towards black in 5% steps and stops at the first shade that clears
	 * {@see self::MIN_CONTRAST}; a colour that is already readable comes back
	 * untouched. Blending towards black keeps the hue, which is the point:
	 * Midnight's accent stays Midnight red, only darker.
	 *
	 * @param string $hex        Colour.
	 * @param string $background Surface the text sits on.
	 * @param float  $min        Required contrast ratio.
	 * @return string `#rrggbb`.
	 */
	public static function ink( string $hex, string $background = '#ffffff', float $min = self::MIN_CONTRAST ): string {
		$normalized = self::normalize( $hex );
		if ( null === $normalized ) {
			return self::DEFAULT_ACCENT;
		}
		for ( $step = 0; $step <= 20; $step++ ) {
			$candidate = self::mix( $normalized, '#000000', $step * 0.05 );
			if ( self::contrast( $candidate, $background ) >= $min ) {
				return $candidate;
			}
		}
		return '#000000';
	}

	/**
	 * `rgba(r, g, b, a)` for a hex colour, for tinted backgrounds.
	 *
	 * @param string $hex   Colour.
	 * @param float  $alpha 0 → 1.
	 * @return string
	 */
	public static function rgba( string $hex, float $alpha ): string {
		$rgb = self::rgb( $hex );
		if ( null === $rgb ) {
			$rgb = self::rgb( self::DEFAULT_ACCENT );
		}
		$alpha = max( 0.0, min( 1.0, $alpha ) );
		return sprintf( 'rgba(%d, %d, %d, %s)', $rgb[0], $rgb[1], $rgb[2], rtrim( rtrim( number_format( $alpha, 2, '.', '' ), '0' ), '.' ) );
	}

	/**
	 * Fallback for a colour scheme registered outside core: the most colourful
	 * swatch of its palette, which is what a scheme uses to highlight the
	 * current menu item. Greys (chroma 0) are never picked.
	 *
	 * @param array $palette Hex colours, as registered with wp_admin_css_color().
	 * @return string|null `#rrggbb`, or null when the palette has no usable colour.
	 */
	public static function pick_accent( array $palette ): ?string {
		$best   = null;
		$chroma = 0;
		foreach ( $palette as $entry ) {
			if ( ! is_string( $entry ) ) {
				continue;
			}
			$rgb = self::rgb( $entry );
			if ( null === $rgb ) {
				continue;
			}
			$spread = max( $rgb ) - min( $rgb );
			if ( $spread > $chroma ) {
				$chroma = $spread;
				$best   = self::normalize( $entry );
			}
		}
		return $best;
	}

	/**
	 * Accent of a colour scheme: the core table first, then the palette
	 * heuristic, then Fresh.
	 *
	 * @param string $scheme  Scheme name (`get_user_option( 'admin_color' )`).
	 * @param array  $palette Swatches registered for it, when known.
	 * @return string `#rrggbb`.
	 */
	public static function accent_for_scheme( string $scheme, array $palette = array() ): string {
		$scheme = strtolower( trim( $scheme ) );
		if ( isset( self::SCHEME_ACCENTS[ $scheme ] ) ) {
			return self::SCHEME_ACCENTS[ $scheme ];
		}
		return self::pick_accent( $palette ) ?? self::DEFAULT_ACCENT;
	}

	/**
	 * The custom properties the stylesheet expects, for one accent.
	 *
	 * All three are printed as literal colours rather than as
	 * `var(--wp-admin-theme-color, …)`. That property looks like the right
	 * source and is not: `wp-includes/css/dist/base-styles/admin-schemes.css`
	 * sets it per scheme (`body.admin-color-midnight { … #cf4339 }`, the same
	 * values as {@see self::SCHEME_ACCENTS}), but that file is only loaded by
	 * the block editor, while `wp-components/style.css` — which WooCommerce
	 * pulls onto every admin page for its command palette — sets a flat
	 * `:root { --wp-admin-theme-color: #3858e9 }`. On a Midnight shop the
	 * property therefore reads Modern blue, and an accent taken from it would
	 * disagree with the tint and the ink computed here.
	 *
	 * The stylesheet still declares `var(--wp-admin-theme-color, #2271b1)` as
	 * its own default, so the page degrades to something scheme-ish rather
	 * than to nothing if this block ever fails to load.
	 *
	 * @param string $accent Scheme highlight colour.
	 * @return array<string,string> Property name => value.
	 */
	public static function variables( string $accent ): array {
		$accent = self::normalize( $accent ) ?? self::DEFAULT_ACCENT;
		return array(
			'--osl-accent'      => $accent,
			'--osl-accent-ink'  => self::ink( $accent ),
			'--osl-accent-soft' => self::rgba( $accent, 0.1 ),
		);
	}

	/**
	 * {@see self::variables()} as a CSS rule.
	 *
	 * @param string $selector CSS selector.
	 * @param string $accent   Scheme highlight colour.
	 * @return string
	 */
	public static function css( string $selector, string $accent ): string {
		$body = '';
		foreach ( self::variables( $accent ) as $property => $value ) {
			$body .= "\t" . $property . ': ' . $value . ";\n";
		}
		return $selector . " {\n" . $body . "}\n";
	}
}
