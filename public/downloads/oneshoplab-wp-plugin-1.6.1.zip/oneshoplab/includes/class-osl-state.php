<?php
/**
 * Per-site persisted state (options + transients). Every option is
 * site-scoped so the plugin is multisite-safe by construction.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Options facade.
 */
final class OSL_State {

	public const OPT_KEY         = 'oneshoplab_site_key';
	public const OPT_KEY_PREFIX  = 'oneshoplab_key_prefix';
	public const OPT_STATUS      = 'oneshoplab_status';
	public const OPT_CURSOR      = 'oneshoplab_changes_cursor';
	public const OPT_CHANGE_LOG  = 'oneshoplab_change_log';
	public const OPT_ACKED       = 'oneshoplab_acked_changes';
	public const OPT_WEBHOOK_SECRET = 'oneshoplab_webhook_secret';
	public const TR_QUEUE        = 'oneshoplab_sync_queue';
	public const TR_FULL_SYNC    = 'oneshoplab_full_sync';
	public const TR_RETRY_AFTER  = 'oneshoplab_retry_after';
	public const TR_HEALTH_UPLOADS = 'oneshoplab_health_uploads';
	public const TR_HEALTH_EGRESS  = 'oneshoplab_health_egress';

	public const KEY_STATE_OK      = 'ok';
	public const KEY_STATE_MISSING = 'missing';
	public const KEY_STATE_REVOKED = 'key_revoked';
	public const KEY_STATE_EXPIRED = 'key_expired';
	public const KEY_STATE_INVALID = 'unauthorized';
	public const KEY_STATE_UNREADABLE = 'unreadable';

	/** All option names, for uninstall. */
	public const ALL_OPTIONS = array(
		self::OPT_KEY,
		self::OPT_KEY_PREFIX,
		self::OPT_STATUS,
		self::OPT_CURSOR,
		self::OPT_CHANGE_LOG,
		self::OPT_ACKED,
		self::OPT_WEBHOOK_SECRET,
	);

	/** All transient names, for uninstall. */
	public const ALL_TRANSIENTS = array(
		self::TR_QUEUE,
		self::TR_FULL_SYNC,
		self::TR_RETRY_AFTER,
		self::TR_HEALTH_UPLOADS,
		self::TR_HEALTH_EGRESS,
	);

	/**
	 * Stores a new site key (encrypted) and resets the auth state.
	 *
	 * @param string $key Plain site key.
	 * @return bool
	 */
	public static function save_key( string $key ): bool {
		$encrypted = OSL_Crypto::encrypt( $key );
		if ( null === $encrypted ) {
			return false;
		}
		update_option( self::OPT_KEY, $encrypted, false );
		update_option( self::OPT_KEY_PREFIX, OSL_Signer::prefix( $key ), false );
		self::update_status(
			array(
				'key_state'  => self::KEY_STATE_OK,
				'last_error' => null,
			)
		);
		return true;
	}

	/**
	 * Removes the key and everything derived from it.
	 */
	public static function clear_key(): void {
		delete_option( self::OPT_KEY );
		delete_option( self::OPT_KEY_PREFIX );
		delete_option( self::OPT_CURSOR );
		delete_transient( self::TR_FULL_SYNC );
		delete_transient( self::TR_QUEUE );
		self::update_status(
			array(
				'key_state' => self::KEY_STATE_MISSING,
				'site'      => null,
				'key'       => null,
			)
		);
	}

	/**
	 * Plain site key, or null when absent/undecryptable.
	 *
	 * @return string|null
	 */
	public static function key(): ?string {
		$stored = get_option( self::OPT_KEY, '' );
		if ( ! is_string( $stored ) || '' === $stored ) {
			return null;
		}
		$plain = OSL_Crypto::decrypt( $stored );
		if ( null === $plain ) {
			self::update_status( array( 'key_state' => self::KEY_STATE_UNREADABLE ) );
			return null;
		}
		return $plain;
	}

	/**
	 * Stores the inbound-webhook secret, encrypted like the site key.
	 *
	 * @param string $secret Plain secret returned by PUT /webhooks/self.
	 * @return bool
	 */
	public static function save_webhook_secret( string $secret ): bool {
		$encrypted = OSL_Crypto::encrypt( $secret );
		if ( null === $encrypted ) {
			return false;
		}
		update_option( self::OPT_WEBHOOK_SECRET, $encrypted, false );
		return true;
	}

	/**
	 * Plain webhook secret, or null when absent/undecryptable.
	 *
	 * @return string|null
	 */
	public static function webhook_secret(): ?string {
		$stored = get_option( self::OPT_WEBHOOK_SECRET, '' );
		if ( ! is_string( $stored ) || '' === $stored ) {
			return null;
		}
		return OSL_Crypto::decrypt( $stored );
	}

	/**
	 * Forgets the webhook secret.
	 */
	public static function clear_webhook_secret(): void {
		delete_option( self::OPT_WEBHOOK_SECRET );
	}

	/**
	 * Whether a key is stored (readable or not).
	 *
	 * @return bool
	 */
	public static function has_key(): bool {
		return '' !== (string) get_option( self::OPT_KEY, '' );
	}

	/**
	 * Display prefix of the stored key — `osl_live_` plus the first three
	 * characters of the secret, and never one character more, whatever an
	 * older version or a hand-edited option happens to hold. Enough for
	 * support to tell two keys apart, useless to anyone else.
	 *
	 * @return string
	 */
	public static function key_prefix(): string {
		return substr( (string) get_option( self::OPT_KEY_PREFIX, '' ), 0, OSL_Signer::PREFIX_LENGTH );
	}

	/**
	 * Status card data.
	 *
	 * @return array
	 */
	public static function status(): array {
		$status = get_option( self::OPT_STATUS, array() );
		return is_array( $status ) ? $status : array();
	}

	/**
	 * Merges fields into the status option.
	 *
	 * @param array $fields Fields.
	 */
	public static function update_status( array $fields ): void {
		update_option( self::OPT_STATUS, array_merge( self::status(), $fields ), false );
	}

	/**
	 * Records an API error on the status card.
	 *
	 * @param WP_Error $error Error.
	 */
	public static function record_error( WP_Error $error ): void {
		self::update_status(
			array(
				'last_error' => array(
					'code'    => $error->get_error_code(),
					'message' => OSL_Logger::redact( $error->get_error_message() ),
					'at'      => time(),
				),
			)
		);
	}

	/**
	 * True when cron work may call the API (key present, not revoked/expired,
	 * no active rate-limit cool-down, not in maintenance).
	 *
	 * @return bool
	 */
	public static function can_work(): bool {
		if ( ! self::has_key() || OSL_Plugin::is_maintenance() ) {
			return false;
		}
		$state = self::status()['key_state'] ?? self::KEY_STATE_OK;
		if ( ! in_array( $state, array( self::KEY_STATE_OK, '' ), true ) ) {
			return false;
		}
		return (int) get_transient( self::TR_RETRY_AFTER ) <= time();
	}

	/**
	 * Marks the key as unusable until a new one is saved.
	 *
	 * @param string $state One of the KEY_STATE_* auth codes.
	 */
	public static function block_key( string $state ): void {
		self::update_status( array( 'key_state' => $state ) );
	}

	/**
	 * Cursor of the changes feed.
	 *
	 * @return string
	 */
	public static function cursor(): string {
		return (string) get_option( self::OPT_CURSOR, '' );
	}

	/**
	 * Stores the cursor.
	 *
	 * @param string $cursor Change id or ''.
	 */
	public static function set_cursor( string $cursor ): void {
		update_option( self::OPT_CURSOR, $cursor, false );
	}

	/**
	 * Locally acknowledged change ids → status (bounded to the last 500).
	 *
	 * @return array<string,string>
	 */
	public static function acked(): array {
		$acked = get_option( self::OPT_ACKED, array() );
		return is_array( $acked ) ? $acked : array();
	}

	/**
	 * Remembers an ack.
	 *
	 * @param string $change_id Change id.
	 * @param string $status    applied|failed|skipped|conflict.
	 */
	public static function remember_ack( string $change_id, string $status ): void {
		$acked               = self::acked();
		$acked[ $change_id ] = $status;
		if ( count( $acked ) > 500 ) {
			$acked = array_slice( $acked, -500, null, true );
		}
		update_option( self::OPT_ACKED, $acked, false );
	}

	/**
	 * Last 50 change-log entries, newest first.
	 *
	 * @return array[]
	 */
	public static function change_log(): array {
		$log = get_option( self::OPT_CHANGE_LOG, array() );
		return is_array( $log ) ? $log : array();
	}

	/**
	 * Prepends a change-log entry.
	 *
	 * @param array $entry id, product_id, product_title, field, status, message, at.
	 *                     `product_title` is the product's name at the time the
	 *                     change was applied; entries written before 1.6.1 do
	 *                     not have it and are read back unchanged.
	 */
	public static function log_change( array $entry ): void {
		$log = self::change_log();
		array_unshift( $log, $entry );
		update_option( self::OPT_CHANGE_LOG, array_slice( $log, 0, 50 ), false );
	}

	/**
	 * Empties the change log. Display-only: the cursor and the acknowledged
	 * change ids stay, so nothing is ever applied twice because of this.
	 */
	public static function clear_change_log(): void {
		delete_option( self::OPT_CHANGE_LOG );
	}

	/**
	 * Pending partial-sync queue: source id → 'upsert'|'archive'.
	 *
	 * @return array<string,string>
	 */
	public static function queue(): array {
		$queue = get_transient( self::TR_QUEUE );
		return is_array( $queue ) ? $queue : array();
	}

	/**
	 * Replaces the queue.
	 *
	 * @param array $queue Queue.
	 */
	public static function set_queue( array $queue ): void {
		if ( empty( $queue ) ) {
			delete_transient( self::TR_QUEUE );
			return;
		}
		set_transient( self::TR_QUEUE, $queue, DAY_IN_SECONDS );
	}
}
