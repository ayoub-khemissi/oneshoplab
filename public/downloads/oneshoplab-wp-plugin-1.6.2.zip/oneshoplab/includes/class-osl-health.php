<?php
/**
 * Diagnostics (≥ 1.5.0). Two jobs, both aimed at the same problem: a shop
 * owner should never read a raw WordPress error.
 *
 * 1. **Error mapping.** `media_sideload_image()` / `wp_handle_sideload()`
 *    fail with English sentences meant for developers ("The uploaded file
 *    could not be moved to wp-content/uploads/2026/08."). {@see
 *    self::classify_media_error()} sorts those into a handful of families and
 *    {@see self::explain_media_error()} returns the translated, actionable
 *    sentence the merchant (and the OneShopLab dashboard, through the ack
 *    `error`) actually sees. The original English message only ever goes to
 *    the WooCommerce log, for support.
 *
 * 2. **Pre-flight checks.** The same failures are almost always predictable:
 *    the uploads folder is not writable, the server cannot reach OneShopLab,
 *    WP-Cron is off, PHP memory is tiny. {@see self::report()} tests all four
 *    (the two expensive ones cached in a transient for 15 minutes) so the
 *    status card can say so *before* a merchant approves anything, and so
 *    `POST /products/sync` can carry `capabilities.health` to the dashboard.
 *
 *    A cached verdict is only ever trusted when it *passes*. {@see
 *    self::decide()} is the rule: a stored "blocked" is re-tested before it
 *    stops anything, because a host that fixes the folder permissions (or a
 *    merchant who clicks *Re-check*) must not be told the shop is broken for
 *    another quarter of an hour. The uploads probe is a temp file created and
 *    deleted, so paying for it again costs microseconds. The egress probe is
 *    the exception, and says why on {@see self::egress()}.
 *
 * Everything above the "WordPress" divider is pure PHP and unit-tested.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Diagnostics helper.
 */
final class OSL_Health {

	/* ------------------------------------------------- error families */

	public const ERR_UPLOADS_NOT_WRITABLE = 'uploads_not_writable';
	public const ERR_DISK_FULL            = 'disk_full';
	public const ERR_DOWNLOAD_FAILED      = 'download_failed';
	public const ERR_FILE_TYPE            = 'file_type';
	public const ERR_TOO_LARGE            = 'too_large';
	public const ERR_UNKNOWN              = 'unknown';

	/** Every family, in the order {@see self::classify_media_error()} tries them. */
	public const FAMILIES = array(
		self::ERR_DISK_FULL,
		self::ERR_UPLOADS_NOT_WRITABLE,
		self::ERR_FILE_TYPE,
		self::ERR_TOO_LARGE,
		self::ERR_DOWNLOAD_FAILED,
		self::ERR_UNKNOWN,
	);

	/* ------------------------------------------------------ settings */

	/** How long a probe result is trusted (seconds). */
	public const CACHE_TTL = 900;

	/** Below this, image imports start dying on `memory_limit` (64 MiB). */
	public const MIN_MEMORY_BYTES = 67108864;

	/** Timeout of the outgoing-connection probe (seconds). */
	public const EGRESS_TIMEOUT = 5;

	/** Path probed on the OneShopLab API. */
	public const EGRESS_PATH = '/api/health';

	/** A 5-minute event overdue by more than this means cron is not running. */
	public const CRON_STALL_SECONDS = 3600;

	/* ============================================ pure: error mapping */

	/**
	 * Sorts a WordPress media error into one of the families above.
	 *
	 * The WP_Error `code` decides on its own when it is unambiguous (the HTTP
	 * codes `download_url()` returns); otherwise the English message is
	 * matched against the sentences WordPress and PHP actually produce.
	 *
	 * WordPress translates its own errors, so on a French shop the message is
	 * French: `$extra` carries the same core sentences in the site's language
	 * ({@see self::core_needles()}), which is what makes the mapping work off
	 * an English site.
	 *
	 * @param string $code    WP_Error code ('' when unknown).
	 * @param string $message WP_Error message, in the site's language.
	 * @param array  $extra   Additional family => needles (lower-case).
	 * @return string One of the ERR_* constants.
	 */
	public static function classify_media_error( string $code, string $message, array $extra = array() ): string {
		$by_code = array(
			'http_404'              => self::ERR_DOWNLOAD_FAILED,
			'http_request_failed'   => self::ERR_DOWNLOAD_FAILED,
			'http_no_url'           => self::ERR_DOWNLOAD_FAILED,
			'invalid_url'           => self::ERR_DOWNLOAD_FAILED,
			'image_sideload_failed' => self::ERR_DOWNLOAD_FAILED,
			'http_no_file'          => self::ERR_UPLOADS_NOT_WRITABLE,
		);
		$key = strtolower( trim( $code ) );
		if ( isset( $by_code[ $key ] ) ) {
			return $by_code[ $key ];
		}

		$text = strtolower( trim( $message ) );
		if ( '' === $text ) {
			return self::ERR_UNKNOWN;
		}
		$patterns = self::message_patterns();
		foreach ( $extra as $family => $needles ) {
			if ( isset( $patterns[ $family ] ) ) {
				$patterns[ $family ] = array_merge( $patterns[ $family ], (array) $needles );
			}
		}
		foreach ( $patterns as $family => $needles ) {
			foreach ( $needles as $needle ) {
				if ( '' !== $needle && false !== strpos( $text, $needle ) ) {
					return $family;
				}
			}
		}
		return self::ERR_UNKNOWN;
	}

	/**
	 * The handful of WordPress core messages that matter, in the site's own
	 * language. `__( …, 'default' )` gives the translated form, and everything
	 * from the first printf placeholder on is dropped so the remaining prefix
	 * still matches once WordPress has filled the path in.
	 *
	 * Needles shorter than 12 characters are dropped: too short to be a safe
	 * substring test in any language.
	 *
	 * @return array<string,string[]>
	 */
	public static function core_needles(): array {
		$prefix = static function ( string $text ): string {
			$cut = strpos( $text, '%' );
			return strtolower( trim( false === $cut ? $text : substr( $text, 0, $cut ) ) );
		};
		$needles = array(
			self::ERR_UPLOADS_NOT_WRITABLE => array(
				// phpcs:disable WordPress.WP.I18n.MissingArgDomain -- deliberately the WordPress core catalogue.
				/* translators: %s: directory path. This is WordPress's own string, read here to recognise it in the site's language. */
				$prefix( __( 'The uploaded file could not be moved to %s.' ) ),
				/* translators: %s: directory path. This is WordPress's own string, read here to recognise it in the site's language. */
				$prefix( __( 'Unable to create directory %s. Is its parent directory writable by the server?' ) ),
				$prefix( __( 'Missing a temporary folder.' ) ),
				$prefix( __( 'Failed to write file to disk.' ) ),
				$prefix( __( 'Could not create Temporary file.' ) ),
			),
			self::ERR_FILE_TYPE             => array(
				$prefix( __( 'Sorry, this file type is not permitted for security reasons.' ) ),
				$prefix( __( 'Sorry, you are not allowed to upload this file type.' ) ),
			),
			self::ERR_TOO_LARGE             => array(
				$prefix( __( 'The uploaded file exceeds the upload_max_filesize directive in php.ini.' ) ),
				// phpcs:enable WordPress.WP.I18n.MissingArgDomain
			),
		);
		foreach ( $needles as $family => $list ) {
			$needles[ $family ] = array_values(
				array_filter(
					$list,
					static function ( $needle ) {
						return strlen( (string) $needle ) >= 12;
					}
				)
			);
		}
		return $needles;
	}

	/**
	 * Lower-case fragments of the English messages WordPress, PHP and the
	 * filesystem produce, per family. Order matters: "failed to write file to
	 * disk" is a permission problem far more often than a full disk, so the
	 * unambiguous disk-full wording is tried first.
	 *
	 * @return array<string,string[]>
	 */
	private static function message_patterns(): array {
		return array(
			self::ERR_DISK_FULL            => array(
				'no space left on device',
				'disk full',
				'disk quota',
				'quota exceeded',
			),
			self::ERR_UPLOADS_NOT_WRITABLE => array(
				'could not be moved to',
				'not writable',
				'unable to create directory',
				'could not create directory',
				'unable to create the directory',
				'failed to create directory',
				'missing a temporary folder',
				'failed to write file to disk',
				'could not create temporary file',
				'permission denied',
				'failed to open stream',
				'is its parent directory writable',
			),
			self::ERR_FILE_TYPE            => array(
				'file type is not permitted',
				'not permitted for security reasons',
				'does not meet security guidelines',
				'allowed to upload this file type',
				'invalid file type',
				'file type is not allowed',
				'not a valid image',
				'file is not an image',
			),
			self::ERR_TOO_LARGE            => array(
				'allowed memory size',
				'memory exhausted',
				'memory_limit',
				'exceeds the maximum upload size',
				'exceeds the upload_max_filesize',
				'upload_max_filesize',
				'post_max_size',
				'file is too big',
				'is too large',
				'image resize failed',
			),
			self::ERR_DOWNLOAD_FAILED      => array(
				'not found',
				'forbidden',
				'unauthorized',
				'access denied',
				'timed out',
				'timeout',
				'could not resolve host',
				'could not connect',
				'connection refused',
				'connection reset',
				'ssl certificate',
				'certificate problem',
				'too many redirects',
				'valid url was not provided',
				'invalid image url',
				'empty reply from server',
			),
		);
	}

	/**
	 * The merchant-facing sentence for a family. This is what goes into the
	 * ack `error` (so the OneShopLab dashboard shows it), into the plugin's
	 * change log, and — for the uploads family — under the diagnostics line.
	 *
	 * @param string $family One of the ERR_* constants.
	 * @return string Translated, actionable, jargon-free.
	 */
	public static function explain_media_error( string $family ): string {
		switch ( $family ) {
			case self::ERR_UPLOADS_NOT_WRITABLE:
				return __( 'Your site cannot save new images: the media folder is not writable. Ask your host to fix the permissions on wp-content/uploads.', 'oneshoplab' );
			case self::ERR_DISK_FULL:
				return __( 'Your site cannot save new images: there is no free space left on the server. Ask your host to free some space, then try again.', 'oneshoplab' );
			case self::ERR_DOWNLOAD_FAILED:
				return __( 'The image could not be downloaded. Its link may have expired — ask OneShopLab to send this change again. If it keeps failing, check that your server can make outgoing HTTPS requests.', 'oneshoplab' );
			case self::ERR_FILE_TYPE:
				return __( 'WordPress refused this image: that file type is not allowed in your media library. Ask your host to allow JPEG, PNG, GIF and WebP images.', 'oneshoplab' );
			case self::ERR_TOO_LARGE:
				return __( 'This image is too big for your server to process. Ask your host to raise the PHP memory limit and the maximum upload size.', 'oneshoplab' );
			default:
				return __( 'The image could not be added to your media library. The technical details are in WooCommerce › Status › Logs (source "oneshoplab").', 'oneshoplab' );
		}
	}

	/**
	 * Shorthand: classify then explain.
	 *
	 * @param string $code    WP_Error code.
	 * @param string $message WP_Error message.
	 * @param array  $extra   Additional family => needles.
	 * @return string
	 */
	public static function explain_media_failure( string $code, string $message, array $extra = array() ): string {
		return self::explain_media_error( self::classify_media_error( $code, $message, $extra ) );
	}

	/* ====================================== pure: report → flags / lines */

	/**
	 * The flags reported to OneShopLab inside `capabilities.health`. Only the
	 * two the dashboard can act on: a store that cannot save images should be
	 * warned before the merchant approves an image change, and a store with no
	 * cron applies changes late.
	 *
	 * @param array $report {@see self::report()} (or any subset of it).
	 * @return array{uploadsWritable:bool,cron:bool}
	 */
	public static function flags_from_report( array $report ): array {
		return array(
			'uploadsWritable' => ! empty( $report['uploads']['ok'] ),
			'cron'            => ! empty( $report['cron']['ok'] ),
		);
	}

	/**
	 * The status-card lines: label, state word, and — when the check fails —
	 * the fix in plain words.
	 *
	 * @param array $report {@see self::report()}.
	 * @return array[] {key, label, ok, state, fix}
	 */
	public static function lines( array $report ): array {
		$uploads = ! empty( $report['uploads']['ok'] );
		$egress  = ! empty( $report['egress']['ok'] );
		$cron    = ! empty( $report['cron']['ok'] );
		$memory  = ! empty( $report['memory']['ok'] );
		$limit   = isset( $report['memory']['detail'] ) ? (string) $report['memory']['detail'] : '';

		return array(
			array(
				'key'   => 'uploads',
				'label' => __( 'Saving images', 'oneshoplab' ),
				'ok'    => $uploads,
				'state' => $uploads ? __( 'OK', 'oneshoplab' ) : __( 'blocked', 'oneshoplab' ),
				'fix'   => $uploads ? '' : self::explain_media_error( self::ERR_UPLOADS_NOT_WRITABLE ),
			),
			array(
				'key'   => 'egress',
				'label' => __( 'Outgoing connection', 'oneshoplab' ),
				'ok'    => $egress,
				'state' => $egress ? __( 'OK', 'oneshoplab' ) : __( 'unreachable', 'oneshoplab' ),
				'fix'   => $egress ? '' : __( 'Your server cannot reach OneShopLab. Ask your host to allow outgoing HTTPS connections to oneshoplab.com.', 'oneshoplab' ),
			),
			array(
				'key'   => 'cron',
				'label' => __( 'Scheduled tasks', 'oneshoplab' ),
				'ok'    => $cron,
				'state' => $cron ? __( 'OK', 'oneshoplab' ) : __( 'disabled', 'oneshoplab' ),
				'fix'   => $cron ? '' : __( 'WordPress scheduled tasks are turned off, so approved changes are only applied when someone visits your site. Ask your host to run wp-cron every 5 minutes.', 'oneshoplab' ),
			),
			array(
				'key'   => 'memory',
				'label' => __( 'PHP memory', 'oneshoplab' ),
				'ok'    => $memory,
				'state' => $memory ? __( 'OK', 'oneshoplab' ) : __( 'too low', 'oneshoplab' ),
				'fix'   => $memory ? '' : sprintf(
					/* translators: %s: PHP memory_limit value, e.g. "40M" */
					__( 'The PHP memory limit is %s. Large images may fail to import. Ask your host to raise it to at least 128 MB.', 'oneshoplab' ),
					$limit
				),
			),
		);
	}

	/**
	 * `memory_limit`-style value → bytes. Negative (unlimited) stays negative.
	 *
	 * @param string $value e.g. "256M", "1G", "-1", "".
	 * @return int Bytes, or -1 for unlimited/unknown.
	 */
	public static function bytes_from_ini( string $value ): int {
		$value = trim( $value );
		if ( '' === $value ) {
			return -1;
		}
		$number = (float) $value;
		if ( $number < 0 ) {
			return -1;
		}
		switch ( strtolower( substr( $value, -1 ) ) ) {
			case 'g':
				$number *= 1024 * 1024 * 1024;
				break;
			case 'm':
				$number *= 1024 * 1024;
				break;
			case 'k':
				$number *= 1024;
				break;
		}
		return (int) $number;
	}

	/* ========================================= pure: cached vs re-tested */

	/**
	 * The rule every cached probe follows: **trust a pass, never trust a fail.**
	 *
	 * A 15-minute cache is what makes the checks affordable, but caching a
	 * *negative* means that a shop whose problem was fixed keeps being refused
	 * until the transient expires. That happened in QA: the media folder was
	 * made writable again and three perfectly legitimate changes still failed
	 * for another ten minutes on a stale "blocked". So the cache short-circuits
	 * only a passing verdict; a failing one is re-tested by running `$probe`
	 * again, and the caller stores the fresh answer.
	 *
	 * Pure on purpose — `$probe` is a callable, so the rule is unit-tested
	 * without WordPress, a transient or a filesystem.
	 *
	 * @param mixed    $cached Cached `{ok, detail, at}`, or anything else (no cache).
	 * @param callable $probe  The real test: `(): array{ok:bool,detail:string,at:int}`.
	 * @return array{0:array,1:bool} The verdict, and whether the probe was re-run
	 *                               (i.e. whether the cache should be refreshed).
	 */
	public static function decide( $cached, callable $probe ): array {
		if ( is_array( $cached ) && isset( $cached['ok'] ) && ! empty( $cached['ok'] ) ) {
			return array( $cached, false );
		}
		return array( $probe(), true );
	}

	/* =============================================== WordPress: probes */

	/**
	 * All four checks. The two that cost something (a file write, an HTTP
	 * call) are cached for {@see self::CACHE_TTL}; cron and memory are read
	 * live because they are free.
	 *
	 * @param bool $fresh Re-run the cached probes instead of reading them.
	 * @return array {uploads, egress, cron, memory}, each {ok, detail, at}.
	 */
	public static function report( bool $fresh = false ): array {
		return array(
			'uploads' => self::uploads( $fresh ),
			'egress'  => self::egress( $fresh ),
			'cron'    => self::cron(),
			'memory'  => self::memory(),
		);
	}

	/**
	 * Health flags for `capabilities.health`. Deliberately does *not* touch
	 * the egress probe: this runs on every `/products/sync`, and the outgoing
	 * call already proves egress works.
	 *
	 * @return array{uploadsWritable:bool,cron:bool}
	 */
	public static function flags(): array {
		return self::flags_from_report(
			array(
				'uploads' => self::uploads(),
				'cron'    => self::cron(),
			)
		);
	}

	/**
	 * Forgets the cached probes so the next read re-runs them.
	 */
	public static function flush(): void {
		delete_transient( OSL_State::TR_HEALTH_UPLOADS );
		delete_transient( OSL_State::TR_HEALTH_EGRESS );
	}

	/**
	 * Whether the media folder accepts a new file. This is the decision path —
	 * {@see OSL_Changes::prepare_images()} refuses a change on a `false` — so it
	 * never answers `false` from the cache: {@see self::uploads()} re-runs the
	 * write test before this can block anything.
	 *
	 * @param bool $fresh Skip the cache entirely (also for a passing verdict).
	 * @return bool
	 */
	public static function uploads_writable( bool $fresh = false ): bool {
		$result = self::uploads( $fresh );
		return ! empty( $result['ok'] );
	}

	/**
	 * Uploads probe. A passing verdict is read from the transient; a failing one
	 * is always re-tested ({@see self::decide()}), so the moment the permissions
	 * are fixed the very next change goes through.
	 *
	 * @param bool $fresh Skip the cache entirely (also for a passing verdict).
	 * @return array {ok, detail, at}
	 */
	public static function uploads( bool $fresh = false ): array {
		$cached = $fresh ? null : get_transient( OSL_State::TR_HEALTH_UPLOADS );
		list( $result, $probed ) = self::decide(
			$cached,
			static function (): array {
				return self::probe_uploads();
			}
		);
		if ( ! $probed ) {
			return $result;
		}
		set_transient( OSL_State::TR_HEALTH_UPLOADS, $result, self::CACHE_TTL );
		if ( empty( $result['ok'] ) ) {
			OSL_Logger::warning( 'Uploads folder is not writable', array( 'detail' => $result['detail'] ) );
		}
		return $result;
	}

	/**
	 * `wp_upload_dir()` plus a real write: WordPress reports no error for a
	 * month folder that already exists but lost its write bit, which is
	 * exactly the case that broke image changes in the field.
	 *
	 * @return array {ok, detail, at}
	 */
	private static function probe_uploads(): array {
		$dir = wp_upload_dir();
		if ( ! empty( $dir['error'] ) ) {
			return self::fail( (string) $dir['error'] );
		}
		$path = isset( $dir['path'] ) ? (string) $dir['path'] : '';
		if ( '' === $path ) {
			return self::fail( 'wp_upload_dir() returned no path' );
		}
		if ( ! is_dir( $path ) ) {
			return self::fail( $path . ' does not exist' );
		}
		$probe   = rtrim( $path, '/\\' ) . '/.oneshoplab-write-test-' . substr( wp_generate_uuid4(), 0, 8 ) . '.tmp';
		$written = @file_put_contents( $probe, 'oneshoplab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions, WordPress.PHP.NoSilencedErrors
		if ( false === $written ) {
			return self::fail( 'cannot write into ' . $path );
		}
		wp_delete_file( $probe );
		return self::pass( $path );
	}

	/**
	 * Outgoing-connection probe (cached). Goes through the WordPress HTTP API,
	 * so it is true whatever `allow_url_fopen` says and whichever transport
	 * (curl or streams) the host provides.
	 *
	 * This is the one probe that keeps a cached *failure*, and it is allowed to
	 * because it decides nothing: it is read by the diagnostics card only —
	 * never by {@see self::flags()}, never by the apply path — so a stale
	 * negative delays no change. Re-running it costs a 5-second HTTP round trip
	 * on a host that has just proved it cannot make one, which is exactly the
	 * page load a merchant should not wait through; *Re-check* passes
	 * `$fresh = true` and gets the live answer on demand. The day egress gates
	 * anything, it moves to {@see self::decide()} like the uploads probe.
	 *
	 * @param bool $fresh Skip the cache.
	 * @return array {ok, detail, at}
	 */
	public static function egress( bool $fresh = false ): array {
		if ( ! $fresh ) {
			$cached = get_transient( OSL_State::TR_HEALTH_EGRESS );
			if ( is_array( $cached ) && isset( $cached['ok'] ) ) {
				return $cached;
			}
		}
		$result = self::probe_egress();
		set_transient( OSL_State::TR_HEALTH_EGRESS, $result, self::CACHE_TTL );
		if ( empty( $result['ok'] ) ) {
			OSL_Logger::warning( 'Outgoing connection probe failed', array( 'detail' => $result['detail'] ) );
		}
		return $result;
	}

	/**
	 * One short GET on the OneShopLab health endpoint.
	 *
	 * @return array {ok, detail, at}
	 */
	private static function probe_egress(): array {
		$response = wp_remote_get(
			self::egress_url(),
			array(
				'timeout'     => self::EGRESS_TIMEOUT,
				'redirection' => 2,
				'user-agent'  => 'OneShopLab-WooCommerce/' . OSL_VERSION . ' (health)',
				'headers'     => array( 'Accept' => 'application/json' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return self::fail( $response->get_error_message() );
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		if ( $status < 200 || $status >= 500 ) {
			return self::fail( 'HTTP ' . $status );
		}
		return self::pass( 'HTTP ' . $status );
	}

	/**
	 * URL of the probe: the same base the client uses, so a staging site
	 * checks the API it actually talks to.
	 *
	 * @return string
	 */
	public static function egress_url(): string {
		$base = defined( 'OSL_API_BASE' ) ? OSL_API_BASE : OSL_Client::DEFAULT_BASE;
		/** This filter is documented in includes/class-osl-client.php */
		return rtrim( (string) apply_filters( 'oneshoplab_api_base', $base ), '/' ) . self::EGRESS_PATH;
	}

	/**
	 * WP-Cron sanity. `DISABLE_WP_CRON` alone is not a verdict: plenty of good
	 * hosts turn the page-load trigger off and run `wp-cron.php` from a system
	 * crontab instead, and the proof of that is a recent poll.
	 *
	 * @return array {ok, detail, at}
	 */
	public static function cron(): array {
		$next = wp_next_scheduled( OSL_Plugin::CRON_POLL_CHANGES );
		if ( ! $next ) {
			return self::fail( 'the 5-minute check is not scheduled' );
		}
		$last_poll = (int) ( OSL_State::status()['last_poll'] ?? 0 );
		$recent    = $last_poll > 0 && $last_poll > time() - 2 * self::CRON_STALL_SECONDS;
		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON && ! $recent ) {
			return self::fail( 'DISABLE_WP_CRON is on and nothing ran recently' );
		}
		if ( (int) $next < time() - self::CRON_STALL_SECONDS && ! $recent ) {
			return self::fail( 'the 5-minute check is overdue since ' . gmdate( 'Y-m-d\TH:i:s\Z', (int) $next ) );
		}
		return self::pass( 'next run ' . gmdate( 'Y-m-d\TH:i:s\Z', (int) $next ) );
	}

	/**
	 * PHP memory limit.
	 *
	 * @return array {ok, detail, at}
	 */
	public static function memory(): array {
		$raw   = (string) ini_get( 'memory_limit' );
		$bytes = self::bytes_from_ini( $raw );
		$ok    = $bytes < 0 || $bytes >= self::MIN_MEMORY_BYTES;
		return $ok ? self::pass( $raw ) : self::fail( $raw );
	}

	/**
	 * Passing result.
	 *
	 * @param string $detail Technical detail (logs only).
	 * @return array
	 */
	private static function pass( string $detail ): array {
		return array(
			'ok'     => true,
			'detail' => $detail,
			'at'     => time(),
		);
	}

	/**
	 * Failing result.
	 *
	 * @param string $detail Technical detail, in English (logs only).
	 * @return array
	 */
	private static function fail( string $detail ): array {
		return array(
			'ok'     => false,
			'detail' => $detail,
			'at'     => time(),
		);
	}
}
