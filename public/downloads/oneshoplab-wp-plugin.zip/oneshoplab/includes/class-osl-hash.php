<?php
/**
 * Canonical JSON + sha256, byte-compatible with the server's `hashValue()`:
 * object keys sorted recursively, no whitespace, `/` and unicode unescaped
 * (JavaScript `JSON.stringify` output). Used for `storeValueHash`.
 *
 * @package OneShopLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Value hashing for conflict detection.
 */
final class OSL_Hash {

	/**
	 * Canonical JSON string of a value.
	 *
	 * @param mixed $value Scalars, lists, associative arrays (= objects), stdClass.
	 * @return string
	 */
	public static function canonical_json( $value ): string {
		$json = json_encode( // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode
			self::sort_keys( $value ),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_LINE_TERMINATORS
		);
		return false === $json ? 'null' : $json;
	}

	/**
	 * sha256 hex of the canonical JSON.
	 *
	 * @param mixed $value Value.
	 * @return string
	 */
	public static function value( $value ): string {
		return hash( 'sha256', self::canonical_json( $value ) );
	}

	/**
	 * Recursively sorts associative keys; lists keep their order; null-ish stays null.
	 *
	 * @param mixed $value Value.
	 * @return mixed
	 */
	private static function sort_keys( $value ) {
		if ( $value instanceof stdClass ) {
			$value = (array) $value;
			if ( empty( $value ) ) {
				return new stdClass();
			}
		}
		if ( is_array( $value ) ) {
			if ( array_is_list( $value ) ) {
				return array_map( array( __CLASS__, 'sort_keys' ), $value );
			}
			ksort( $value, SORT_STRING );
			$out = array();
			foreach ( $value as $k => $v ) {
				$out[ (string) $k ] = self::sort_keys( $v );
			}
			return (object) $out;
		}
		return $value;
	}
}
