<?php
/**
 * Uninstall: remove every option, transient and cron event, on every site of
 * a network. The WooCommerce log files are left to WooCommerce's own retention.
 *
 * @package OneShopLab
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-osl-state.php';
require_once __DIR__ . '/includes/class-osl-plugin.php';

/**
 * Cleans the current site.
 */
function oneshoplab_uninstall_site(): void {
	foreach ( OSL_State::ALL_OPTIONS as $option ) {
		delete_option( $option );
	}
	foreach ( OSL_State::ALL_TRANSIENTS as $transient ) {
		delete_transient( $transient );
	}
	foreach ( array( OSL_Plugin::CRON_FLUSH_QUEUE, OSL_Plugin::CRON_POLL_CHANGES, OSL_Plugin::CRON_FULL_SYNC_STEP ) as $hook ) {
		wp_unschedule_hook( $hook );
	}
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'number' => 0, 'fields' => 'ids' ) ) as $blog_id ) {
		switch_to_blog( (int) $blog_id );
		oneshoplab_uninstall_site();
		restore_current_blog();
	}
} else {
	oneshoplab_uninstall_site();
}
